#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Sistema de menú interactivo para análisis de ventas
Proyecto Aurelion - Sistema de Gestión de Ventas
Autor: Ximena Vargas
Camada: 25
Grupo: 10

Este script proporciona un menú real donde el usuario puede elegir opciones.
"""

import pandas as pd  # type: ignore
import os
import sys

class MenuInteractivo:
    """
    Clase que maneja el menú interactivo del sistema de análisis de ventas.
    Esta clase proporciona una interfaz de usuario amigable para acceder a todas las funcionalidades.
    """
    
    def __init__(self):
        """
        Constructor de la clase - inicializa las variables principales.
        Carga la base de datos y prepara el sistema para su uso.
        """
        self.base_path = "../BASE_DE_DATOS"  # Ruta a la base de datos
        self.clientes = None
        self.productos = None
        self.ventas = None
        self.detalle_ventas = None
        
        # Cargar datos al inicializar
        self.cargar_datos()
    
    def cargar_datos(self):
        """
        Método que carga todos los archivos Excel de la base de datos.
        Utiliza pandas.read_excel() para leer cada archivo de manera eficiente.
        """
        try:
            print("Cargando base de datos...")
            
            # Cargar archivo de clientes
            self.clientes = pd.read_excel(os.path.join(self.base_path, "Clientes.xlsx"))
            print(f"OK Clientes: {len(self.clientes)} registros")
            
            # Cargar archivo de productos
            self.productos = pd.read_excel(os.path.join(self.base_path, "Productos.xlsx"))
            print(f"OK Productos: {len(self.productos)} registros")
            
            # Cargar archivo de ventas
            self.ventas = pd.read_excel(os.path.join(self.base_path, "Ventas.xlsx"))
            print(f"OK Ventas: {len(self.ventas)} registros")
            
            # Cargar archivo de detalle de ventas
            self.detalle_ventas = pd.read_excel(os.path.join(self.base_path, "Detalle_ventas.xlsx"))
            print(f"OK Detalle_ventas: {len(self.detalle_ventas)} registros")
            
            print("Base de datos cargada exitosamente!")
            print()
            
        except Exception as e:
            print(f"Error al cargar la base de datos: {e}")
            sys.exit(1)
    
    def mostrar_menu(self):
        """
        Método que muestra el menú principal del sistema.
        Presenta todas las opciones disponibles de manera clara y organizada.
        """
        print("=" * 60)
        print("    SISTEMA DE ANALISIS DE VENTAS - PROYECTO AURELION")
        print("=" * 60)
        print("1. Consultar Documentacion")
        print("2. Analisis de Clientes")
        print("3. Analisis de Productos")
        print("4. Analisis de Ventas")
        print("5. Reportes Generales")
        print("6. Consultas Personalizadas")
        print("7. Salir")
        print("=" * 60)
    
    def consultar_documentacion(self):
        """
        Método que muestra información sobre la documentación del proyecto.
        Proporciona acceso a todos los archivos de documentación disponibles.
        """
        print("\n=== CONSULTAR DOCUMENTACION ===")
        print("Documentación disponible del proyecto:")
        print()
        print("📄 DOCUMENTACION.md - Documentación completa del proyecto")
        print("   - Descripción del problema y solución")
        print("   - Estructura de la base de datos")
        print("   - Tipos de datos y clasificación")
        print("   - Pasos de desarrollo")
        print()
        print("📄 PSEUDOCODIGO.md - Pseudocódigo detallado")
        print("   - Algoritmos del sistema")
        print("   - Lógica de programación")
        print("   - Estructura de datos")
        print()
        print("📄 DIAGRAMA_FLUJO.md - Diagramas de flujo")
        print("   - Flujo del sistema")
        print("   - Diagramas de procesos")
        print("   - Visualización de algoritmos")
        print()
        print("📄 INSTRUCCIONES.md - Guía de uso")
        print("   - Cómo ejecutar el sistema")
        print("   - Solución de problemas")
        print("   - Archivos del proyecto")
        print()
        input("Presiona Enter para continuar...")
    
    def analisis_clientes(self):
        """
        Método que realiza análisis estadístico de los clientes.
        Proporciona información demográfica y patrones de comportamiento.
        """
        print("\n=== ANALISIS DE CLIENTES ===")
        
        # Estadísticas básicas
        total_clientes = len(self.clientes)
        ciudades_unicas = self.clientes['ciudad'].nunique()
        
        print(f"Total de clientes: {total_clientes}")
        print(f"Ciudades únicas: {ciudades_unicas}")
        print()
        
        # Top 5 ciudades por cantidad de clientes
        print("Top 5 ciudades por cantidad de clientes:")
        top_ciudades = self.clientes['ciudad'].value_counts().head(5)
        for ciudad, cantidad in top_ciudades.items():
            print(f"  {ciudad}: {cantidad} clientes")
        print()
        
        # Análisis temporal
        self.clientes['año'] = pd.to_datetime(self.clientes['fecha_alta']).dt.year
        clientes_por_año = self.clientes['año'].value_counts().sort_index()
        print("Clientes por año de alta:")
        for año, cantidad in clientes_por_año.items():
            print(f"  {año}: {cantidad} clientes")
        print()
        
        input("Presiona Enter para continuar...")
    
    def analisis_productos(self):
        """
        Método que realiza análisis del catálogo de productos.
        Proporciona información sobre categorías, precios y distribución.
        """
        print("\n=== ANALISIS DE PRODUCTOS ===")
        
        # Estadísticas básicas
        total_productos = len(self.productos)
        categorias_unicas = self.productos['categoria'].nunique()
        
        print(f"Total de productos: {total_productos}")
        print(f"Categorías únicas: {categorias_unicas}")
        print()
        
        # Productos por categoría
        print("Productos por categoría:")
        productos_por_categoria = self.productos['categoria'].value_counts()
        for categoria, cantidad in productos_por_categoria.items():
            print(f"  {categoria}: {cantidad} productos")
        print()
        
        # Análisis de precios
        precio_promedio = self.productos['precio_unitario'].mean()
        precio_minimo = self.productos['precio_unitario'].min()
        precio_maximo = self.productos['precio_unitario'].max()
        
        print("Análisis de precios:")
        print(f"  Precio promedio: ${precio_promedio:.2f}")
        print(f"  Precio mínimo: ${precio_minimo:.2f}")
        print(f"  Precio máximo: ${precio_maximo:.2f}")
        print()
        
        input("Presiona Enter para continuar...")
    
    def analisis_ventas(self):
        """
        Método que realiza análisis de las ventas realizadas.
        Proporciona información sobre tendencias, volúmenes y patrones de venta.
        """
        print("\n=== ANALISIS DE VENTAS ===")
        
        # Estadísticas básicas
        total_ventas = len(self.ventas)
        total_items = len(self.detalle_ventas)
        
        print(f"Total de ventas: {total_ventas}")
        print(f"Total de items vendidos: {total_items}")
        print()
        
        # Ventas por medio de pago
        print("Ventas por medio de pago:")
        ventas_por_medio = self.ventas['medio_pago'].value_counts()
        for medio, cantidad in ventas_por_medio.items():
            print(f"  {medio}: {cantidad} ventas")
        print()
        
        # Análisis temporal
        self.ventas['fecha'] = pd.to_datetime(self.ventas['fecha'])
        self.ventas['mes'] = self.ventas['fecha'].dt.to_period('M')
        ventas_por_mes = self.ventas['mes'].value_counts().sort_index()
        
        print("Ventas por mes:")
        for mes, cantidad in ventas_por_mes.items():
            print(f"  {mes}: {cantidad} ventas")
        print()
        
        # Análisis de importes
        total_importe = self.detalle_ventas['importe'].sum()
        importe_promedio = self.detalle_ventas['importe'].mean()
        
        print("Análisis de importes:")
        print(f"  Total de ventas: ${total_importe:,.2f}")
        print(f"  Importe promedio por item: ${importe_promedio:,.2f}")
        print()
        
        input("Presiona Enter para continuar...")
    
    def reportes_generales(self):
        """
        Método que genera reportes generales del sistema.
        Proporciona un resumen completo de todos los datos.
        """
        print("\n=== REPORTES GENERALES ===")
        
        # Resumen general
        print("RESUMEN GENERAL DEL SISTEMA:")
        print(f"  Clientes: {len(self.clientes)} registros")
        print(f"  Productos: {len(self.productos)} registros")
        print(f"  Ventas: {len(self.ventas)} registros")
        print(f"  Detalle_ventas: {len(self.detalle_ventas)} registros")
        print()
        
        # Análisis de completitud
        print("ANÁLISIS DE COMPLETITUD:")
        print(f"  Clientes: {self.clientes.isnull().sum().sum()} valores nulos")
        print(f"  Productos: {self.productos.isnull().sum().sum()} valores nulos")
        print(f"  Ventas: {self.ventas.isnull().sum().sum()} valores nulos")
        print(f"  Detalle_ventas: {self.detalle_ventas.isnull().sum().sum()} valores nulos")
        print()
        
        # Top 5 productos más vendidos
        print("TOP 5 PRODUCTOS MÁS VENDIDOS:")
        productos_vendidos = self.detalle_ventas['nombre_producto'].value_counts().head(5)
        for i, (producto, cantidad) in enumerate(productos_vendidos.items(), 1):
            print(f"  {i}. {producto}: {cantidad} unidades")
        print()
        
        input("Presiona Enter para continuar...")
    
    def consultas_personalizadas(self):
        """
        Método que permite realizar consultas personalizadas.
        Proporciona búsquedas específicas según las necesidades del usuario.
        """
        print("\n=== CONSULTAS PERSONALIZADAS ===")
        
        while True:
            print("Opciones de consulta:")
            print("1. Buscar clientes por nombre")
            print("2. Buscar productos por nombre")
            print("3. Volver al menú principal")
            print()
            
            opcion = input("Selecciona una opción (1-3): ").strip()
            
            if opcion == "1":
                self.buscar_clientes()
            elif opcion == "2":
                self.buscar_productos()
            elif opcion == "3":
                break
            else:
                print("Opción no válida. Por favor selecciona 1, 2 o 3.")
                print()
    
    def buscar_clientes(self):
        """
        Método que busca clientes por nombre.
        Permite búsquedas parciales y muestra resultados detallados.
        """
        print("\n--- BÚSQUEDA DE CLIENTES ---")
        nombre_buscar = input("Ingresa el nombre a buscar: ").strip()
        
        if nombre_buscar:
            # Buscar clientes que contengan el nombre
            clientes_encontrados = self.clientes[
                self.clientes['nombre_cliente'].str.contains(nombre_buscar, case=False, na=False)
            ]
            
            if len(clientes_encontrados) > 0:
                print(f"\nSe encontraron {len(clientes_encontrados)} cliente(s):")
                for _, cliente in clientes_encontrados.iterrows():
                    print(f"  {cliente['nombre_cliente']} - {cliente['email']} - {cliente['ciudad']}")
            else:
                print(f"No se encontraron clientes con el nombre '{nombre_buscar}'.")
        else:
            print("Nombre de búsqueda no puede estar vacío.")
        
        print()
        input("Presiona Enter para continuar...")
    
    def buscar_productos(self):
        """
        Método que busca productos por nombre.
        Permite búsquedas parciales y muestra información del producto.
        """
        print("\n--- BÚSQUEDA DE PRODUCTOS ---")
        nombre_buscar = input("Ingresa el nombre del producto a buscar: ").strip()
        
        if nombre_buscar:
            # Buscar productos que contengan el nombre
            productos_encontrados = self.productos[
                self.productos['nombre_producto'].str.contains(nombre_buscar, case=False, na=False)
            ]
            
            if len(productos_encontrados) > 0:
                print(f"\nSe encontraron {len(productos_encontrados)} producto(s):")
                for _, producto in productos_encontrados.iterrows():
                    print(f"  {producto['nombre_producto']} - {producto['categoria']} - ${producto['precio_unitario']}")
            else:
                print(f"No se encontraron productos con el nombre '{nombre_buscar}'.")
        else:
            print("Nombre de búsqueda no puede estar vacío.")
        
        print()
        input("Presiona Enter para continuar...")
    
    def ejecutar(self):
        """
        Método principal que ejecuta el menú interactivo.
        Maneja el bucle principal del sistema y la navegación del usuario.
        """
        while True:
            self.mostrar_menu()
            opcion = input("Selecciona una opción (1-7): ").strip()
            
            if opcion == "1":
                self.consultar_documentacion()
            elif opcion == "2":
                self.analisis_clientes()
            elif opcion == "3":
                self.analisis_productos()
            elif opcion == "4":
                self.analisis_ventas()
            elif opcion == "5":
                self.reportes_generales()
            elif opcion == "6":
                self.consultas_personalizadas()
            elif opcion == "7":
                print("\n¡Gracias por usar el Sistema de Análisis de Ventas!")
                print("Proyecto Aurelion - Sprint 1")
                print("Autor: Ximena Vargas Vargas")
                print("Camada: 25")
                break
            else:
                print("\nOpción no válida. Por favor selecciona una opción del 1 al 7.")
                input("Presiona Enter para continuar...")

def main():
    """
    Función principal del programa - punto de entrada.
    Esta función maneja la inicialización del sistema y el manejo de errores.
    """
    print("Iniciando Sistema de Análisis de Ventas...")
    print("Proyecto Aurelion - Sprint 1")
    print("Autor: Ximena Vargas Vargas")
    print("Camada: 25")
    print()
    
    try:
        # Crear una instancia de la clase MenuInteractivo
        menu = MenuInteractivo()
        menu.ejecutar()
    except KeyboardInterrupt:
        print("\n\nSistema interrumpido por el usuario.")
    except Exception as e:
        print(f"\nError inesperado: {e}")
        print("Por favor verifica que los archivos de la base de datos estén disponibles.")

if __name__ == "__main__":
    main()
