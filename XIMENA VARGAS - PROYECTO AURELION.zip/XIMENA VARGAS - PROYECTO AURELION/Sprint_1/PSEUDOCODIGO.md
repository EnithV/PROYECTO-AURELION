# PSEUDOCÓDIGO - PROYECTO AURELION SPRINT 1

## Análisis de Base de Datos de Ventas

**Autor:** Ximena Vargas Vargas  
**Camada:** 25  
**Grupo:** 10  
**Proyecto:** Aurelion  
**Sprint:** 1  

---

## PSEUDOCÓDIGO PRINCIPAL

```
INICIO
    // Configuración inicial
    DEFINIR ruta_base_datos = "../BASE_DE_DATOS"
    DEFINIR archivos_excel = ["Clientes.xlsx", "Productos.xlsx", "Ventas.xlsx", "Detalle_ventas.xlsx"]
    DEFINIR datos = {}
    
    // Cargar base de datos
    PARA CADA archivo EN archivos_excel HACER
        INTENTAR
            ruta_completa = CONCATENAR(ruta_base_datos, archivo)
            datos[archivo] = LEER_EXCEL(ruta_completa)
            MOSTRAR("OK " + archivo + ": " + CONTAR_FILAS(datos[archivo]) + " registros")
        CAPTURAR ERROR
            MOSTRAR("ERROR cargando " + archivo + ": " + ERROR)
        FIN INTENTAR
    FIN PARA
    
    // Sistema interactivo principal
    MIENTRAS verdadero HACER
        MOSTRAR_MENU_PRINCIPAL()
        opcion = LEER_ENTRADA_USUARIO("Selecciona una opcion (1-7): ")
        
        SEGUN opcion HACER
            CASO "1":
                CONSULTAR_DOCUMENTACION()
            CASO "2":
                ANALISIS_CLIENTES(datos)
            CASO "3":
                ANALISIS_PRODUCTOS(datos)
            CASO "4":
                ANALISIS_VENTAS(datos)
            CASO "5":
                REPORTES_GENERALES(datos)
            CASO "6":
                CONSULTAS_PERSONALIZADAS(datos)
            CASO "7":
                MOSTRAR("¡Gracias por usar el Sistema de Analisis de Ventas!")
                SALIR
            CASO OTRO:
                MOSTRAR("Opcion no valida. Por favor selecciona una opcion del 1 al 7.")
        FIN SEGUN
    FIN MIENTRAS
FIN
```

---

## PSEUDOCÓDIGO DE ANÁLISIS DE CLIENTES

```
FUNCION ANALISIS_CLIENTES(datos)
    INICIO
        df_clientes = datos['clientes']
        
        // Análisis básico
        total_clientes = CONTAR_FILAS(df_clientes)
        ciudades_unicas = CONTAR_VALORES_UNICOS(df_clientes['ciudad'])
        
        MOSTRAR("Total de clientes: " + total_clientes)
        MOSTRAR("Ciudades unicas: " + ciudades_unicas)
        
        // Top ciudades
        top_ciudades = CONTAR_VALORES(df_clientes['ciudad']).ORDENAR_DESCENDENTE().TOMAR(5)
        MOSTRAR("Top 5 ciudades por cantidad de clientes:")
        MOSTRAR(top_ciudades)
        
        // Análisis temporal
        df_clientes['año'] = CONVERTIR_FECHA(df_clientes['fecha_alta']).EXTRAER_AÑO()
        clientes_por_año = CONTAR_VALORES(df_clientes['año']).ORDENAR_POR_INDICE()
        MOSTRAR("Clientes por año de alta:")
        MOSTRAR(clientes_por_año)
        
        PAUSAR("Presiona Enter para continuar...")
    FIN
FIN FUNCION
```

---

## PSEUDOCÓDIGO DE ANÁLISIS DE PRODUCTOS

```
FUNCION ANALISIS_PRODUCTOS(datos)
    INICIO
        df_productos = datos['productos']
        
        // Análisis básico
        total_productos = CONTAR_FILAS(df_productos)
        categorias_unicas = CONTAR_VALORES_UNICOS(df_productos['categoria'])
        
        MOSTRAR("Total de productos: " + total_productos)
        MOSTRAR("Categorias unicas: " + categorias_unicas)
        
        // Análisis por categoría
        productos_por_categoria = CONTAR_VALORES(df_productos['categoria'])
        MOSTRAR("Productos por categoria:")
        MOSTRAR(productos_por_categoria)
        
        // Análisis de precios
        precio_promedio = CALCULAR_PROMEDIO(df_productos['precio_unitario'])
        precio_minimo = CALCULAR_MINIMO(df_productos['precio_unitario'])
        precio_maximo = CALCULAR_MAXIMO(df_productos['precio_unitario'])
        
        MOSTRAR("Precio promedio: $" + precio_promedio)
        MOSTRAR("Precio minimo: $" + precio_minimo)
        MOSTRAR("Precio maximo: $" + precio_maximo)
        
        PAUSAR("Presiona Enter para continuar...")
    FIN
FIN FUNCION
```

---

## PSEUDOCÓDIGO DE ANÁLISIS DE VENTAS

```
FUNCION ANALISIS_VENTAS(datos)
    INICIO
        df_ventas = datos['ventas']
        df_detalle = datos['detalle_ventas']
        
        // Análisis básico
        total_ventas = CONTAR_FILAS(df_ventas)
        total_items = CONTAR_FILAS(df_detalle)
        
        MOSTRAR("Total de ventas: " + total_ventas)
        MOSTRAR("Total de items vendidos: " + total_items)
        
        // Análisis por medio de pago
        ventas_por_medio = CONTAR_VALORES(df_ventas['medio_pago'])
        MOSTRAR("Ventas por medio de pago:")
        MOSTRAR(ventas_por_medio)
        
        // Análisis temporal
        df_ventas['fecha'] = CONVERTIR_FECHA(df_ventas['fecha'])
        df_ventas['mes'] = df_ventas['fecha'].EXTRAER_MES()
        ventas_por_mes = CONTAR_VALORES(df_ventas['mes']).ORDENAR_POR_INDICE()
        MOSTRAR("Ventas por mes:")
        MOSTRAR(ventas_por_mes)
        
        // Análisis de importes
        SI 'importe' EXISTE EN df_detalle ENTONCES
            total_ventas_importe = SUMAR(df_detalle['importe'])
            importe_promedio = CALCULAR_PROMEDIO(df_detalle['importe'])
            
            MOSTRAR("Total de ventas: $" + total_ventas_importe)
            MOSTRAR("Importe promedio por item: $" + importe_promedio)
        FIN SI
        
        PAUSAR("Presiona Enter para continuar...")
    FIN
FIN FUNCION
```

---

## PSEUDOCÓDIGO DE CONSULTAS PERSONALIZADAS

```
FUNCION CONSULTAS_PERSONALIZADAS(datos)
    INICIO
        MOSTRAR("Opciones disponibles:")
        MOSTRAR("1. Buscar cliente por nombre")
        MOSTRAR("2. Buscar producto por nombre")
        MOSTRAR("3. Ventas por rango de fechas")
        MOSTRAR("4. Productos por categoria")
        MOSTRAR("5. Volver al menu principal")
        
        opcion = LEER_ENTRADA_USUARIO("Selecciona una opcion (1-5): ")
        
        SEGUN opcion HACER
            CASO "1":
                BUSCAR_CLIENTE(datos)
            CASO "2":
                BUSCAR_PRODUCTO(datos)
            CASO "3":
                VENTAS_POR_FECHA(datos)
            CASO "4":
                PRODUCTOS_POR_CATEGORIA(datos)
            CASO "5":
                RETORNAR
            CASO OTRO:
                MOSTRAR("Opcion no valida.")
        FIN SEGUN
    FIN
FIN FUNCION

FUNCION BUSCAR_CLIENTE(datos)
    INICIO
        nombre = LEER_ENTRADA_USUARIO("Ingresa el nombre del cliente a buscar: ")
        df_clientes = datos['clientes']
        
        resultados = FILTRAR(df_clientes, df_clientes['nombre_cliente'].CONTENER(nombre, IGNORAR_MAYUSCULAS))
        
        SI CONTAR_FILAS(resultados) > 0 ENTONCES
            MOSTRAR("Se encontraron " + CONTAR_FILAS(resultados) + " cliente(s):")
            MOSTRAR(resultados[['nombre_cliente', 'email', 'ciudad']])
        SINO
            MOSTRAR("No se encontraron clientes con ese nombre.")
        FIN SI
        
        PAUSAR("Presiona Enter para continuar...")
    FIN
FIN FUNCION
```

---

## PSEUDOCÓDIGO DE MANEJO DE ERRORES

```
FUNCION CARGAR_DATOS()
    INICIO
        archivos = {
            'clientes': 'Clientes.xlsx',
            'productos': 'Productos.xlsx', 
            'ventas': 'Ventas.xlsx',
            'detalle_ventas': 'Detalle_ventas.xlsx'
        }
        
        PARA CADA nombre, archivo EN archivos HACER
            INTENTAR
                ruta = CONCATENAR(self.base_path, archivo)
                self.datos[nombre] = LEER_EXCEL(ruta)
                MOSTRAR("OK " + nombre + ": " + CONTAR_FILAS(self.datos[nombre]) + " registros")
            CAPTURAR ERROR
                MOSTRAR("ERROR cargando " + nombre + ": " + ERROR)
            FIN INTENTAR
        FIN PARA
    FIN
FIN FUNCION
```

---

## PSEUDOCÓDIGO DE VALIDACIÓN

```
FUNCION VALIDAR_DATOS(datos)
    INICIO
        // Verificar que todos los archivos se cargaron
        archivos_requeridos = ['clientes', 'productos', 'ventas', 'detalle_ventas']
        
        PARA CADA archivo EN archivos_requeridos HACER
            SI archivo NO EXISTE EN datos ENTONCES
                MOSTRAR("ERROR: No se pudo cargar " + archivo)
                RETORNAR falso
            FIN SI
        FIN PARA
        
        // Verificar estructura básica
        SI CONTAR_FILAS(datos['clientes']) == 0 ENTONCES
            MOSTRAR("ERROR: Tabla de clientes vacía")
            RETORNAR falso
        FIN SI
        
        RETORNAR verdadero
    FIN
FIN FUNCION
```
