# INSTRUCCIONES DE EJECUCIÓN

## Proyecto Aurelion - Sprint 1
**Autor:** Ximena Vargas Vargas  
**Camada:** 25  
**Grupo:** 10

## 🚀 Ejecución del Sistema

### Paso 1: Activar Ambiente Virtual
```bash
source ../../venv/Scripts/activate
```

### Paso 2: Sistema Interactivo (RECOMENDADO)
```bash
python sistema_interactivo.py
```
**Nota:** Sistema interactivo real donde el usuario elige opciones del menú.

### Paso 3: Demo Automático (Análisis completo)
```bash
python demo_sistema.py
```
**Nota:** Ejecuta todos los análisis automáticamente sin interacción del usuario.

## 📊 Opciones del Sistema

1. **Consultar Documentación** - Ver documentación completa
2. **Análisis de Clientes** - Estadísticas de clientes
3. **Análisis de Productos** - Análisis de catálogo
4. **Análisis de Ventas** - Tendencias de ventas
5. **Reportes Generales** - Resumen del sistema
6. **Consultas Personalizadas** - Búsquedas específicas
7. **Salir** - Cerrar sistema

## 🔧 Solución de Problemas

### Error de codificación:
```bash
export PYTHONIOENCODING=utf-8
```

### Error de dependencias:
```bash
pip install -r requirements.txt
```

## 📁 Archivos del Proyecto

- `sistema_interactivo.py` - **Sistema interactivo (RECOMENDADO)**
- `demo_sistema.py` - Demo automático (análisis completo)
- `DOCUMENTACION.md` - Documentación completa
- `PSEUDOCODIGO.md` - Pseudocódigo detallado
- `DIAGRAMA_FLUJO.md` - Diagramas de flujo
- `requirements.txt` - Dependencias
- `INSTRUCCIONES.md` - Este archivo
