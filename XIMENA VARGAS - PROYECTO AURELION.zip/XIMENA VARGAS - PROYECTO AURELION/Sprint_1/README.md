# PROYECTO AURELION - SPRINT 1

**Autor:** Ximena Vargas Vargas  
**Camada:** 25  
**Grupo:** 10  
**Proyecto:** Aurelion  
**Sprint:** 1  

---

## 🎯 **¿QUÉ HACE ESTE SPRINT?**

Este sprint te permite **explorar y analizar los datos de la tienda Aurelion** de forma fácil e interactiva. No necesitas conocimientos técnicos avanzados - solo selecciona opciones del menú y obtén información útil sobre:

- **Clientes**: ¿De dónde vienen? ¿Cuántos hay por ciudad?
- **Productos**: ¿Qué productos se venden más? ¿Cuáles tienen mejor precio?
- **Ventas**: ¿Cuánto se vende por mes? ¿Qué método de pago prefieren los clientes?
- **Reportes**: Resúmenes fáciles de entender para la gerencia

---

## 🚀 **EJECUCIÓN RÁPIDA**

### **Sistema Interactivo (RECOMENDADO)**
```bash
python sistema_interactivo.py
```
**¿Qué hace?** Te muestra un menú con 7 opciones donde puedes:
1. Ver documentación del proyecto
2. Analizar información de clientes
3. Analizar información de productos
4. Analizar información de ventas
5. Ver reportes generales
6. Hacer búsquedas personalizadas
7. Salir del sistema

**Ventaja**: Tú decides qué análisis ver y cuándo verlo.

### **Demo Automático**
```bash
python demo_sistema.py
```
**¿Qué hace?** Ejecuta automáticamente todos los análisis y te muestra los resultados uno tras otro.

**Ventaja**: Perfecto si quieres ver todos los análisis de una vez sin interactuar.

---

## 📁 **ARCHIVOS DEL PROYECTO**

### **Programas Python**
- `sistema_interactivo.py` - **Sistema interactivo (RECOMENDADO)**
  - Menú fácil de usar
  - 7 opciones de análisis
  - Búsquedas personalizadas
  
- `demo_sistema.py` - Demo automático
  - Ejecuta todos los análisis automáticamente
  - Muestra resultados secuencialmente

### **Documentación**
- `DOCUMENTACION.md` - Documentación técnica completa
  - Explica la estructura de la base de datos
  - Describe cada tabla y sus columnas
  - Incluye tipos de datos y relaciones

- `PSEUDOCODIGO.md` - Pseudocódigo detallado
  - Explica la lógica del programa paso a paso
  - Útil para entender cómo funciona el código

- `DIAGRAMA_FLUJO.md` - Diagramas de flujo
  - Muestra visualmente cómo funciona el sistema
  - Incluye flujos de cada opción del menú

- `INSTRUCCIONES.md` - Guía de uso
  - Instrucciones paso a paso para ejecutar el sistema
  - Solución de problemas comunes

### **Configuración**
- `requirements.txt` - Dependencias necesarias
  - Lista de librerías de Python que necesitas instalar
  - Ejemplo: pandas, openpyxl (para leer archivos Excel)

- `BASE_DE_DATOS/` - Base de datos Excel
  - Contiene los archivos con los datos de la tienda
  - 4 archivos: Clientes, Productos, Ventas, Detalle_ventas

---

## 📊 **ANÁLISIS DISPONIBLES**

### **1. Análisis de Clientes**
**¿Qué información obtienes?**
- Total de clientes registrados
- Número de ciudades diferentes
- Top 5 ciudades con más clientes
- Distribución de clientes por año de alta

**Ejemplo de uso**: "¿En qué ciudades tengo más clientes?" → Te muestra las 5 ciudades principales.

### **2. Análisis de Productos**
**¿Qué información obtienes?**
- Total de productos en el catálogo
- Número de categorías diferentes
- Distribución de productos por categoría
- Análisis de precios (promedio, mínimo, máximo)

**Ejemplo de uso**: "¿Cuál es el precio promedio de mis productos?" → Te muestra el promedio, mínimo y máximo.

### **3. Análisis de Ventas**
**¿Qué información obtienes?**
- Total de ventas realizadas
- Total de items vendidos
- Distribución de ventas por método de pago
- Ventas por mes
- Análisis de importes (total, promedio)

**Ejemplo de uso**: "¿Qué método de pago prefieren mis clientes?" → Te muestra cuántas ventas se hicieron con cada método.

### **4. Reportes Generales**
**¿Qué información obtienes?**
- Resumen completo del sistema
- Análisis de completitud de datos (valores faltantes)
- Top 5 productos más vendidos
- Estadísticas generales de todas las tablas

**Ejemplo de uso**: "¿Cuál es el estado general de mi negocio?" → Te muestra un resumen completo.

### **5. Consultas Personalizadas**
**¿Qué puedes hacer?**
- Buscar clientes por nombre
- Buscar productos por nombre
- Ver información detallada de resultados

**Ejemplo de uso**: "¿Tengo un cliente llamado 'Juan'?" → Te muestra todos los clientes con ese nombre.

---

## ✅ **SISTEMA COMPLETO Y LISTO**

**¡El proyecto está 100% completo y listo para usar!** 🎯

Todos los análisis están funcionando correctamente y la documentación está completa. Puedes empezar a usar el sistema inmediatamente siguiendo las instrucciones de ejecución rápida.
