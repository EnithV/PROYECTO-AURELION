#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de demostración del Sistema de Análisis de Ventas
Proyecto Aurelion - Sistema de Gestión de Ventas
Autor: Ximena Vargas
Camada: 25
Grupo: 10
"""

# Importar librerías necesarias para el análisis de datos
import pandas as pd  # type: ignore
import os

def demo_sistema():
    """
    Función de demostración que muestra las capacidades del sistema
    sin requerir entrada interactiva del usuario.
    Esta función ejecuta automáticamente todos los análisis disponibles.
    """
    # Mostrar encabezado del sistema
    print("=" * 60)
    print("    DEMOSTRACION DEL SISTEMA DE ANALISIS DE VENTAS")
    print("    PROYECTO AURELION - SPRINT 1")
    print("=" * 60)
    print("Autor: Ximena Vargas Vargas")
    print("Camada: 25")
    print("Fecha: 2025")
    print()
    
    # Sección 1: Cargar base de datos
    print("1. CARGANDO BASE DE DATOS...")
    print("-" * 40)
    
    # Definir ruta base donde están los archivos Excel
    base_path = "../BASE_DE_DATOS"
    
    # Diccionario con los nombres de archivos y sus rutas
    archivos = {
        'clientes': 'Clientes.xlsx',      # Archivo de datos de clientes
        'productos': 'Productos.xlsx',   # Archivo de catálogo de productos
        'ventas': 'Ventas.xlsx',          # Archivo de transacciones de ventas
        'detalle_ventas': 'Detalle_ventas.xlsx'  # Archivo de detalle de productos vendidos
    }
    
    # Diccionario para almacenar los DataFrames cargados
    datos = {}
    
    # Bucle para cargar cada archivo Excel
    for nombre, archivo in archivos.items():
        try:
            # Construir ruta completa del archivo
            ruta = os.path.join(base_path, archivo)
            # Leer archivo Excel usando pandas
            datos[nombre] = pd.read_excel(ruta)
            # Mostrar confirmación de carga exitosa
            print(f"OK {nombre.capitalize()}: {len(datos[nombre])} registros")
        except Exception as e:
            # Manejar errores de carga
            print(f"ERROR cargando {nombre}: {str(e)}")
    
    # Sección 2: Análisis de Clientes
    print("\n2. ANALISIS DE CLIENTES")
    print("-" * 40)
    if 'clientes' in datos:  # Verificar que los datos de clientes se cargaron correctamente
        df = datos['clientes']  # Obtener DataFrame de clientes
        print(f"Total de clientes: {len(df)}")  # Mostrar cantidad total de clientes
        print(f"Ciudades únicas: {df['ciudad'].nunique()}")  # Contar ciudades únicas
        print("\nTop 5 ciudades por cantidad de clientes:")
        print(df['ciudad'].value_counts().head())  # Mostrar las 5 ciudades con más clientes
        
        # Análisis temporal de clientes
        df['año'] = pd.to_datetime(df['fecha_alta']).dt.year  # Extraer año de fecha de alta
        print("\nClientes por año de alta:")
        print(df['año'].value_counts().sort_index())  # Mostrar distribución por año
    
    # Sección 3: Análisis de Productos
    print("\n3. ANALISIS DE PRODUCTOS")
    print("-" * 40)
    if 'productos' in datos:  # Verificar que los datos de productos se cargaron correctamente
        df = datos['productos']  # Obtener DataFrame de productos
        print(f"Total de productos: {len(df)}")  # Mostrar cantidad total de productos
        print(f"Categorías únicas: {df['categoria'].nunique()}")  # Contar categorías únicas
        print("\nProductos por categoría:")
        print(df['categoria'].value_counts())  # Mostrar distribución por categoría
        print(f"\nPrecio promedio: ${df['precio_unitario'].mean():.2f}")  # Calcular precio promedio
        print(f"Precio mínimo: ${df['precio_unitario'].min():.2f}")  # Encontrar precio mínimo
        print(f"Precio máximo: ${df['precio_unitario'].max():.2f}")  # Encontrar precio máximo
    
    # Sección 4: Análisis de Ventas
    print("\n4. ANALISIS DE VENTAS")
    print("-" * 40)
    if 'ventas' in datos and 'detalle_ventas' in datos:  # Verificar que ambos archivos se cargaron
        ventas = datos['ventas']  # Obtener DataFrame de ventas
        detalle = datos['detalle_ventas']  # Obtener DataFrame de detalle de ventas
        
        print(f"Total de ventas: {len(ventas)}")  # Mostrar cantidad total de ventas
        print(f"Total de items vendidos: {len(detalle)}")  # Mostrar cantidad total de items
        
        # Análisis por medio de pago
        print("\nVentas por medio de pago:")
        print(ventas['medio_pago'].value_counts())  # Contar ventas por medio de pago
        
        # Análisis temporal de ventas
        ventas['fecha'] = pd.to_datetime(ventas['fecha'])  # Convertir fecha a formato datetime
        ventas['mes'] = ventas['fecha'].dt.to_period('M')  # Extraer mes de la fecha
        print("\nVentas por mes:")
        print(ventas['mes'].value_counts().sort_index())  # Mostrar distribución por mes
        
        # Análisis de importes monetarios
        if 'importe' in detalle.columns:  # Verificar que existe la columna importe
            total_ventas = detalle['importe'].sum()  # Sumar todos los importes
            print(f"\nTotal de ventas: ${total_ventas:,.2f}")  # Mostrar total con formato de moneda
            print(f"Importe promedio por item: ${detalle['importe'].mean():.2f}")  # Calcular promedio
    
    # Sección 5: Reportes Generales
    print("\n5. REPORTES GENERALES")
    print("-" * 40)
    print("RESUMEN GENERAL DEL SISTEMA:")
    for nombre, df in datos.items():  # Iterar sobre todos los DataFrames cargados
        print(f"{nombre.capitalize()}: {len(df)} registros")  # Mostrar cantidad de registros por tabla
    
    # Análisis de completitud de datos
    print("\nANÁLISIS DE COMPLETITUD:")
    for nombre, df in datos.items():  # Iterar sobre todos los DataFrames
        nulos = df.isnull().sum().sum()  # Contar total de valores nulos
        print(f"{nombre.capitalize()}: {nulos} valores nulos")  # Mostrar cantidad de nulos por tabla
    
    # Análisis de productos más vendidos
    if 'detalle_ventas' in datos:  # Verificar que existe el detalle de ventas
        detalle = datos['detalle_ventas']  # Obtener DataFrame de detalle
        if 'nombre_producto' in detalle.columns:  # Verificar que existe la columna nombre_producto
            print("\nTOP 5 PRODUCTOS MÁS VENDIDOS:")
            top_productos = detalle['nombre_producto'].value_counts().head()  # Contar productos y tomar los 5 primeros
            for i, (producto, cantidad) in enumerate(top_productos.items(), 1):  # Enumerar resultados
                print(f"{i}. {producto}: {cantidad} unidades")  # Mostrar producto y cantidad vendida
    
    # Sección 6: Consultas Personalizadas - Ejemplos
    print("\n6. CONSULTAS PERSONALIZADAS - EJEMPLOS")
    print("-" * 40)
    
    # Ejemplo de búsqueda de clientes
    if 'clientes' in datos:  # Verificar que existen datos de clientes
        print("Ejemplo: Búsqueda de clientes que contengan 'Ana':")
        clientes = datos['clientes']  # Obtener DataFrame de clientes
        # Filtrar clientes que contengan 'Ana' en el nombre (insensible a mayúsculas)
        resultados = clientes[clientes['nombre_cliente'].str.contains('Ana', case=False, na=False)]
        if len(resultados) > 0:  # Verificar si se encontraron resultados
            print(f"Se encontraron {len(resultados)} cliente(s):")
            # Mostrar solo las columnas relevantes sin índice
            print(resultados[['nombre_cliente', 'email', 'ciudad']].head().to_string(index=False))
        else:
            print("No se encontraron clientes con ese nombre.")
    
    # Ejemplo de búsqueda de productos
    if 'productos' in datos:  # Verificar que existen datos de productos
        print("\nEjemplo: Búsqueda de productos que contengan 'Laptop':")
        productos = datos['productos']  # Obtener DataFrame de productos
        # Filtrar productos que contengan 'Laptop' en el nombre (insensible a mayúsculas)
        resultados = productos[productos['nombre_producto'].str.contains('Laptop', case=False, na=False)]
        if len(resultados) > 0:  # Verificar si se encontraron resultados
            print(f"Se encontraron {len(resultados)} producto(s):")
            # Mostrar solo las columnas relevantes sin índice
            print(resultados[['nombre_producto', 'categoria', 'precio_unitario']].to_string(index=False))
        else:
            print("No se encontraron productos con ese nombre.")
    
    # Mostrar mensaje de finalización exitosa
    print("\n" + "=" * 60)
    print("    DEMOSTRACION COMPLETADA EXITOSAMENTE")
    print("    Sistema funcional y sin errores de ejecución")
    print("=" * 60)

# Punto de entrada del programa
if __name__ == "__main__":
    demo_sistema()  # Ejecutar la función de demostración
