# 📊 PROGRAMAS INTERACTIVOS - PROYECTO AURELION

**Autor:** Ximena Vargas  
**Curso:** AI Fundamentals - Guayerd - IBM Skills Build  
**Camada:** 25  
**Grupo:** 10  
**Fecha:** 2025-10-27

---

## 🎯 RESUMEN DE PROGRAMAS INTERACTIVOS

### **TOTAL DE PROGRAMAS INTERACTIVOS: 4**

| Sprint | Programa | Tipo | Estado |
|--------|----------|------|--------|
| **Sprint_1** | `sistema_interactivo.py` | Sistema Principal | ✅ Completo |
| **Sprint_2** | `sistema_interactivo_sprint2.py` | Sistema Principal - Proyecto | ✅ Completo |
| **Sprint_2** | `menu_interactivo.py` | Sistema - Ejercicios de Clase | ✅ Completo |
| **Unificado** | `programa_unificado_aurelion.py` | Sistema Principal | ✅ Completo |

---

## 🚀 PROGRAMA UNIFICADO (RECOMENDADO)

### **`programa_unificado_aurelion.py`**

**Ubicación:** `Ximena Vargas - Proyecto Aurelion/programa_unificado_aurelion.py`

**Descripción:** Sistema principal que permite al usuario interactuar con los sprints desde un solo programa.

**Funcionalidades:**
- 🎯 Menú principal para seleccionar sprint
- 📊 Acceso a Sprint_1 (Análisis de Datos Básico)
- 🤖 Acceso a Sprint_2 (Machine Learning y Normalización)
- 📖 Información del proyecto
- 🔧 Navegación intuitiva

**Cómo ejecutar:**
```bash
cd "Ximena Vargas - Proyecto Aurelion"
python programa_unificado_aurelion.py
```

---

## 📋 PROGRAMAS INDIVIDUALES POR SPRINT

### **SPRINT_1 - Análisis de Datos Básico**

#### **`sistema_interactivo.py`**
**Ubicación:** `Sprint_1/sistema_interactivo.py`

**Características:**
- ✅ Sistema interactivo completo
- 📊 Menú con 7 opciones
- 📈 Análisis de ventas, productos, clientes, pagos
- 🎯 Consultas personalizadas
- 📋 Reportes ejecutivos
- 📚 Consulta de documentación

**Opciones del menú:**
1. Consultar Documentación
2. Análisis de Clientes
3. Análisis de Productos
4. Análisis de Ventas
5. Reportes Generales
6. Consultas Personalizadas
7. Salir

---

### **SPRINT_2 - Machine Learning y Normalización**

#### **`sistema_interactivo_sprint2.py` (PROYECTO PRINCIPAL)**
**Ubicación:** `Sprint_2/sistema_interactivo_sprint2.py`

**Características:**
- ✅ Sistema interactivo completo para el proyecto principal
- 🔧 Menú con scripts del proyecto (00-07)
- 📊 Ejecución de análisis de esquema, EDA, normalización
- 🤖 Modelos de Machine Learning
- 📈 Visualizaciones avanzadas
- 📋 Reportes finales
- 🎯 Control total sobre el proceso

**Opciones del menú:**
1. Análisis de Esquema (`00_analisis_esquema.py`)
2. Análisis Exploratorio (`01_analisis_exploratorio.py`)
3. Normalización de Datos (`02_normalizacion_datos.py`)
4. Merge de Tablas (`03_merge_tablas.py`)
5. Resumen Final (`04_resumen_final.py`)
6. Visualizaciones Avanzadas (`05_visualizaciones_avanzadas.py`) - ⚡ Genera automáticamente `ANALISIS_GRAFICOS.md`
7. Modelos de ML (`06_modelos_ml.py`) - ⚡ Genera automáticamente `VARIABLES_Y_CENTROIDES.md`
8. Estadística Inferencial (`08_estadistica_inferencial.py`)
9. Estadística Prescriptiva (`09_estadistica_prescriptiva.py`)
10. Reporte Final (`07_reporte_final.py`)
11. Generar ANALISIS_GRAFICOS.md (`10_generar_analisis_graficos.py`) - 🔄 Generación automática
12. Generar VARIABLES_Y_CENTROIDES.md (`11_generar_variables_centroides.py`) - 🔄 Generación automática
13. Ver Resultados Generados
14. Visualizar Gráficos con Interpretaciones
0. Salir

#### **`menu_interactivo.py` (EJERCICIOS DE CLASE)**
**Ubicación:** `Sprint_2/menu_interactivo.py`

**Características:**
- ✅ Sistema interactivo para ejercicios de clase
- 🔧 Menú con módulos organizados
- 📊 Ejecución de ejercicios específicos
- 📁 Navegación por módulos
- 💳 Análisis estadístico
- 📈 Visualizaciones básicas
- 🎯 Control total sobre el proceso

**Módulos disponibles:**
1. Limpieza y Transformación
   - `lectura_archivos.py` - Lectura de archivos Excel
   - `estructuras_pandas.py` - Estructuras principales de pandas
2. Estadística Aplicada
   - `estadistica_descriptiva.py` - Estadística descriptiva (incluye histogramas)
   - `correlaciones.py` - Análisis de correlaciones
3. Visualización
   - `matplotlib_basico.py` - Fundamentos de Matplotlib
   - `seaborn_avanzado.py` - Visualizaciones con Seaborn
4. Demo
   - `demo_completo.py` - Demo integrado completo

---

## 🎮 PROGRAMAS DE DEMOSTRACIÓN (NO INTERACTIVOS)

### **Sprint_1 - Demo Automático**
- `demo_sistema.py` - Ejecución automática de todos los análisis

**Nota:** Este programa ejecuta tareas automáticamente sin interacción del usuario.

---

## 🚀 INSTRUCCIONES DE USO

### **Opción 1: Programa Unificado (Recomendado)**
```bash
# Navegar al directorio principal
cd "Ximena Vargas - Proyecto Aurelion"

# Ejecutar programa unificado
python programa_unificado_aurelion.py
```

### **Opción 2: Programas Individuales**

#### **Sprint_1:**
```bash
cd "Sprint_1"
python sistema_interactivo.py
```

#### **Sprint_2 (Proyecto Principal):**
```bash
cd "Sprint_2"
python sistema_interactivo_sprint2.py
```

#### **Sprint_2 (Ejercicios de Clase - Opcional):**
```bash
cd "Sprint_2"
python menu_interactivo.py
```

---

## 📊 COMPARACIÓN DE FUNCIONALIDADES

| Característica | Sprint_1 | Sprint_2 (Proyecto) | Sprint_2 (Ejercicios) | Unificado |
|----------------|----------|---------------------|----------------------|-----------|
| **Menú Interactivo** | ✅ | ✅ | ✅ | ✅ |
| **Navegación** | ✅ | ✅ | ✅ | ✅ |
| **Análisis de Datos** | ✅ | ✅ | ✅ | ✅ |
| **Machine Learning** | ❌ | ✅ | ❌ | ✅ |
| **Normalización Avanzada** | ❌ | ✅ | ❌ | ✅ |
| **Visualizaciones** | ✅ | ✅ | ✅ | ✅ |
| **Reportes** | ✅ | ✅ | ❌ | ✅ |
| **Ejercicios de Clase** | ❌ | ❌ | ✅ | ❌ |
| **Acceso a Múltiples Sprints** | ❌ | ❌ | ❌ | ✅ |

---

## 🎯 RECOMENDACIÓN

**Para la mejor experiencia de usuario, utiliza el `programa_unificado_aurelion.py`** que te permite:

1. 🎯 Acceder a todos los sprints desde un solo lugar
2. 📊 Navegar fácilmente entre diferentes funcionalidades
3. 🔧 Ejecutar cualquier sprint sin cambiar directorios
4. 📖 Obtener información completa del proyecto
5. 🚀 Tener control total sobre el sistema

---

## 📝 NOTAS TÉCNICAS

- **Lenguaje:** Python 3.x
- **Dependencias:** pandas, numpy, matplotlib, scikit-learn
- **Sistema Operativo:** Windows, Linux, macOS
- **Interfaz:** Consola interactiva
- **Terminal:** Git Bash (recomendado)
- **Documentación:** Completa en cada módulo

---

## ⚠️ IMPORTANTE

**Este proyecto utiliza exclusivamente Git Bash.**

Para más información sobre el uso de Git Bash, consulta el README.md principal.

---

**¡Disfruta explorando el Proyecto Aurelion! 🎉**

