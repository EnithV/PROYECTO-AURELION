#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SCRIPT DE EJECUCIÓN INDEPENDIENTE - SPRINT_3
============================================

**Autor:** Ximena Vargas  
**Fecha:** 2025-11-11  
**Curso:** AI Fundamentals - Guayerd - IBM Skills Build  
**Sprint:** 3 - Machine Learning Fundamentals  

Este script permite ejecutar el Sprint_3 de forma independiente.
"""

import os
import sys

# Obtener la ruta del directorio donde está este script
ruta_script = os.path.dirname(os.path.abspath(__file__))
ruta_sprint3 = os.path.join(ruta_script, "Ximena Vargas - Proyecto Aurelion", "Demo", "demo_interactivo.py")

# Verificar que el archivo existe
if os.path.exists(ruta_sprint3):
    # Cambiar al directorio del Demo
    directorio_demo = os.path.dirname(ruta_sprint3)
    os.chdir(directorio_demo)
    
    # Ejecutar el programa
    print("🚀 Ejecutando Sprint_3 - Machine Learning Fundamentals")
    print("=" * 60)
    print()
    
    try:
        exec(open(ruta_sprint3, encoding='utf-8').read())
    except Exception as e:
        print(f"❌ Error al ejecutar: {e}")
        sys.exit(1)
else:
    print(f"❌ No se encontró el archivo: {ruta_sprint3}")
    sys.exit(1)

