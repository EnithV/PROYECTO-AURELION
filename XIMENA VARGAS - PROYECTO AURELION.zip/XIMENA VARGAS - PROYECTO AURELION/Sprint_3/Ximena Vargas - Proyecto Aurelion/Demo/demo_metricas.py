#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
<!--
# DEMO METRICAS EVALUACION - SPRINT_3
**Autor:** Ximena Vargas  
**Camada:** 25  
**Grupo:** 10  
**Fecha:** 2025-11-11  
**Curso:** AI Fundamentals - Guayerd - IBM Skills Build  
**Sprint:** 3 - Machine Learning Fundamentals  
**Módulo:** Demo - Métricas de Evaluación  
-->

DEMO DE METRICAS DE EVALUACION - PROYECTO AURELION SPRINT_3
============================================================

Demo para ejecutar el módulo de métricas de evaluación en ML.
"""

import sys               # Módulo para interactuar con el sistema
import os               # Módulo del sistema operativo
import importlib.util   # Módulo para importación dinámica
from pathlib import Path  # Módulo para manejo de rutas

def main():
    """Función principal del demo."""
    print("DEMO DE METRICAS DE EVALUACION EN ML")
    print("Grupo 10 - Camada 25 | Ximena Vargas")
    print("=" * 60)
    
    try:
        # Cargar el módulo de métricas de evaluación
        module_path = Path(__file__).parent.parent / "Fundamentos" / "04_metricas_evaluacion.py"
        
        spec = importlib.util.spec_from_file_location("metricas_evaluacion", module_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        
        # Obtener la clase EvaluationMetrics
        EvaluationMetrics = getattr(module, 'EvaluationMetrics')
        
        # Crear instancia y ejecutar
        demo = EvaluationMetrics()
        demo.execute()
        
    except Exception as e:
        print(f"[ERROR] Error al ejecutar demo: {e}")
        print("Ejecutando módulo directamente...")
        os.system("python ../Fundamentos/04_metricas_evaluacion.py")

if __name__ == "__main__":
    main()
