#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
<!--
# DEMO PREPARACION DATOS - SPRINT_3
**Autor:** Ximena Vargas  
**Camada:** 25  
**Grupo:** 10  
**Fecha:** 2025-11-11  
**Curso:** AI Fundamentals - Guayerd - IBM Skills Build  
**Sprint:** 3 - Machine Learning Fundamentals  
**Módulo:** Demo - Preparación de Datos  
-->

DEMO DE PREPARACION DE DATOS - PROYECTO AURELION SPRINT_3
==========================================================

Demo para ejecutar el módulo de preparación de datos para ML.
"""

import sys               # Módulo para interactuar con el sistema
import os               # Módulo del sistema operativo
import importlib.util   # Módulo para importación dinámica
from pathlib import Path  # Módulo para manejo de rutas

def main():
    """Función principal del demo."""
    print("DEMO DE PREPARACION DE DATOS PARA ML")
    print("Grupo 10 - Camada 25 | Ximena Vargas")
    print("=" * 60)
    
    try:
        # Cargar el módulo de preparación de datos
        module_path = Path(__file__).parent.parent / "Modelado" / "01_preparacion_datos.py"
        
        spec = importlib.util.spec_from_file_location("preparacion_datos", module_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        
        # Obtener la clase DataPreparation
        DataPreparation = getattr(module, 'DataPreparation')
        
        # Crear instancia y ejecutar
        demo = DataPreparation()
        demo.execute()
        
    except Exception as e:
        print(f"[ERROR] Error al ejecutar demo: {e}")
        print("Ejecutando módulo directamente...")
        os.system("python ../Modelado/01_preparacion_datos.py")

if __name__ == "__main__":
    main()
