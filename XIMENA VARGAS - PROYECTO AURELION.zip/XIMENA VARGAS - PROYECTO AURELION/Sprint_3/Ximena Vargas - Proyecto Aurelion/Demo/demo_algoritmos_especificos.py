#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
<!--
# DEMO ALGORITMOS ESPECIFICOS - SPRINT_3
**Autor:** Ximena Vargas  
**Camada:** 25  
**Grupo:** 10  
**Fecha:** 2025-11-11  
**Curso:** AI Fundamentals - Guayerd - IBM Skills Build  
**Sprint:** 3 - Machine Learning Fundamentals  
**Módulo:** Demo - Algoritmos Específicos  
-->

DEMO DE ALGORITMOS ESPECIFICOS - PROYECTO AURELION SPRINT_3
===========================================================

Demo para ejecutar el módulo de algoritmos específicos ML.
"""

import sys               # Módulo para interactuar con el sistema
import os               # Módulo del sistema operativo
import importlib.util   # Módulo para importación dinámica
from pathlib import Path  # Módulo para manejo de rutas

def main():
    """Función principal del demo."""
    print("DEMO DE ALGORITMOS ESPECIFICOS ML")
    print("Grupo 10 - Camada 25 | Ximena Vargas")
    print("=" * 60)
    
    try:
        # Cargar el módulo de algoritmos específicos
        module_path = Path(__file__).parent.parent / "Modelado" / "05_algoritmos_especificos.py"
        
        spec = importlib.util.spec_from_file_location("algoritmos_especificos", module_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        
        # Obtener la clase SpecificAlgorithms
        SpecificAlgorithms = getattr(module, 'SpecificAlgorithms')
        
        # Crear instancia y ejecutar
        demo = SpecificAlgorithms()
        demo.execute()
        
    except Exception as e:
        print(f"[ERROR] Error al ejecutar demo: {e}")
        print("Ejecutando módulo directamente...")
        os.system("python ../Modelado/05_algoritmos_especificos.py")

if __name__ == "__main__":
    main()
