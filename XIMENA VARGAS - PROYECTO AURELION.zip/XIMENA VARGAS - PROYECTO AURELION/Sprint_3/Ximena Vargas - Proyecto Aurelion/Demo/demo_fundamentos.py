#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
<!--
# DEMO FUNDAMENTOS ML - SPRINT_3
**Autor:** Ximena Vargas  
**Camada:** 25  
**Grupo:** 10  
**Fecha:** 2025-11-11  
**Curso:** AI Fundamentals - Guayerd - IBM Skills Build  
**Sprint:** 3 - Machine Learning Fundamentals  
**Módulo:** Demo - Fundamentos ML  
-->

DEMO DE FUNDAMENTOS DE ML - PROYECTO AURELION SPRINT_3
=======================================================

Demo para ejecutar el módulo de fundamentos de ML.
"""

import sys               # Módulo para interactuar con el sistema
import os               # Módulo del sistema operativo
import importlib.util   # Módulo para importación dinámica
from pathlib import Path  # Módulo para manejo de rutas

def main():
    """Función principal del demo."""
    print("DEMO DE FUNDAMENTOS DE MACHINE LEARNING")
    print("Grupo 10 - Camada 25 | Ximena Vargas")
    print("=" * 60)
    
    try:
        # Cargar el módulo de fundamentos
        module_path = Path(__file__).parent.parent / "Fundamentos" / "01_machine_learning_basico.py"
        
        spec = importlib.util.spec_from_file_location("fundamentos_ml", module_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        
        # Obtener la clase MLFundamentals
        MLFundamentals = getattr(module, 'MLFundamentals')
        
        # Crear instancia y ejecutar
        demo = MLFundamentals()
        demo.execute()
        
    except Exception as e:
        print(f"[ERROR] Error al ejecutar demo: {e}")
        print("Ejecutando módulo directamente...")
        os.system("python ../Fundamentos/01_machine_learning_basico.py")

if __name__ == "__main__":
    main()
