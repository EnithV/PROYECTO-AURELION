# 📊 PROYECTO AURELION
## Sistema Completo de Análisis de Datos e IA para Tienda Aurelion

**Autor:** Ximena Vargas  
**Camada:** 25  
**Grupo:** 10  
**Curso:** AI Fundamentals - Guayerd - IBM Skills Build  
**Fecha:** Octubre 2025

---

## 🎯 VISIÓN GENERAL

Proyecto Aurelion es un sistema completo de análisis de datos e Inteligencia Artificial para optimizar las operaciones comerciales de la Tienda Aurelion. El proyecto consta de sprints que, trabajando en conjunto, proporcionan análisis descriptivos y predictivos para la toma de decisiones empresariales.

---

## 🚀 INICIO RÁPIDO

### **Opción Recomendada - Programa Unificado:**
```bash
# Navegar al directorio principal
cd "Ximena Vargas - Proyecto Aurelion"

# Ejecutar programa unificado
python programa_unificado_aurelion.py
```

### **Opciones Individuales por Sprint:**
```bash
# Sprint_1 - Análisis de Datos Básico
cd "Sprint_1"
python sistema_interactivo.py

# Sprint_2 - Machine Learning y Normalización (Proyecto Principal)
cd "Sprint_2"
python sistema_interactivo_sprint2.py

# Sprint_2 - Ejercicios de Clase (Opcional)
cd "Sprint_2"
python menu_interactivo.py
```

---

## 📁 ESTRUCTURA DEL PROYECTO

```
Ximena Vargas - Proyecto Aurelion/
│
├── 📊 BASE_DE_DATOS/
│   ├── Clientes.xlsx
│   ├── Productos.xlsx
│   ├── Ventas.xlsx
│   └── Detalle_ventas.xlsx
│
├── 🐍 venv/ (Ambiente Virtual de Python)
│
├── 🚀 programa_unificado_aurelion.py (PROGRAMA PRINCIPAL)
│
├── 📋 PROGRAMAS_INTERACTIVOS.md (Documentación de programas)
│
├── 📚 README.md (Este archivo)
│
├── 📦 requirements.txt (Dependencias)
│
├── 🔧 instalar_dependencias.sh (Script de instalación)
│
├── 🎯 Sprint_1/ (Análisis de Datos Básico)
│   ├── sistema_interactivo.py (Sistema interactivo principal)
│   ├── demo_sistema.py (Demo automático)
│   ├── DOCUMENTACION.md (Documentación técnica)
│   ├── PSEUDOCODIGO.md (Pseudocódigo)
│   ├── DIAGRAMA_FLUJO.md (Diagramas de flujo)
│   ├── INSTRUCCIONES.md (Instrucciones de uso)
│   └── README.md (Documentación Sprint_1)
│
└── 🤖 Sprint_2/ (Machine Learning y Normalización)
    ├── sistema_interactivo_sprint2.py (Sistema interactivo principal - Proyecto)
    ├── menu_interactivo.py (Sistema interactivo - Ejercicios de clase)
    ├── Ximena Vargas - Proyecto Aurelion/ (Scripts del proyecto principal y ejercicios)
    │   ├── 00_analisis_esquema.py
    │   ├── 01_analisis_exploratorio.py
    │   ├── 02_normalizacion_datos.py
    │   ├── 03_merge_tablas.py
    │   ├── 04_resumen_final.py
    │   ├── 05_visualizaciones_avanzadas.py
    │   ├── 06_modelos_ml.py
    │   ├── 07_reporte_final.py
    │   ├── 1_Limpieza_y_Transformacion/ (Ejercicios de clase)
    │   │   ├── lectura_archivos.py
    │   │   └── estructuras_pandas.py
    │   ├── 2_Estadistica_Aplicada/ (Ejercicios de clase)
    │   │   ├── estadistica_descriptiva.py
    │   │   ├── correlaciones.py
    │   │   └── histogramas/ (Gráficos generados)
    │   ├── 3_Visualizacion/ (Ejercicios de clase)
    │   │   ├── matplotlib_basico.py
    │   │   └── seaborn_avanzado.py
    │   ├── 4_Demo/ (Ejercicios de clase)
    │   │   └── demo_completo.py
    │   ├── resultados/ (Resultados generados)
    │   └── README.md (Documentación del proyecto)
    └── README.md (Documentación Sprint_2)
```

---

## 🎮 PROGRAMAS INTERACTIVOS DISPONIBLES

### **1. Programa Unificado (RECOMENDADO)**
- **Archivo:** `programa_unificado_aurelion.py`
- **Función:** Acceso a los sprints desde un solo programa
- **Características:** Menú principal, navegación intuitiva, información del proyecto

### **2. Sprint_1 - Análisis de Datos Básico**
- **Archivo:** `Sprint_1/sistema_interactivo.py`
- **Funcionalidades:**
  - Análisis de ventas, productos, clientes, pagos
  - Consultas personalizadas
  - Reportes ejecutivos
  - Sistema interactivo con menú de 7 opciones

### **3. Sprint_2 - Machine Learning y Normalización (Proyecto Principal)**
- **Archivo:** `Sprint_2/sistema_interactivo_sprint2.py`
- **Funcionalidades:**
  - Ejecución de scripts del proyecto (00-07)
  - Análisis de esquema y EDA
  - Normalización de datos
  - Merge de tablas
  - Modelos de Machine Learning
  - Visualizaciones avanzadas
  - Reportes finales

### **4. Sprint_2 - Ejercicios de Clase (Opcional)**
- **Archivo:** `Sprint_2/menu_interactivo.py`
- **Funcionalidades:**
  - Ejecución de ejercicios de clase
  - Limpieza y transformación de datos
  - Estadística aplicada
  - Visualizaciones básicas
  - Demo completo

---

## 📊 FUNCIONALIDADES POR SPRINT

### **🎯 Sprint_1 - Análisis de Datos Básico**

**¿Qué hace este sprint?** Te permite explorar y entender los datos de la tienda de forma interactiva, sin necesidad de conocimientos técnicos avanzados.

- ✅ **Análisis exploratorio completo (EDA)**: 
  - Explora los datos para entender qué información tenemos
  - Identifica patrones y tendencias básicas
  - Encuentra valores atípicos o problemas en los datos

- ✅ **Análisis de ventas y productos**: 
  - Ver qué productos se venden más
  - Analizar tendencias de ventas por mes o período
  - Identificar productos estrella o productos con bajo rendimiento

- ✅ **Análisis de clientes y pagos**: 
  - Ver de dónde vienen los clientes (ciudades)
  - Analizar qué métodos de pago prefieren
  - Identificar clientes frecuentes o nuevos

- ✅ **Reportes ejecutivos**: 
  - Genera resúmenes fáciles de entender para la gerencia
  - Incluye métricas clave como total de ventas, número de clientes, etc.

- ✅ **Consultas personalizadas**: 
  - Busca clientes o productos específicos
  - Filtra datos según tus necesidades

- ✅ **Sistema interactivo completo**: 
  - Menú fácil de usar
  - No necesitas escribir código, solo seleccionar opciones

### **🤖 Sprint_2 - Machine Learning y Normalización**

**¿Qué hace este sprint?** Prepara los datos para análisis avanzados y Machine Learning, transformándolos en un formato que los algoritmos pueden entender mejor.

- ✅ **Análisis de esquema (PK/FK)**: 
  - Identifica cómo están organizadas las tablas
  - Encuentra las relaciones entre diferentes tablas de datos
  - **PK (Primary Key)**: Identificador único de cada registro (como el ID de un cliente)
  - **FK (Foreign Key)**: Conexión entre tablas (como el ID del cliente en una venta)

- ✅ **Análisis exploratorio (EDA)**: 
  - Calcula estadísticas descriptivas (promedio, mediana, etc.)
  - Crea gráficos para visualizar los datos
  - Detecta valores atípicos (outliers) que podrían afectar los análisis

- ✅ **Normalización avanzada de datos**: 
  - Convierte texto en números (por ejemplo, "Buenos Aires" → 1, "Córdoba" → 2)
  - Escala números para que todos tengan el mismo "peso" (por ejemplo, convertir precios de $100-$1000 a escala 0-1)
  - Rellena datos faltantes de forma inteligente

- ✅ **Merge de tablas normalizadas**: 
  - Combina todas las tablas en una sola
  - Asegura que no se pierdan datos al combinar

- ✅ **Modelos de Machine Learning**: 
  - Entrena algoritmos para hacer predicciones
  - Por ejemplo, predecir ventas futuras basándose en datos históricos

- ✅ **Visualizaciones avanzadas**: 
  - Crea gráficos más complejos y detallados
  - Muestra relaciones entre múltiples variables

- ✅ **Reportes finales**: 
  - Genera reportes completos con todos los análisis realizados
  - Incluye conclusiones y recomendaciones

- ✅ **Sistema interactivo para ejecutar scripts del proyecto**: 
  - Menú para ejecutar cada paso del análisis
  - No necesitas conocer los comandos técnicos

- ✅ **Ejercicios de clase (módulos 1-4)**: 
  - Ejercicios prácticos para aprender conceptos básicos
  - Incluye limpieza de datos, estadística, visualización y demos completos

---

## 🛠️ REQUISITOS TÉCNICOS

### **Software Requerido:**
- Python 3.x
- Git Bash (terminal recomendada)

### **Dependencias Python:**
```
pandas>=1.5.0
numpy>=1.24.0
matplotlib>=3.6.0
seaborn>=0.12.0
scikit-learn>=1.2.0
scipy>=1.10.0
category-encoders>=2.6.0
openpyxl>=3.1.0
```

### **Instalación de Dependencias:**

**Opción A: Instalación manual**
```bash
# Activar entorno virtual
source venv/Scripts/activate  # En Git Bash

# Instalar dependencias
pip install -r requirements.txt
```

**Opción B: Script automático (RECOMENDADO)**
```bash
# Ejecutar script de instalación
bash instalar_dependencias.sh
```

Este script automáticamente:
- Verifica que estás en el directorio correcto
- Crea el venv si no existe
- Activa el ambiente virtual
- Actualiza pip
- Instala todas las dependencias
- Muestra los paquetes instalados

---

## 📈 RESULTADOS OBTENIDOS

### **Sprint_1:**
- ✅ Sistema interactivo completo
- ✅ Análisis de 4 tablas de datos
- ✅ Reportes ejecutivos generados
- ✅ Consultas personalizadas implementadas

### **Sprint_2:**
- ✅ Módulos de análisis ejecutados
- ✅ Visualizaciones creadas
- ✅ Análisis estadístico detallado
- ✅ Modelos entrenados y evaluados

---

## 🎯 CASOS DE USO

### **Para Análisis de Negocio:**
- Usar **Sprint_1** para análisis descriptivos
- Generar reportes ejecutivos
- Analizar datos de clientes y productos

### **Para Machine Learning:**
- Usar **Sprint_2** para normalización y análisis
- Generar visualizaciones
- Realizar análisis estadístico

### **Para Desarrollo:**
- Usar **Programa Unificado** para acceso completo
- Navegar entre sprints fácilmente
- Acceder a toda la funcionalidad

---

## 📚 DOCUMENTACIÓN ADICIONAL

- **`PROGRAMAS_INTERACTIVOS.md`** - Guía completa de programas interactivos
- **`Sprint_1/DOCUMENTACION.md`** - Documentación técnica Sprint_1
- **`Sprint_1/INSTRUCCIONES.md`** - Instrucciones de uso Sprint_1
- **`Sprint_2/README.md`** - Documentación técnica Sprint_2

---

## 🏆 LOGROS DEL PROYECTO

- ✅ **2 Sprints completados** con funcionalidades únicas
- ✅ **3 programas interactivos** desarrollados
- ✅ **Sistema unificado** para acceso completo
- ✅ **Documentación completa** de cada módulo
- ✅ **Resultados reproducibles** en cada ejecución
- ✅ **Interfaz de usuario** intuitiva y profesional

---

## 👥 INFORMACIÓN DEL PROYECTO

**Desarrollado por:** Ximena Vargas  
**Curso:** AI Fundamentals - Guayerd - IBM Skills Build  
**Institución:** Guayerd  
**Año:** 2025  

---

## ⚠️ IMPORTANTE

**Este proyecto utiliza exclusivamente Git Bash. Está prohibido utilizar PowerShell.**

Para más información sobre el uso de Git Bash, consulta la sección de configuración inicial en este README.

---

**¡Disfruta explorando el Proyecto Aurelion! 🎉**
