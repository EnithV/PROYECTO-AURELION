# Ejercicios de Clase - Sprint 2

## 📚 Estructura del Curso

Este directorio contiene todos los ejercicios prácticos organizados por temas:

### 1. 📊 Limpieza y Transformación
- **Objetivo**: Dominar pandas y manipulación de datos
- **Archivos**:
  - `lectura_archivos.py` - Carga de archivos Excel
  - `estructuras_pandas.py` - DataFrame y Series
  - `inspeccion_datos.py` - Análisis exploratorio
  - `limpieza_datos.py` - Técnicas de limpieza

### 2. 📈 Estadística Aplicada
- **Objetivo**: Aplicar estadística descriptiva e inferencial con análisis completo y profesional
- **Archivos**:
  - `estadistica_descriptiva.py` - Medidas centrales y dispersión (incluye histogramas y boxplots)
  - `correlaciones.py` - Análisis de correlaciones
  - `analisis_completo_estadistico.py` ⭐ **RECOMENDADO** - Análisis completo profesional con:
    - Presentación de problema e hipótesis
    - Análisis de variables comunes con histogramas y boxplots
    - Análisis detallado de outliers
    - Análisis estadístico completo de medios de pago
    - Relación entre medios de pago, clientes y ventas
    - Recomendaciones basadas en datos
    - Explicaciones claras para todos los niveles
- **Carpeta**:
  - `histogramas/` - Carpeta donde se guardan los gráficos generados (histogramas, boxplots, gráficos de medios de pago)

**¿Qué aprenderás aquí?**
- **Medidas centrales**: Cómo calcular el promedio, la mediana y la moda para resumir tus datos.
- **Medidas de dispersión**: Cómo medir qué tan diferentes son tus datos entre sí (desviación estándar, rango, etc.).
- **Histogramas y Boxplots**: Cómo crear gráficos que muestren la distribución de tus datos y detectar valores atípicos.
- **Análisis de Outliers**: Cómo identificar y analizar valores que se salen de lo normal.
- **Análisis de Medios de Pago**: Cómo analizar estadísticamente los métodos de pago y su relación con clientes y ventas.
- **Correlaciones**: Cómo identificar si dos variables están relacionadas (por ejemplo, ¿más clientes = más ventas?).
- **Recomendaciones basadas en datos**: Cómo generar recomendaciones accionables a partir del análisis estadístico.

### 3. 📊 Visualización
- **Objetivo**: Crear visualizaciones efectivas
- **Archivos**:
  - `matplotlib_basico.py` - Fundamentos de Matplotlib
  - `seaborn_avanzado.py` - Visualizaciones con Seaborn
  - `graficos_estadisticos.py` - Gráficos especializados
  - `dashboard_visualizacion.py` - Dashboards interactivos

### 4. 🎯 Demo
- **Objetivo**: Integrar todos los conceptos
- **Archivos**:
  - `demo_completo.py` - Análisis integral
  - `dashboard_interactivo.py` - Dashboard completo
  - `reporte_automatico.py` - Generación de reportes
  - `presentacion_resultados.py` - Presentación de resultados

## 🚀 Cómo usar

### 1. Activar ambiente virtual
```bash
# Desde Git Bash
source venv/Scripts/activate
```

### 2. Instalar dependencias
```bash
pip install -r requirements.txt
```

### 3. Ejecutar el programa interactivo (RECOMENDADO)

**Para el Proyecto Principal:**
```bash
# Ejecutar el sistema interactivo del proyecto
python sistema_interactivo_sprint2.py
```

**Para Ejercicios de Clase:**
```bash
# Ejecutar el menú interactivo de ejercicios
python menu_interactivo.py
```

**🎯 Características de los programas interactivos:**

**sistema_interactivo_sprint2.py (Proyecto Principal):**
- **Menú principal** con scripts del proyecto (00-07)
- **Ejecución de análisis** de esquema, EDA, normalización
- **Modelos de ML** y visualizaciones avanzadas
- **Reportes finales** del proyecto
- **Navegación intuitiva** entre opciones

**menu_interactivo.py (Ejercicios de Clase):**
- **Menú principal** con todos los módulos disponibles
- **Submenús** para cada módulo con archivos específicos
- **Navegación intuitiva** entre opciones
- **Confirmación** antes de ejecutar el demo completo
- **Manejo de errores** y validación de entrada
- **Salida controlada** del programa

### 4. Ejecutar ejercicios individuales (OPCIONAL)
```bash
# Ejemplo: Limpieza y transformación
cd "Ximena Vargas - Proyecto Aurelion/1_Limpieza_y_Transformacion"
python lectura_archivos.py

# Ejemplo: Estadística (Análisis Completo - RECOMENDADO)
cd "../2_Estadistica_Aplicada"
python analisis_completo_estadistico.py

# O análisis básico
python estadistica_descriptiva.py

# Ejemplo: Visualización
cd "../3_Visualizacion"
python matplotlib_basico.py

# Ejemplo: Demo completo
cd "../4_Demo"
python demo_completo.py
```

## 📁 Datos disponibles

Los ejercicios utilizan los siguientes archivos de datos:
- `../../../BASE_DE_DATOS/Clientes.xlsx`
- `../../../BASE_DE_DATOS/Productos.xlsx`
- `../../../BASE_DE_DATOS/Ventas.xlsx`
- `../../../BASE_DE_DATOS/Detalle_ventas.xlsx`

## 🎯 Objetivos de aprendizaje

Al completar estos ejercicios, habrás aprendido:

### Pandas
- ✅ Carga y lectura de archivos Excel
- ✅ Manipulación de DataFrames y Series
- ✅ Operaciones de limpieza de datos
- ✅ Transformaciones y filtros

### Estadística
- ✅ **Medidas de tendencia central**: 
  - **Media (promedio)**: Suma todos los valores y divide entre la cantidad. Ejemplo: (100+200+300)/3 = 200
  - **Mediana**: El valor del medio cuando ordenas los datos. Ejemplo: En [100, 200, 300], la mediana es 200
  - **Moda**: El valor que aparece más veces. Ejemplo: Si el precio $50 aparece 10 veces, es la moda
- ✅ **Medidas de dispersión**: 
  - **Desviación estándar**: Mide qué tan dispersos están los datos. Si es baja, los datos son similares; si es alta, hay mucha variación
  - **Rango**: La diferencia entre el valor máximo y mínimo
  - **Varianza**: Similar a la desviación estándar, pero al cuadrado
- ✅ **Análisis de distribuciones**: 
  - Ver cómo se distribuyen los datos (¿están concentrados en un rango o distribuidos uniformemente?)
  - Identificar si los datos siguen una distribución normal (campana de Gauss)
- ✅ **Correlaciones y regresión**: 
  - **Correlación**: Mide si dos variables están relacionadas. Si cuando una aumenta, la otra también aumenta, hay correlación positiva
  - **Regresión**: Permite predecir un valor basándose en otros valores. Por ejemplo, predecir ventas basándose en número de clientes

### Visualización
- ✅ Gráficos básicos con Matplotlib
- ✅ Visualizaciones avanzadas con Seaborn
- ✅ Dashboards interactivos
- ✅ Interpretación de gráficos

### Integración
- ✅ Análisis completo de datos
- ✅ Generación de reportes
- ✅ Presentación de resultados
- ✅ Mejores prácticas

## 📝 Notas importantes

- Todos los ejercicios están diseñados para ejecutarse con Git Bash
- El ambiente virtual debe estar activado antes de ejecutar cualquier script
- Los archivos de datos deben estar en la ruta correcta
- Cada ejercicio incluye comentarios explicativos y ejemplos
- Los resultados se muestran en consola y se pueden guardar como archivos

## 🔧 Solución de problemas

### Error de importación
```bash
pip install --upgrade pandas matplotlib seaborn scipy openpyxl
```

### Error de rutas
- Verificar que los archivos de datos estén en `../../../BASE_DE_DATOS/` (desde las carpetas de ejercicios)
- Usar rutas relativas desde la carpeta del ejercicio
- Las carpetas de ejercicios ahora están dentro de "Ximena Vargas - Proyecto Aurelion"

### Error de ambiente virtual
```bash
# Recrear ambiente virtual
python -m venv venv
source venv/Scripts/activate
pip install -r requirements.txt
```

¡Disfruta aprendiendo análisis de datos! 🎉
