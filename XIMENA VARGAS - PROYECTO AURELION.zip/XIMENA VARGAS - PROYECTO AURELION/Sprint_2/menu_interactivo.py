#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Programa Interactivo - Ejercicios de Clase
Proyecto Aurelion - Sistema de Gestión de Ventas
Autor: Ximena Vargas
Camada: 25
Grupo: 10

Objetivo: Menú interactivo para que el usuario pueda elegir qué ejercicio ejecutar
Este programa permite:
- Navegar por diferentes módulos de ejercicios
- Ejecutar ejercicios específicos
- Ver información de cada módulo
- Salir del programa de forma controlada
"""

# Importar librerías necesarias
import os  # Librería para operaciones del sistema de archivos
import sys  # Librería para acceso a variables y funciones específicas del sistema
import subprocess  # Librería para ejecutar procesos externos

class MenuInteractivo:
    """
    Clase para manejar el menú interactivo de ejercicios
    """
    
    def __init__(self):
        """
        Inicializar el menú interactivo
        """
        self.ejercicios = {
            "1": {
                "nombre": "Limpieza y Transformación",
                "descripcion": "Aprender pandas, lectura de archivos y limpieza de datos",
                "archivos": [
                    ("lectura_archivos.py", "Lectura de archivos Excel"),
                    ("estructuras_pandas.py", "Estructuras principales de pandas")
                ],
                "ruta": os.path.join("Ximena Vargas - Proyecto Aurelion", "1_Limpieza_y_Transformacion")
            },
            "2": {
                "nombre": "Estadística Aplicada",
                "descripcion": "Estadística descriptiva, distribuciones, correlaciones, boxplots y análisis completo",
                "archivos": [
                    ("estadistica_descriptiva.py", "Estadística descriptiva básica (incluye histogramas)"),
                    ("correlaciones.py", "Análisis de correlaciones"),
                    ("analisis_completo_estadistico.py", "Análisis completo profesional (boxplots, outliers, medios de pago, recomendaciones)")
                ],
                "ruta": os.path.join("Ximena Vargas - Proyecto Aurelion", "2_Estadistica_Aplicada")
            },
            "3": {
                "nombre": "Visualización",
                "descripcion": "Matplotlib, Seaborn y visualizaciones avanzadas",
                "archivos": [
                    ("matplotlib_basico.py", "Fundamentos de Matplotlib"),
                    ("seaborn_avanzado.py", "Visualizaciones con Seaborn")
                ],
                "ruta": os.path.join("Ximena Vargas - Proyecto Aurelion", "3_Visualizacion")
            },
            "4": {
                "nombre": "Demo Completo",
                "descripcion": "Análisis integral que integra todos los conceptos",
                "archivos": [
                    ("demo_completo.py", "Demo completo de análisis de datos")
                ],
                "ruta": os.path.join("Ximena Vargas - Proyecto Aurelion", "4_Demo")
            }
        }
    
    def mostrar_bienvenida(self):
        """
        Mostrar mensaje de bienvenida
        """
        print("="*70)
        print("🎯 PROYECTO AURELION - EJERCICIOS DE CLASE")
        print("="*70)
        print("📚 Sistema de Gestión de Ventas - Análisis de Datos")
        print("👩‍💻 Autor: Ximena Vargas")
        print("🏫 Camada: 25 | Grupo: 10")
        print("="*70)
        print()
    
    def mostrar_menu_principal(self):
        """
        Mostrar el menú principal con todas las opciones
        """
        print("📋 MENÚ PRINCIPAL - EJERCICIOS DISPONIBLES")
        print("-" * 50)
        
        for clave, info in self.ejercicios.items():
            print(f"{clave}. {info['nombre']}")
            print(f"   📝 {info['descripcion']}")
            print()
        
        print("0. 🚪 Salir del programa")
        print("-" * 50)
    
    def mostrar_submenu(self, modulo):
        """
        Mostrar submenú para un módulo específico
        
        Args:
            modulo (str): Clave del módulo seleccionado
        """
        info = self.ejercicios[modulo]
        print(f"\n📂 MÓDULO: {info['nombre']}")
        print("=" * 50)
        print(f"📝 Descripción: {info['descripcion']}")
        print("\n📄 Archivos disponibles:")
        
        for i, (archivo, descripcion) in enumerate(info['archivos'], 1):
            print(f"  {i}. {archivo}")
            print(f"     📋 {descripcion}")
        
        print(f"\n{len(info['archivos']) + 1}. 🔙 Volver al menú principal")
        print("0. 🚪 Salir del programa")
        print("-" * 50)
    
    def ejecutar_archivo(self, modulo, archivo_index):
        """
        Ejecutar un archivo específico
        
        Args:
            modulo (str): Clave del módulo
            archivo_index (int): Índice del archivo a ejecutar
        """
        info = self.ejercicios[modulo]
        archivo = info['archivos'][archivo_index - 1][0]
        ruta_completa = os.path.join(info['ruta'], archivo)
        
        print(f"\n🚀 Ejecutando: {archivo}")
        print("=" * 50)
        
        try:
            # Verificar que el archivo existe
            if not os.path.exists(ruta_completa):
                print(f"❌ Error: El archivo {ruta_completa} no existe")
                return False
            
            # Guardar directorio actual
            directorio_actual = os.getcwd()
            try:
                # Cambiar al directorio del módulo para que las rutas relativas funcionen
                directorio_modulo = os.path.dirname(os.path.abspath(ruta_completa))
                os.chdir(directorio_modulo)
                
                # Configurar entorno con codificación UTF-8 para Windows
                env = os.environ.copy()
                env['PYTHONIOENCODING'] = 'utf-8'
                
                # Ejecutar el archivo Python desde su directorio
                resultado = subprocess.run(
                    [sys.executable, archivo], 
                    capture_output=False, 
                    text=True,
                    env=env
                )
            finally:
                # Restaurar directorio original
                os.chdir(directorio_actual)
            
            if resultado.returncode == 0:
                print(f"\n✅ {archivo} ejecutado exitosamente")
            else:
                print(f"\n❌ Error al ejecutar {archivo}")
            
            return True
            
        except Exception as e:
            print(f"❌ Error inesperado: {e}")
            return False
    
    def ejecutar_demo_completo(self):
        """
        Ejecutar el demo completo
        """
        print("\n🎯 EJECUTANDO DEMO COMPLETO")
        print("=" * 50)
        print("⚠️  Este demo ejecutará un análisis completo de datos.")
        print("📊 Incluye: carga de datos, limpieza, estadística y visualizaciones")
        print()
        
        confirmacion = input("¿Deseas continuar? (s/n): ").lower().strip()
        
        if confirmacion in ['s', 'si', 'sí', 'y', 'yes']:
            return self.ejecutar_archivo("4", 1)
        else:
            print("❌ Demo cancelado por el usuario")
            return False
    
    def procesar_opcion_modulo(self, modulo):
        """
        Procesar la selección de un módulo
        
        Args:
            modulo (str): Clave del módulo seleccionado
        """
        while True:
            self.mostrar_submenu(modulo)
            
            try:
                opcion = input("Selecciona una opción: ").strip()
                
                if opcion == "0":
                    print("👋 ¡Hasta luego!")
                    sys.exit(0)
                elif opcion == str(len(self.ejercicios[modulo]['archivos']) + 1):
                    return  # Volver al menú principal
                else:
                    opcion_num = int(opcion)
                    if 1 <= opcion_num <= len(self.ejercicios[modulo]['archivos']):
                        if modulo == "4":  # Demo completo
                            self.ejecutar_demo_completo()
                        else:
                            self.ejecutar_archivo(modulo, opcion_num)
                        
                        input("\n⏸️  Presiona Enter para continuar...")
                    else:
                        print("❌ Opción inválida. Intenta de nuevo.")
                        
            except ValueError:
                print("❌ Por favor, ingresa un número válido.")
            except KeyboardInterrupt:
                print("\n\n👋 Programa interrumpido por el usuario. ¡Hasta luego!")
                sys.exit(0)
    
    def ejecutar(self):
        """
        Ejecutar el menú interactivo principal
        """
        self.mostrar_bienvenida()
        
        while True:
            try:
                self.mostrar_menu_principal()
                opcion = input("Selecciona una opción: ").strip()
                
                if opcion == "0":
                    print("👋 ¡Gracias por usar el sistema! ¡Hasta luego!")
                    break
                elif opcion in self.ejercicios:
                    self.procesar_opcion_modulo(opcion)
                else:
                    print("❌ Opción inválida. Por favor, selecciona una opción del 0 al 4.")
                    input("⏸️  Presiona Enter para continuar...")
                    
            except KeyboardInterrupt:
                print("\n\n👋 Programa interrumpido por el usuario. ¡Hasta luego!")
                break
            except Exception as e:
                print(f"❌ Error inesperado: {e}")
                input("⏸️  Presiona Enter para continuar...")

def main():
    """
    Función principal del programa interactivo
    """
    # Verificar que estamos en el directorio correcto
    ruta_verificacion = os.path.join("Ximena Vargas - Proyecto Aurelion", "1_Limpieza_y_Transformacion")
    if not os.path.exists(ruta_verificacion):
        print("❌ Error: Este programa debe ejecutarse desde la carpeta Sprint_2")
        print("📁 Asegúrate de estar en el directorio correcto")
        sys.exit(1)
    
    # Crear y ejecutar el menú interactivo
    menu = MenuInteractivo()
    menu.ejecutar()

if __name__ == "__main__":
    main()
