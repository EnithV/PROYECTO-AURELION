# Carpeta de Histogramas

Esta carpeta contiene todos los gráficos generados como parte del análisis estadístico descriptivo.

## Contenido

Los histogramas se generan automáticamente cuando se ejecuta el análisis estadístico completo. Esta carpeta incluye:

- **Histogramas individuales**: Un histograma por cada variable numérica analizada
- **Boxplots**: Gráficos para detección de outliers
- **Matrices de correlaciones**: Heatmaps de correlaciones entre variables
- **Gráficos de métodos de pago**: Distribución de métodos de pago (si aplica)

## Generación

Los histogramas se generan automáticamente cuando se ejecuta:
- `estadistica_descriptiva.py` con el parámetro `generar_histograma=True`
- `demo_completo.py` (genera todos los histogramas automáticamente)

## Ubicación

Esta carpeta está dentro de `2_Estadistica_Aplicada/` porque los histogramas son parte del análisis estadístico descriptivo, no un módulo separado.

