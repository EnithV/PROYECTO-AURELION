#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ejercicio 3: Análisis de Correlaciones
Proyecto Aurelion - Sistema de Gestión de Ventas
Autor: Ximena Vargas
Camada: 25
Grupo: 10

Objetivo: Calcular e interpretar correlaciones entre variables
Este ejercicio enseña:
- Correlación de Pearson (lineal)
- Correlación de Spearman (monótona)
- Matrices de correlación
- Interpretación de resultados estadísticos
- Significancia estadística
"""

# Importar librerías necesarias para el análisis de correlaciones
import pandas as pd  # type: ignore
import numpy as np  # type: ignore
import os

# Importar scipy.stats (opcional para evitar errores del linter)
try:
    from scipy.stats import pearsonr, spearmanr  # type: ignore
except ImportError:
    pearsonr = None
    spearmanr = None

def cargar_datos():
    """
    Cargar datos para análisis de correlaciones
    """
    ruta_datos = "../../../BASE_DE_DATOS/"
    
    try:
        ventas = pd.read_excel(os.path.join(ruta_datos, "Ventas.xlsx"))
        detalle_ventas = pd.read_excel(os.path.join(ruta_datos, "Detalle_ventas.xlsx"))
        productos = pd.read_excel(os.path.join(ruta_datos, "Productos.xlsx"))
        
        print("✅ Datos cargados para análisis de correlaciones")
        return ventas, detalle_ventas, productos
        
    except Exception as e:
        print(f"❌ Error al cargar datos: {e}")
        return None, None, None

def calcular_correlacion_pearson(df, col1, col2):
    """
    Calcular correlación de Pearson entre dos variables
    """
    if col1 not in df.columns or col2 not in df.columns:
        print(f"❌ Una o ambas columnas no existen: {col1}, {col2}")
        return None, None
    
    if not (pd.api.types.is_numeric_dtype(df[col1]) and pd.api.types.is_numeric_dtype(df[col2])):
        print(f"❌ Una o ambas columnas no son numéricas: {col1}, {col2}")
        return None, None
    
    # Eliminar valores nulos
    data_clean = df[[col1, col2]].dropna()
    
    if len(data_clean) < 2:
        print(f"❌ No hay suficientes datos válidos para calcular correlación")
        return None, None
    
    if pearsonr is None:
        print(f"❌ scipy.stats no está disponible. Usando método de pandas.")
        correlation = data_clean[col1].corr(data_clean[col2], method='pearson')
        p_value = None  # pandas no calcula p-value directamente
    else:
        correlation, p_value = pearsonr(data_clean[col1], data_clean[col2])
    
    print(f"\n📊 CORRELACIÓN DE PEARSON: {col1} vs {col2}")
    print("="*50)
    print(f"Correlación: {correlation:.4f}")
    if p_value is not None:
        print(f"P-valor: {p_value:.4f}")
        print(f"Significancia: {'Significativa' if p_value < 0.05 else 'No significativa'} (α=0.05)")
    else:
        print(f"P-valor: No disponible (usando pandas)")
    print(f"Interpretación: {interpretar_correlacion(correlation)}")
    
    return correlation, p_value

def calcular_correlacion_spearman(df, col1, col2):
    """
    Calcular correlación de Spearman entre dos variables
    """
    if col1 not in df.columns or col2 not in df.columns:
        print(f"❌ Una o ambas columnas no existen: {col1}, {col2}")
        return None, None
    
    if not (pd.api.types.is_numeric_dtype(df[col1]) and pd.api.types.is_numeric_dtype(df[col2])):
        print(f"❌ Una o ambas columnas no son numéricas: {col1}, {col2}")
        return None, None
    
    # Eliminar valores nulos
    data_clean = df[[col1, col2]].dropna()
    
    if len(data_clean) < 2:
        print(f"❌ No hay suficientes datos válidos para calcular correlación")
        return None, None
    
    if spearmanr is None:
        print(f"❌ scipy.stats no está disponible. Usando método de pandas.")
        correlation = data_clean[col1].corr(data_clean[col2], method='spearman')
        p_value = None  # pandas no calcula p-value directamente
    else:
        correlation, p_value = spearmanr(data_clean[col1], data_clean[col2])
    
    print(f"\n📈 CORRELACIÓN DE SPEARMAN: {col1} vs {col2}")
    print("="*50)
    print(f"Correlación: {correlation:.4f}")
    if p_value is not None:
        print(f"P-valor: {p_value:.4f}")
        print(f"Significancia: {'Significativa' if p_value < 0.05 else 'No significativa'} (α=0.05)")
    else:
        print(f"P-valor: No disponible (usando pandas)")
    print(f"Interpretación: {interpretar_correlacion(correlation)}")
    
    return correlation, p_value

def interpretar_correlacion(correlation):
    """
    Interpretar la fuerza de la correlación
    """
    abs_corr = abs(correlation)
    
    if abs_corr >= 0.9:
        return "Correlación muy fuerte"
    elif abs_corr >= 0.7:
        return "Correlación fuerte"
    elif abs_corr >= 0.5:
        return "Correlación moderada"
    elif abs_corr >= 0.3:
        return "Correlación débil"
    else:
        return "Correlación muy débil o nula"

def matriz_correlaciones(df, metodo='pearson'):
    """
    Calcular matriz de correlaciones
    """
    print(f"\n🔢 MATRIZ DE CORRELACIONES ({metodo.upper()})")
    print("="*50)
    
    # Seleccionar solo columnas numéricas
    df_numeric = df.select_dtypes(include=[np.number])
    
    if df_numeric.empty:
        print("❌ No hay columnas numéricas en el DataFrame")
        return None
    
    # Calcular matriz de correlaciones
    if metodo.lower() == 'pearson':
        corr_matrix = df_numeric.corr(method='pearson')
    elif metodo.lower() == 'spearman':
        corr_matrix = df_numeric.corr(method='spearman')
    else:
        print("❌ Método no válido. Use 'pearson' o 'spearman'")
        return None
    
    print("Matriz de correlaciones:")
    print(corr_matrix.round(4))
    
    return corr_matrix

def analizar_correlaciones_fuertes(corr_matrix, umbral=0.7):
    """
    Identificar correlaciones fuertes en la matriz
    """
    print(f"\n🎯 CORRELACIONES FUERTES (|r| >= {umbral})")
    print("="*50)
    
    # Obtener pares de correlaciones fuertes
    strong_correlations = []
    
    for i in range(len(corr_matrix.columns)):
        for j in range(i+1, len(corr_matrix.columns)):
            corr_value = corr_matrix.iloc[i, j]
            if abs(corr_value) >= umbral:
                strong_correlations.append({
                    'Variable 1': corr_matrix.columns[i],
                    'Variable 2': corr_matrix.columns[j],
                    'Correlación': corr_value,
                    'Fuerza': interpretar_correlacion(corr_value)
                })
    
    if strong_correlations:
        df_strong = pd.DataFrame(strong_correlations)
        print(df_strong.to_string(index=False))
    else:
        print(f"No se encontraron correlaciones con |r| >= {umbral}")

def comparar_metodos_correlacion(df, col1, col2):
    """
    Comparar correlación de Pearson vs Spearman
    """
    print(f"\n⚖️  COMPARACIÓN PEARSON vs SPEARMAN: {col1} vs {col2}")
    print("="*60)
    
    # Pearson
    pearson_corr, pearson_p = calcular_correlacion_pearson(df, col1, col2)
    
    # Spearman
    spearman_corr, spearman_p = calcular_correlacion_spearman(df, col1, col2)
    
    if pearson_corr is not None and spearman_corr is not None:
        print(f"\n📊 RESUMEN COMPARATIVO:")
        pearson_p_str = f"{pearson_p:.4f}" if pearson_p is not None else "N/A"
        spearman_p_str = f"{spearman_p:.4f}" if spearman_p is not None else "N/A"
        print(f"Pearson:  r = {pearson_corr:.4f}, p = {pearson_p_str}")
        print(f"Spearman: ρ = {spearman_corr:.4f}, p = {spearman_p_str}")
        print(f"Diferencia: {abs(pearson_corr - spearman_corr):.4f}")
        
        if abs(pearson_corr - spearman_corr) > 0.1:
            print("⚠️  Diferencia notable entre métodos - posible no-linealidad")

if __name__ == "__main__":
    print("🚀 Iniciando análisis de correlaciones...")
    
    # Cargar datos
    ventas, detalle_ventas, productos = cargar_datos()
    
    if detalle_ventas is not None:
        print("\n" + "="*60)
        print("ANÁLISIS DE CORRELACIONES - DETALLE VENTAS")
        print("="*60)
        
        # Mostrar columnas disponibles
        columnas_numericas = detalle_ventas.select_dtypes(include=[np.number]).columns
        print(f"Columnas numéricas disponibles: {list(columnas_numericas)}")
        
        # Matriz de correlaciones de Pearson
        corr_pearson = matriz_correlaciones(detalle_ventas, 'pearson')
        
        # Matriz de correlaciones de Spearman
        corr_spearman = matriz_correlaciones(detalle_ventas, 'spearman')
        
        # Analizar correlaciones fuertes
        if corr_pearson is not None:
            analizar_correlaciones_fuertes(corr_pearson, umbral=0.5)
        
        # Comparar métodos si hay al menos 2 columnas numéricas
        if len(columnas_numericas) >= 2:
            col1, col2 = columnas_numericas[0], columnas_numericas[1]
            comparar_metodos_correlacion(detalle_ventas, col1, col2)
        
        # Análisis individual de pares de variables
        if len(columnas_numericas) >= 2:
            print(f"\n🔍 ANÁLISIS INDIVIDUAL DE CORRELACIONES")
            print("="*50)
            
            for i in range(len(columnas_numericas)):
                for j in range(i+1, len(columnas_numericas)):
                    col1, col2 = columnas_numericas[i], columnas_numericas[j]
                    calcular_correlacion_pearson(detalle_ventas, col1, col2)
