#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ANÁLISIS ESTADÍSTICO COMPLETO Y PROFESIONAL - PROYECTO AURELION
Proyecto Aurelion - Sistema de Gestión de Ventas
Autor: Ximena Vargas
Camada: 25
Grupo: 10

Este script realiza un análisis estadístico completo y profesional que incluye:
- Análisis de problema e hipótesis
- Estadísticas descriptivas detalladas
- Histogramas y boxplots de variables comunes
- Análisis detallado de outliers
- Análisis estadístico de medios de pago y su relación con clientes y ventas
- Recomendaciones basadas en datos
- Explicaciones claras para personas sin conocimiento de estadística
"""

import pandas as pd
import numpy as np
import os
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

class AnalisisCompletoEstadistico:
    """
    Clase para realizar análisis estadístico completo y profesional.
    
    Incluye análisis de problema, hipótesis, estadísticas detalladas,
    visualizaciones (histogramas, boxplots), análisis de outliers,
    análisis de medios de pago y recomendaciones.
    """
    
    def __init__(self):
        """Inicializar el analizador estadístico completo."""
        self.base_path = "../../../BASE_DE_DATOS"
        self.tablas = {}
        self.resultados = {}
        
        # Configurar estilo de visualización
        plt.style.use('seaborn-v0_8-darkgrid')
        sns.set_palette("husl")
        
        # Directorio para guardar gráficos
        self.resultados_dir = Path(__file__).parent / "histogramas"
        self.resultados_dir.mkdir(exist_ok=True)
    
    def cargar_datos(self):
        """Cargar todas las tablas de la base de datos."""
        print("=" * 80)
        print("📊 CARGANDO DATOS PARA ANÁLISIS ESTADÍSTICO COMPLETO")
        print("=" * 80)
        
        try:
            self.tablas['clientes'] = pd.read_excel(f"{self.base_path}/Clientes.xlsx")
            self.tablas['productos'] = pd.read_excel(f"{self.base_path}/Productos.xlsx")
            self.tablas['ventas'] = pd.read_excel(f"{self.base_path}/Ventas.xlsx")
            self.tablas['detalle_ventas'] = pd.read_excel(f"{self.base_path}/Detalle_ventas.xlsx")
            
            print("✅ Todas las tablas cargadas exitosamente!")
            print(f"   • Clientes: {len(self.tablas['clientes'])} registros")
            print(f"   • Productos: {len(self.tablas['productos'])} registros")
            print(f"   • Ventas: {len(self.tablas['ventas'])} registros")
            print(f"   • Detalle Ventas: {len(self.tablas['detalle_ventas'])} registros")
            return True
            
        except Exception as e:
            print(f"❌ Error al cargar datos: {e}")
            return False
    
    def presentar_problema_e_hipotesis(self):
        """
        Presentar el problema de negocio y las hipótesis a analizar.
        Explicado de forma clara para personas sin conocimiento de estadística.
        """
        print("\n" + "=" * 80)
        print("📋 ANÁLISIS DEL PROBLEMA Y HIPÓTESIS")
        print("=" * 80)
        
        print("\n🎯 PROBLEMA DE NEGOCIO:")
        print("-" * 80)
        print("""
La Tienda Aurelion necesita entender mejor su negocio para tomar decisiones 
inteligentes. Queremos responder preguntas como:

1. ¿Qué productos se venden más y por qué?
2. ¿Qué método de pago prefieren los clientes y cómo afecta esto a las ventas?
3. ¿Hay clientes que compran mucho más que otros?
4. ¿Hay valores atípicos (ventas muy grandes o muy pequeñas) que necesitamos entender?
5. ¿Cómo se relacionan las diferentes variables del negocio?

Para responder estas preguntas, necesitamos hacer un análisis estadístico completo
que nos ayude a entender los patrones y tendencias en los datos.
        """)
        
        print("\n💡 HIPÓTESIS A ANALIZAR:")
        print("-" * 80)
        print("""
H1: Los métodos de pago tienen diferentes patrones de uso y montos promedio
    → Analizaremos si algunos métodos de pago se usan más que otros
    → Veremos si el monto promedio de compra varía según el método de pago

H2: Existen valores atípicos (outliers) en las ventas que pueden indicar
    oportunidades o problemas
    → Identificaremos ventas muy grandes o muy pequeñas
    → Analizaremos si estos valores son normales o requieren atención

H3: Las variables numéricas (precios, cantidades, importes) tienen distribuciones
    que nos ayudan a entender el comportamiento del negocio
    → Veremos cómo se distribuyen los precios, cantidades e importes
    → Identificaremos si hay concentración en ciertos rangos de valores

H4: Existen relaciones entre las diferentes variables que pueden ayudar a
    predecir comportamientos
    → Analizaremos si hay correlaciones entre variables
    → Identificaremos qué variables están más relacionadas entre sí
        """)
        
        print("\n📊 METODOLOGÍA:")
        print("-" * 80)
        print("""
Para analizar estas hipótesis, utilizaremos:

1. Estadísticas Descriptivas: Números que resumen los datos (promedios, medianas, etc.)
2. Visualizaciones: Gráficos que nos permiten ver los datos de forma visual
3. Análisis de Outliers: Identificación de valores que se salen de lo normal
4. Análisis de Correlaciones: Identificación de relaciones entre variables
5. Análisis de Medios de Pago: Estudio detallado de cómo los clientes pagan

Cada análisis incluirá explicaciones claras para que cualquier persona pueda entenderlo.
        """)
        
        input("\n⏸️  Presiona Enter para continuar con el análisis...")
    
    def analisis_variables_comunes(self):
        """
        Analizar variables comunes entre todas las tablas.
        Incluye histogramas y boxplots para visualización.
        """
        print("\n" + "=" * 80)
        print("📊 ANÁLISIS DE VARIABLES COMUNES")
        print("=" * 80)
        
        print("\n💡 ¿QUÉ SON LAS VARIABLES COMUNES?")
        print("-" * 80)
        print("""
Las variables comunes son aquellas que aparecen en múltiples tablas o que
representan conceptos similares. Por ejemplo:
- ID de venta aparece en Ventas y Detalle_ventas
- Precios e importes aparecen en diferentes tablas
- Cantidades de productos vendidos

Analizar estas variables nos ayuda a entender:
- Cómo se distribuyen los valores (¿hay muchos valores pequeños o grandes?)
- Si hay valores atípicos que necesitamos investigar
- Cómo se relacionan las diferentes partes del negocio
        """)
        
        # Variables numéricas comunes a analizar
        variables_comunes = {
            'detalle_ventas': ['cantidad', 'precio_unitario', 'importe'],
            'productos': ['precio_unitario'],
            'ventas': ['id_venta', 'id_cliente']
        }
        
        resultados_variables = {}
        
        for tabla_nombre, columnas in variables_comunes.items():
            if tabla_nombre not in self.tablas:
                continue
                
            df = self.tablas[tabla_nombre]
            print(f"\n📋 ANÁLISIS DE VARIABLES EN: {tabla_nombre.upper()}")
            print("-" * 80)
            
            for columna in columnas:
                if columna not in df.columns:
                    continue
                
                if not pd.api.types.is_numeric_dtype(df[columna]):
                    continue
                
                print(f"\n🔍 Analizando: {columna}")
                print("-" * 60)
                
                data = df[columna].dropna()
                
                if len(data) == 0:
                    print(f"   ⚠️  No hay datos válidos para {columna}")
                    continue
                
                # Estadísticas descriptivas
                print(f"\n📊 ESTADÍSTICAS DESCRIPTIVAS:")
                print(f"   • Total de valores: {len(data)}")
                print(f"   • Promedio (Media): {data.mean():.2f}")
                print(f"   • Mediana: {data.median():.2f}")
                print(f"   • Desviación estándar: {data.std():.2f}")
                print(f"   • Mínimo: {data.min():.2f}")
                print(f"   • Máximo: {data.max():.2f}")
                print(f"   • Rango: {data.max() - data.min():.2f}")
                
                # Explicación simple
                print(f"\n💡 INTERPRETACIÓN:")
                print(f"   • El promedio de {columna} es {data.mean():.2f}")
                print(f"   • La mitad de los valores están por debajo de {data.median():.2f} (mediana)")
                print(f"   • Los valores van desde {data.min():.2f} hasta {data.max():.2f}")
                
                # Crear histograma
                self.crear_histograma_variable(data, columna, tabla_nombre)
                
                # Crear boxplot
                self.crear_boxplot_variable(data, columna, tabla_nombre)
                
                # Análisis de outliers
                outliers_info = self.analizar_outliers_detallado(data, columna)
                resultados_variables[f"{tabla_nombre}_{columna}"] = {
                    'estadisticas': {
                        'media': data.mean(),
                        'mediana': data.median(),
                        'std': data.std(),
                        'min': data.min(),
                        'max': data.max()
                    },
                    'outliers': outliers_info
                }
        
        self.resultados['variables_comunes'] = resultados_variables
        input("\n⏸️  Presiona Enter para continuar...")
    
    def crear_histograma_variable(self, data, columna, tabla_nombre):
        """Crear histograma para una variable con explicación clara y análisis de sesgo."""
        print(f"\n📊 Generando histograma para {columna}...")
        
        fig, ax = plt.subplots(figsize=(14, 8))
        
        # Calcular número óptimo de bins
        n_bins = min(30, int(np.sqrt(len(data))))
        
        # Crear histograma
        n, bins, patches = ax.hist(data, bins=n_bins, alpha=0.7, color='steelblue', 
                                   edgecolor='black', linewidth=1.2)
        
        # Calcular estadísticas
        media = data.mean()
        mediana = data.median()
        q1 = data.quantile(0.25)
        q3 = data.quantile(0.75)
        skewness = stats.skew(data)
        
        # Agregar líneas de referencia
        ax.axvline(media, color='red', linestyle='--', linewidth=2.5, 
                   label=f'Promedio (Media): {media:.2f}', zorder=3)
        ax.axvline(mediana, color='green', linestyle='--', linewidth=2.5, 
                   label=f'Mediana: {mediana:.2f}', zorder=3)
        ax.axvline(q1, color='orange', linestyle=':', linewidth=2, alpha=0.8, 
                   label=f'Q1 (25%): {q1:.2f}', zorder=2)
        ax.axvline(q3, color='orange', linestyle=':', linewidth=2, alpha=0.8, 
                   label=f'Q3 (75%): {q3:.2f}', zorder=2)
        
        # Análisis de sesgo
        if abs(skewness) < 0.5:
            tipo_sesgo = "DISTRIBUCIÓN SIMÉTRICA"
            descripcion_sesgo = "Los datos están balanceados, con valores distribuidos de forma equilibrada alrededor del centro."
            interpretacion_negocio = self._interpretar_distribucion_simetrica(columna, tabla_nombre, media, mediana)
        elif skewness > 0.5:
            tipo_sesgo = "SESGADA A LA DERECHA (Positiva)"
            descripcion_sesgo = "La mayoría de los valores son pequeños, pero hay algunos valores muy grandes que 'arrastran' el promedio hacia la derecha."
            interpretacion_negocio = self._interpretar_distribucion_derecha(columna, tabla_nombre, media, mediana)
        else:
            tipo_sesgo = "SESGADA A LA IZQUIERDA (Negativa)"
            descripcion_sesgo = "La mayoría de los valores son grandes, pero hay algunos valores muy pequeños que 'arrastran' el promedio hacia la izquierda."
            interpretacion_negocio = self._interpretar_distribucion_izquierda(columna, tabla_nombre, media, mediana)
        
        # Configurar gráfico
        ax.set_title(f'Distribución de {columna} - {tabla_nombre}\n'
                    f'Tipo: {tipo_sesgo} | Sesgo: {skewness:.3f}', 
                    fontsize=14, fontweight='bold', pad=20)
        ax.set_xlabel(columna, fontsize=12, fontweight='bold')
        ax.set_ylabel('Frecuencia (Cantidad de veces que aparece)', fontsize=12, fontweight='bold')
        ax.grid(True, alpha=0.3, linestyle='--', axis='y')
        ax.legend(fontsize=9, loc='upper right', framealpha=0.9)
        
        # Agregar texto explicativo detallado
        texto_explicacion = f"""
📊 ANÁLISIS DE LA DISTRIBUCIÓN:
• Tipo de distribución: {tipo_sesgo}
• Medida de sesgo (Skewness): {skewness:.3f} {'(Simétrica)' if abs(skewness) < 0.5 else '(Sesgada a la derecha)' if skewness > 0.5 else '(Sesgada a la izquierda)'}
• {descripcion_sesgo}

💼 INTERPRETACIÓN PARA EL NEGOCIO:
{interpretacion_negocio}

📈 LECTURA DEL GRÁFICO:
• Las barras azules muestran cuántas veces aparece cada rango de valores
• La línea roja (promedio) está en {media:.2f} - es el valor promedio de todos los datos
• La línea verde (mediana) está en {mediana:.2f} - es el valor del medio (50% arriba, 50% abajo)
• Las líneas naranjas muestran Q1 ({q1:.2f}) y Q3 ({q3:.2f}) - el 50% central de los datos
• {'La mediana está a la IZQUIERDA del promedio → Más valores pequeños' if mediana < media else 'La mediana está a la DERECHA del promedio → Más valores grandes' if mediana > media else 'La mediana y el promedio están cerca → Distribución balanceada'}
        """
        
        # Crear texto en múltiples líneas para mejor legibilidad
        fig.text(0.5, -0.25, texto_explicacion, ha='center', fontsize=9, 
                style='normal', wrap=True, bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))
        
        plt.tight_layout()
        
        # Guardar
        filename = self.resultados_dir / f'histograma_{tabla_nombre}_{columna}.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"   ✅ Histograma guardado: {filename.name}")
        print(f"   📊 Tipo de distribución: {tipo_sesgo}")
        print(f"   📈 Sesgo: {skewness:.3f}")
        plt.close()
    
    def _interpretar_distribucion_simetrica(self, columna, tabla_nombre, media, mediana):
        """Interpretar distribución simétrica para el negocio."""
        interpretaciones = {
            'importe': f"Los importes de venta están distribuidos de forma equilibrada. Esto significa que hay una mezcla balanceada de ventas pequeñas, medianas y grandes. El promedio de ${media:.2f} es representativo de las ventas típicas.",
            'cantidad': f"Las cantidades vendidas están distribuidas de forma equilibrada. Hay una mezcla balanceada de pedidos pequeños y grandes. El promedio de {media:.2f} unidades representa bien las ventas típicas.",
            'precio_unitario': f"Los precios unitarios están distribuidos de forma equilibrada. Hay una mezcla balanceada de productos económicos y costosos. El precio promedio de ${media:.2f} es representativo del catálogo.",
            'id_venta': "Las ventas están distribuidas de forma equilibrada en el tiempo. No hay concentración excesiva en períodos específicos.",
            'id_cliente': "Los clientes están distribuidos de forma equilibrada. No hay concentración excesiva de ventas en pocos clientes.",
            'id_producto': "Los productos están distribuidos de forma equilibrada. No hay concentración excesiva de ventas en pocos productos."
        }
        
        # Buscar coincidencias parciales
        for key, value in interpretaciones.items():
            if key.lower() in columna.lower():
                return value
        
        return f"Los valores de {columna} están distribuidos de forma equilibrada. El promedio de {media:.2f} es representativo de los valores típicos en {tabla_nombre}."
    
    def _interpretar_distribucion_derecha(self, columna, tabla_nombre, media, mediana):
        """Interpretar distribución sesgada a la derecha para el negocio."""
        interpretaciones = {
            'importe': f"La mayoría de las ventas son de montos pequeños (mediana: ${mediana:.2f}), pero hay algunas ventas muy grandes que elevan el promedio a ${media:.2f}. Esto es TÍPICO en retail: muchas compras pequeñas y pocas compras grandes. Los clientes VIP o compras corporativas pueden estar causando este patrón.",
            'cantidad': f"La mayoría de los pedidos son de pocas unidades (mediana: {mediana:.2f}), pero hay algunos pedidos muy grandes que elevan el promedio a {media:.2f}. Esto sugiere que la mayoría de clientes compra poco, pero algunos hacen pedidos grandes (posiblemente mayoristas o compras corporativas).",
            'precio_unitario': f"La mayoría de los productos tienen precios bajos (mediana: ${mediana:.2f}), pero hay algunos productos muy costosos que elevan el promedio a ${media:.2f}. Esto es normal: muchos productos económicos y pocos productos premium o de lujo.",
            'id_venta': "La mayoría de las ventas ocurren en períodos normales, pero hay algunos períodos con muchas ventas (posiblemente temporadas altas, promociones o eventos especiales).",
            'id_cliente': "La mayoría de los clientes hacen pocas compras, pero hay algunos clientes muy activos (clientes VIP o frecuentes) que generan muchas ventas.",
            'id_producto': "La mayoría de los productos se venden poco, pero hay algunos productos estrella (best sellers) que se venden mucho más que el resto."
        }
        
        for key, value in interpretaciones.items():
            if key.lower() in columna.lower():
                return value
        
        return f"La mayoría de los valores de {columna} son pequeños (mediana: {mediana:.2f}), pero hay algunos valores muy grandes que elevan el promedio a {media:.2f}. Esto es común en datos de negocio: muchos casos normales y pocos casos excepcionales."
    
    def _interpretar_distribucion_izquierda(self, columna, tabla_nombre, media, mediana):
        """Interpretar distribución sesgada a la izquierda para el negocio."""
        interpretaciones = {
            'importe': f"La mayoría de las ventas son de montos grandes (mediana: ${mediana:.2f}), pero hay algunas ventas muy pequeñas que reducen el promedio a ${media:.2f}. Esto puede indicar que el negocio se enfoca en ventas de mayor valor, con pocas ventas pequeñas (posiblemente promociones o productos de entrada).",
            'cantidad': f"La mayoría de los pedidos son de muchas unidades (mediana: {mediana:.2f}), pero hay algunos pedidos muy pequeños que reducen el promedio a {media:.2f}. Esto sugiere que el negocio se enfoca en pedidos grandes, posiblemente mayoristas o B2B.",
            'precio_unitario': f"La mayoría de los productos tienen precios altos (mediana: ${mediana:.2f}), pero hay algunos productos muy económicos que reducen el promedio a ${media:.2f}. Esto indica un catálogo premium con algunos productos de entrada.",
            'id_venta': "La mayoría de las ventas ocurren en períodos de alta actividad, con pocos períodos de baja actividad.",
            'id_cliente': "La mayoría de los clientes hacen muchas compras, con pocos clientes ocasionales.",
            'id_producto': "La mayoría de los productos se venden bien, con pocos productos de bajo movimiento."
        }
        
        for key, value in interpretaciones.items():
            if key.lower() in columna.lower():
                return value
        
        return f"La mayoría de los valores de {columna} son grandes (mediana: {mediana:.2f}), pero hay algunos valores muy pequeños que reducen el promedio a {media:.2f}. Esto puede indicar un enfoque en valores altos con pocos casos de bajo valor."
    
    def crear_boxplot_variable(self, data, columna, tabla_nombre):
        """Crear boxplot para una variable con explicación clara."""
        print(f"📦 Generando boxplot para {columna}...")
        
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Crear boxplot
        bp = ax.boxplot([data], vert=True, patch_artist=True,
                       boxprops=dict(facecolor='lightblue', alpha=0.7),
                       medianprops=dict(color='red', linewidth=2),
                       whiskerprops=dict(color='black', linewidth=1.5),
                       capprops=dict(color='black', linewidth=1.5))
        
        # Agregar puntos de outliers
        q1 = data.quantile(0.25)
        q3 = data.quantile(0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        outliers = data[(data < lower_bound) | (data > upper_bound)]
        
        if len(outliers) > 0:
            ax.scatter([1] * len(outliers), outliers, color='red', 
                      alpha=0.6, s=50, zorder=3, label=f'Outliers ({len(outliers)})')
        
        # Configurar gráfico
        ax.set_title(f'Boxplot de {columna} - {tabla_nombre}\n'
                    f'(Visualización de distribución y valores atípicos)', 
                    fontsize=14, fontweight='bold', pad=20)
        ax.set_ylabel(columna, fontsize=12)
        ax.set_xticklabels([columna])
        ax.grid(True, alpha=0.3, axis='y', linestyle='--')
        if len(outliers) > 0:
            ax.legend(fontsize=10)
        
        # Agregar anotaciones
        ax.text(1.15, q1, f'Q1: {q1:.2f}', fontsize=9, verticalalignment='center')
        ax.text(1.15, data.median(), f'Mediana: {data.median():.2f}', 
               fontsize=9, verticalalignment='center')
        ax.text(1.15, q3, f'Q3: {q3:.2f}', fontsize=9, verticalalignment='center')
        
        # Calcular estadísticas para interpretación
        total = len(data)
        porcentaje_outliers = (len(outliers) / total * 100) if total > 0 else 0
        
        # Agregar texto explicativo detallado
        texto_explicacion = f"""
INTERPRETACIÓN ESPECÍFICA:
• Total de registros analizados: {total}
• OUTLIERS detectados: {len(outliers)} ({porcentaje_outliers:.1f}% del total)
• Rango normal (Q1-Q3): [{q1:.2f}, {q3:.2f}], Mediana: {data.median():.2f}
• Límites de outliers: [{lower_bound:.2f}, {upper_bound:.2f}]
• Rango total de datos: [{data.min():.2f}, {data.max():.2f}]

💡 INTERPRETACIÓN DEL BOXPLOT:
• La caja azul muestra el 50% central de los datos (entre Q1 y Q3)
• La línea roja en el medio es la mediana (valor del medio) = {data.median():.2f}
• Los "bigotes" muestran el rango normal de los datos
• Los puntos rojos son valores atípicos (outliers) que están fuera del rango normal
• {'⚠️ Hay muchos outliers - Revisar si son errores o casos especiales' if porcentaje_outliers > 5 else '✓ Proporción normal de outliers' if porcentaje_outliers > 0 else '✓ No se detectaron outliers'}
        """
        fig.text(0.5, -0.25, texto_explicacion, ha='center', fontsize=9, 
                style='normal', wrap=True, bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))
        
        plt.tight_layout()
        
        # Guardar
        filename = self.resultados_dir / f'boxplot_{tabla_nombre}_{columna}.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"   ✅ Boxplot guardado: {filename.name}")
        plt.close()
    
    def analizar_outliers_detallado(self, data, columna):
        """
        Análisis detallado de outliers con explicaciones claras.
        """
        print(f"\n🔍 ANÁLISIS DETALLADO DE OUTLIERS:")
        print("-" * 60)
        
        # Método IQR
        q1 = data.quantile(0.25)
        q3 = data.quantile(0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        
        outliers_iqr = data[(data < lower_bound) | (data > upper_bound)]
        
        # Método Z-score
        z_scores = np.abs(stats.zscore(data))
        outliers_zscore = data[z_scores > 3]
        
        print(f"\n💡 ¿QUÉ SON LOS OUTLIERS?")
        print("""
Los outliers (valores atípicos) son valores que están muy lejos del resto de los datos.
Por ejemplo, si la mayoría de las ventas son de $100, pero hay una de $10,000, 
esa venta de $10,000 es un outlier.

Los outliers pueden ser:
• Errores de datos (valores incorrectos que necesitan corrección)
• Oportunidades (clientes muy valiosos o productos muy exitosos)
• Casos especiales que necesitan atención particular
        """)
        
        print(f"\n📊 RESULTADOS DEL ANÁLISIS:")
        print(f"   • Método IQR (Rango Intercuartílico):")
        print(f"     - Límite inferior: {lower_bound:.2f}")
        print(f"     - Límite superior: {upper_bound:.2f}")
        print(f"     - Outliers detectados: {len(outliers_iqr)} ({len(outliers_iqr)/len(data)*100:.2f}%)")
        
        if len(outliers_iqr) > 0:
            print(f"     - Rango de outliers: [{outliers_iqr.min():.2f}, {outliers_iqr.max():.2f}]")
            print(f"     - Valores de outliers (primeros 10):")
            for i, val in enumerate(outliers_iqr.head(10), 1):
                print(f"       {i}. {val:.2f}")
        
        print(f"\n   • Método Z-Score (Desviaciones estándar):")
        print(f"     - Outliers detectados: {len(outliers_zscore)} ({len(outliers_zscore)/len(data)*100:.2f}%)")
        
        if len(outliers_zscore) > 0:
            print(f"     - Rango de outliers: [{outliers_zscore.min():.2f}, {outliers_zscore.max():.2f}]")
        
        # Recomendaciones
        print(f"\n💡 RECOMENDACIONES:")
        if len(outliers_iqr) > len(data) * 0.05:  # Más del 5%
            print(f"   ⚠️  Hay muchos outliers ({len(outliers_iqr)/len(data)*100:.1f}%)")
            print(f"      → Revisar si son errores de datos")
            print(f"      → Considerar si son casos especiales que necesitan análisis separado")
        elif len(outliers_iqr) > 0:
            print(f"   ✓ Hay algunos outliers ({len(outliers_iqr)/len(data)*100:.1f}%)")
            print(f"      → Revisar individualmente para entender su origen")
            print(f"      → Pueden ser oportunidades o casos especiales")
        else:
            print(f"   ✓ No se detectaron outliers significativos")
            print(f"      → Los datos están dentro de rangos normales")
        
        return {
            'metodo_iqr': {
                'count': len(outliers_iqr),
                'percentage': len(outliers_iqr)/len(data)*100,
                'lower_bound': lower_bound,
                'upper_bound': upper_bound,
                'values': outliers_iqr.tolist()[:20]  # Primeros 20
            },
            'metodo_zscore': {
                'count': len(outliers_zscore),
                'percentage': len(outliers_zscore)/len(data)*100,
                'values': outliers_zscore.tolist()[:20]
            }
        }
    
    def analisis_medios_pago_completo(self):
        """
        Análisis estadístico completo de medios de pago y su relación
        con clientes y ventas. Incluye explicaciones claras.
        """
        print("\n" + "=" * 80)
        print("💳 ANÁLISIS ESTADÍSTICO COMPLETO: MEDIOS DE PAGO")
        print("=" * 80)
        
        print("\n💡 ¿POR QUÉ ANALIZAR LOS MEDIOS DE PAGO?")
        print("-" * 80)
        print("""
Los medios de pago nos dicen mucho sobre cómo los clientes prefieren comprar.
Algunas preguntas importantes son:

1. ¿Qué método de pago usan más los clientes?
2. ¿Los clientes que usan diferentes métodos de pago compran montos diferentes?
3. ¿Hay relación entre el método de pago y el tipo de cliente?
4. ¿Algunos métodos de pago están asociados con ventas más grandes?

Entender esto nos ayuda a:
• Optimizar los métodos de pago ofrecidos
• Entender el comportamiento de los clientes
• Identificar oportunidades de negocio
        """)
        
        # Verificar que tenemos las tablas necesarias
        if 'ventas' not in self.tablas or 'detalle_ventas' not in self.tablas:
            print("❌ Error: Faltan tablas necesarias para el análisis")
            return
        
        df_ventas = self.tablas['ventas'].copy()
        df_detalle = self.tablas['detalle_ventas'].copy()
        df_clientes = self.tablas['clientes'].copy()
        
        if 'medio_pago' not in df_ventas.columns:
            print("❌ Error: No se encuentra la columna 'medio_pago'")
            return
        
        # Merge de tablas para análisis completo
        df_completo = df_ventas.merge(df_detalle, on='id_venta', how='inner')
        df_completo = df_completo.merge(df_clientes, on='id_cliente', how='left')
        
        # 1. DISTRIBUCIÓN DE VENTAS POR MÉTODO DE PAGO
        print("\n" + "-" * 80)
        print("1️⃣  DISTRIBUCIÓN DE VENTAS POR MÉTODO DE PAGO")
        print("-" * 80)
        
        distribucion = df_ventas['medio_pago'].value_counts().sort_values(ascending=False)
        total_ventas = len(df_ventas)
        
        print(f"\n📊 RESUMEN:")
        print(f"   Total de ventas analizadas: {total_ventas}")
        print(f"\n📈 Distribución por método de pago:")
        
        for metodo, cantidad in distribucion.items():
            porcentaje = (cantidad / total_ventas) * 100
            print(f"   • {metodo.upper()}:")
            print(f"     - Cantidad de ventas: {cantidad}")
            print(f"     - Porcentaje: {porcentaje:.2f}%")
            print(f"     - Interpretación: {'Muy usado' if porcentaje > 30 else 'Moderadamente usado' if porcentaje > 15 else 'Poco usado'}")
        
        # Crear gráfico de barras
        self.crear_grafico_medios_pago(distribucion, "Distribución de Ventas por Método de Pago")
        
        # 2. ANÁLISIS DE MONTOS POR MÉTODO DE PAGO
        print("\n" + "-" * 80)
        print("2️⃣  ANÁLISIS DE MONTOS POR MÉTODO DE PAGO")
        print("-" * 80)
        
        print("\n💡 ¿QUÉ SIGNIFICA ESTO?")
        print("""
Analizamos si los clientes que usan diferentes métodos de pago gastan
cantidades diferentes. Por ejemplo:
• ¿Los que pagan con tarjeta gastan más que los que pagan en efectivo?
• ¿Hay diferencias significativas entre métodos?
        """)
        
        montos_por_metodo = df_completo.groupby('medio_pago')['importe'].agg([
            'count', 'sum', 'mean', 'median', 'std', 'min', 'max'
        ]).round(2)
        montos_por_metodo.columns = ['Cantidad', 'Total', 'Promedio', 'Mediana', 
                                     'Desv. Estándar', 'Mínimo', 'Máximo']
        montos_por_metodo = montos_por_metodo.sort_values('Total', ascending=False)
        
        print(f"\n📊 ESTADÍSTICAS DE IMPORTES POR MÉTODO DE PAGO:")
        print(montos_por_metodo.to_string())
        
        # Crear boxplot comparativo
        self.crear_boxplot_medios_pago(df_completo)
        
        # 3. ANÁLISIS ESTADÍSTICO DETALLADO
        print("\n" + "-" * 80)
        print("3️⃣  ANÁLISIS ESTADÍSTICO DETALLADO POR MÉTODO DE PAGO")
        print("-" * 80)
        
        estadisticas_detalladas = {}
        
        for metodo in df_ventas['medio_pago'].unique():
            importes_metodo = df_completo[df_completo['medio_pago'] == metodo]['importe']
            
            if len(importes_metodo) == 0:
                continue
            
            print(f"\n📊 {metodo.upper()}:")
            print("-" * 60)
            
            # Estadísticas básicas
            print(f"   Cantidad de transacciones: {len(importes_metodo)}")
            print(f"   Total vendido: ${importes_metodo.sum():,.2f}")
            print(f"   Promedio por transacción: ${importes_metodo.mean():.2f}")
            print(f"   Mediana: ${importes_metodo.median():.2f}")
            print(f"   Desviación estándar: ${importes_metodo.std():.2f}")
            print(f"   Mínimo: ${importes_metodo.min():.2f}")
            print(f"   Máximo: ${importes_metodo.max():.2f}")
            
            # Análisis de forma
            skewness = stats.skew(importes_metodo)
            kurtosis = stats.kurtosis(importes_metodo)
            
            print(f"\n   📐 Análisis de distribución:")
            print(f"   • Asimetría (Skewness): {skewness:.3f}")
            if abs(skewness) < 0.5:
                print(f"     → Distribución balanceada (simétrica)")
            elif skewness > 0.5:
                print(f"     → Sesgada a la derecha (más valores pequeños, algunos muy grandes)")
            else:
                print(f"     → Sesgada a la izquierda (más valores grandes, algunos muy pequeños)")
            
            print(f"   • Curtosis: {kurtosis:.3f}")
            if abs(kurtosis) < 0.5:
                print(f"     → Distribución normal")
            elif kurtosis > 0.5:
                print(f"     → Distribución con picos altos (valores concentrados)")
            else:
                print(f"     → Distribución plana (valores dispersos)")
            
            # Outliers
            q1 = importes_metodo.quantile(0.25)
            q3 = importes_metodo.quantile(0.75)
            iqr = q3 - q1
            outliers = importes_metodo[(importes_metodo < q1 - 1.5*iqr) | 
                                      (importes_metodo > q3 + 1.5*iqr)]
            
            print(f"\n   🔍 Valores atípicos (Outliers):")
            print(f"   • Cantidad: {len(outliers)} ({len(outliers)/len(importes_metodo)*100:.2f}%)")
            if len(outliers) > 0:
                print(f"   • Rango: ${outliers.min():.2f} - ${outliers.max():.2f}")
            
            estadisticas_detalladas[metodo] = {
                'count': len(importes_metodo),
                'total': importes_metodo.sum(),
                'mean': importes_metodo.mean(),
                'median': importes_metodo.median(),
                'std': importes_metodo.std(),
                'skewness': skewness,
                'kurtosis': kurtosis,
                'outliers_count': len(outliers)
            }
        
        # 4. RELACIÓN CON CLIENTES
        print("\n" + "-" * 80)
        print("4️⃣  RELACIÓN ENTRE MÉTODOS DE PAGO Y CLIENTES")
        print("-" * 80)
        
        print("\n💡 ¿QUÉ CLIENTES USAN QUÉ MÉTODOS DE PAGO?")
        print("""
Analizamos si hay patrones en qué tipo de clientes usan cada método de pago.
Esto nos ayuda a entender el perfil de nuestros clientes.
        """)
        
        # Clientes por método de pago
        clientes_por_metodo = df_completo.groupby('medio_pago')['id_cliente'].nunique()
        ventas_por_cliente_metodo = df_completo.groupby('medio_pago')['id_cliente'].count() / clientes_por_metodo
        
        print(f"\n📊 ANÁLISIS DE CLIENTES:")
        for metodo in df_ventas['medio_pago'].unique():
            if metodo not in clientes_por_metodo.index:
                continue
            
            num_clientes = clientes_por_metodo[metodo]
            ventas_promedio = ventas_por_cliente_metodo[metodo]
            
            print(f"\n   {metodo.upper()}:")
            print(f"   • Número de clientes únicos: {num_clientes}")
            print(f"   • Ventas promedio por cliente: {ventas_promedio:.2f}")
            print(f"   • Interpretación: ", end="")
            if ventas_promedio > 2:
                print("Clientes frecuentes (compran varias veces)")
            elif ventas_promedio > 1.5:
                print("Clientes moderadamente frecuentes")
            else:
                print("Clientes ocasionales")
        
        # Análisis por ciudad (si está disponible)
        if 'ciudad' in df_completo.columns:
            print(f"\n📊 ANÁLISIS POR CIUDAD:")
            ciudad_metodo = df_completo.groupby(['ciudad', 'medio_pago']).size().unstack(fill_value=0)
            print(f"\n   Top 5 ciudades por método de pago:")
            for metodo in df_ventas['medio_pago'].unique():
                if metodo in ciudad_metodo.columns:
                    top_ciudades = ciudad_metodo[metodo].nlargest(5)
                    print(f"\n   {metodo.upper()}:")
                    for ciudad, cantidad in top_ciudades.items():
                        print(f"     • {ciudad}: {cantidad} ventas")
        
        # 5. PRUEBAS ESTADÍSTICAS
        print("\n" + "-" * 80)
        print("5️⃣  PRUEBAS ESTADÍSTICAS: ¿HAY DIFERENCIAS SIGNIFICATIVAS?")
        print("-" * 80)
        
        print("\n💡 ¿QUÉ SON LAS PRUEBAS ESTADÍSTICAS?")
        print("""
Las pruebas estadísticas nos ayudan a determinar si las diferencias que vemos
entre grupos (por ejemplo, entre métodos de pago) son reales o solo casualidad.

Si la prueba dice que hay diferencias significativas, significa que:
• Las diferencias son reales y no solo casualidad
• Podemos confiar en que los métodos de pago realmente se comportan diferente
        """)
        
        # Test de Kruskal-Wallis (no paramétrico, para comparar múltiples grupos)
        grupos = [df_completo[df_completo['medio_pago'] == metodo]['importe'].values 
                 for metodo in df_ventas['medio_pago'].unique()]
        grupos = [g for g in grupos if len(g) > 0]  # Filtrar grupos vacíos
        
        if len(grupos) > 2:
            try:
                h_stat, p_value = stats.kruskal(*grupos)
                print(f"\n📊 Test de Kruskal-Wallis (Comparación de todos los métodos):")
                print(f"   • Estadístico H: {h_stat:.4f}")
                print(f"   • P-valor: {p_value:.4f}")
                print(f"   • Interpretación: ", end="")
                if p_value < 0.05:
                    print("✓ HAY diferencias significativas entre métodos de pago")
                    print(f"     → Los métodos de pago tienen comportamientos diferentes")
                    print(f"     → Podemos confiar en que las diferencias son reales")
                else:
                    print("✗ NO hay diferencias significativas")
                    print(f"     → Los métodos de pago se comportan de forma similar")
            except Exception as e:
                print(f"   ⚠️  No se pudo realizar la prueba: {e}")
        
        # Comparaciones por pares
        print(f"\n📊 Comparaciones por pares (¿Cuáles métodos son diferentes?):")
        metodos = df_ventas['medio_pago'].unique()
        for i, metodo1 in enumerate(metodos):
            for metodo2 in metodos[i+1:]:
                grupo1 = df_completo[df_completo['medio_pago'] == metodo1]['importe']
                grupo2 = df_completo[df_completo['medio_pago'] == metodo2]['importe']
                
                if len(grupo1) > 0 and len(grupo2) > 0:
                    try:
                        u_stat, p_val = stats.mannwhitneyu(grupo1, grupo2, alternative='two-sided')
                        print(f"\n   {metodo1.upper()} vs {metodo2.upper()}:")
                        print(f"     • P-valor: {p_val:.4f}")
                        if p_val < 0.05:
                            diff = grupo1.mean() - grupo2.mean()
                            print(f"     • ✓ DIFERENTES (diferencia promedio: ${diff:.2f})")
                        else:
                            print(f"     • ✗ Similares (no hay diferencia significativa)")
                    except:
                        pass
        
        self.resultados['medios_pago'] = {
            'distribucion': distribucion.to_dict(),
            'estadisticas_detalladas': estadisticas_detalladas,
            'clientes_por_metodo': clientes_por_metodo.to_dict()
        }
        
        input("\n⏸️  Presiona Enter para continuar...")
    
    def crear_grafico_medios_pago(self, distribucion, titulo):
        """Crear gráfico de barras para distribución de medios de pago."""
        fig, ax = plt.subplots(figsize=(12, 6))
        
        colores = sns.color_palette("husl", len(distribucion))
        bars = ax.bar(distribucion.index, distribucion.values, color=colores, 
                     edgecolor='black', linewidth=1.5, alpha=0.8)
        
        # Agregar valores en las barras
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{int(height)}\n({height/len(self.tablas["ventas"])*100:.1f}%)',
                   ha='center', va='bottom', fontsize=10, fontweight='bold')
        
        ax.set_title(titulo + '\n(¿Qué método de pago prefieren los clientes?)', 
                    fontsize=14, fontweight='bold', pad=20)
        ax.set_xlabel('Método de Pago', fontsize=12)
        ax.set_ylabel('Cantidad de Ventas', fontsize=12)
        ax.grid(True, alpha=0.3, axis='y', linestyle='--')
        
        plt.xticks(rotation=45, ha='right')
        
        # Calcular estadísticas para interpretación
        total_ventas = len(self.tablas["ventas"])
        metodo_mas_usado = distribucion.idxmax()
        metodo_menos_usado = distribucion.idxmin()
        frecuencia_max = distribucion.max()
        frecuencia_min = distribucion.min()
        porcentaje_max = frecuencia_max/total_ventas*100
        porcentaje_min = frecuencia_min/total_ventas*100
        
        interpretacion_lineas = ["INTERPRETACIÓN ESPECÍFICA:"]
        interpretacion_lineas.append(f"• Total de ventas analizadas: {total_ventas}")
        interpretacion_lineas.append(f"• MÉTODO MÁS USADO: '{metodo_mas_usado}' con {frecuencia_max} ventas ({porcentaje_max:.1f}% del total)")
        interpretacion_lineas.append(f"• MÉTODO MENOS USADO: '{metodo_menos_usado}' con {frecuencia_min} ventas ({porcentaje_min:.1f}% del total)")
        interpretacion_lineas.append(f"• Diferencia: {frecuencia_max - frecuencia_min} ventas ({porcentaje_max - porcentaje_min:.1f} puntos porcentuales)")
        interpretacion_lineas.append(f"• CONCLUSIÓN: '{metodo_mas_usado}' es {frecuencia_max/frecuencia_min:.1f}x más usado que '{metodo_menos_usado}'")
        interpretacion_lineas.append(f"\n¿QUÉ SIGNIFICA PARA EL NEGOCIO?")
        interpretacion_lineas.append(f"  • '{metodo_mas_usado}' es el método preferido por los clientes")
        interpretacion_lineas.append(f"  • Se debe asegurar que este método funcione perfectamente")
        interpretacion_lineas.append(f"  • '{metodo_menos_usado}' tiene potencial de crecimiento")
        interpretacion_lineas.append(f"  • Considerar promociones o incentivos para aumentar su uso")
        
        interpretacion = "\n".join(interpretacion_lineas)
        fig.text(0.5, 0.01, interpretacion, ha='center', fontsize=8,
                bbox=dict(boxstyle='round', facecolor='lightcoral', alpha=0.8),
                wrap=True)
        
        plt.tight_layout()
        plt.subplots_adjust(bottom=0.25)
        
        filename = self.resultados_dir / 'distribucion_medios_pago.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"\n   ✅ Gráfico guardado: {filename.name}")
        plt.close()
    
    def crear_boxplot_medios_pago(self, df_completo):
        """Crear boxplot comparativo de importes por método de pago."""
        print(f"\n📦 Generando boxplot comparativo de importes por método de pago...")
        
        fig, ax = plt.subplots(figsize=(14, 8))
        
        metodos = df_completo['medio_pago'].unique()
        data_para_boxplot = [df_completo[df_completo['medio_pago'] == metodo]['importe'].values 
                            for metodo in metodos]
        
        # Calcular estadísticas para interpretación
        estadisticas_metodos = {}
        for metodo in metodos:
            datos_metodo = df_completo[df_completo['medio_pago'] == metodo]['importe']
            estadisticas_metodos[metodo] = {
                'media': datos_metodo.mean(),
                'mediana': datos_metodo.median(),
                'q1': datos_metodo.quantile(0.25),
                'q3': datos_metodo.quantile(0.75),
                'min': datos_metodo.min(),
                'max': datos_metodo.max(),
                'count': len(datos_metodo)
            }
        
        bp = ax.boxplot(data_para_boxplot, labels=metodos, patch_artist=True,
                       boxprops=dict(facecolor='lightblue', alpha=0.7),
                       medianprops=dict(color='red', linewidth=2),
                       whiskerprops=dict(color='black', linewidth=1.5))
        
        ax.set_title('Comparación de Importes por Método de Pago\n'
                    '(¿Los clientes gastan diferente según cómo pagan?)', 
                    fontsize=14, fontweight='bold', pad=20)
        ax.set_xlabel('Método de Pago', fontsize=12)
        ax.set_ylabel('Importe ($)', fontsize=12)
        ax.grid(True, alpha=0.3, axis='y', linestyle='--')
        
        plt.xticks(rotation=45, ha='right')
        
        # Crear interpretación específica
        metodo_mayor_promedio = max(estadisticas_metodos.items(), key=lambda x: x[1]['media'])
        metodo_menor_promedio = min(estadisticas_metodos.items(), key=lambda x: x[1]['media'])
        metodo_mayor_mediana = max(estadisticas_metodos.items(), key=lambda x: x[1]['mediana'])
        
        interpretacion_lineas = ["INTERPRETACIÓN ESPECÍFICA:"]
        interpretacion_lineas.append(f"• Total de métodos de pago analizados: {len(metodos)}")
        interpretacion_lineas.append(f"\nCOMPARACIÓN DE IMPORTES:")
        interpretacion_lineas.append(f"  • MÉTODO CON MAYOR PROMEDIO: '{metodo_mayor_promedio[0]}'")
        interpretacion_lineas.append(f"    - Promedio: ${metodo_mayor_promedio[1]['media']:.2f} por transacción")
        interpretacion_lineas.append(f"    - Mediana: ${metodo_mayor_promedio[1]['mediana']:.2f}")
        interpretacion_lineas.append(f"    - Rango: ${metodo_mayor_promedio[1]['min']:.2f} - ${metodo_mayor_promedio[1]['max']:.2f}")
        interpretacion_lineas.append(f"  • MÉTODO CON MENOR PROMEDIO: '{metodo_menor_promedio[0]}'")
        interpretacion_lineas.append(f"    - Promedio: ${metodo_menor_promedio[1]['media']:.2f} por transacción")
        interpretacion_lineas.append(f"    - Mediana: ${metodo_menor_promedio[1]['mediana']:.2f}")
        
        diferencia = metodo_mayor_promedio[1]['media'] - metodo_menor_promedio[1]['media']
        interpretacion_lineas.append(f"  • Diferencia: ${diferencia:.2f} ({diferencia/metodo_menor_promedio[1]['media']*100:.1f}% más)")
        
        interpretacion_lineas.append(f"\n¿QUÉ SIGNIFICA ESTO?")
        interpretacion_lineas.append(f"  • La caja azul muestra el 50% central de los importes (entre Q1 y Q3)")
        interpretacion_lineas.append(f"  • La línea roja es la mediana (valor del medio)")
        interpretacion_lineas.append(f"  • Los 'bigotes' muestran el rango normal de importes")
        interpretacion_lineas.append(f"  • Los puntos fuera de los bigotes son valores atípicos (outliers)")
        interpretacion_lineas.append(f"  • Si las cajas NO se superponen: Hay diferencia significativa entre métodos")
        interpretacion_lineas.append(f"  • Si las cajas SÍ se superponen: Los métodos pueden ser similares")
        
        interpretacion_lineas.append(f"\nCONCLUSIÓN:")
        interpretacion_lineas.append(f"  • Los clientes que usan '{metodo_mayor_promedio[0]}' gastan más por transacción")
        interpretacion_lineas.append(f"  • Se recomienda investigar por qué hay esta diferencia")
        interpretacion_lineas.append(f"  • Considerar estrategias para aumentar el ticket promedio en otros métodos")
        
        interpretacion = "\n".join(interpretacion_lineas)
        fig.text(0.5, 0.01, interpretacion, ha='center', fontsize=7,
                bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.9),
                wrap=True)
        
        plt.tight_layout()
        plt.subplots_adjust(bottom=0.30)
        
        filename = self.resultados_dir / 'boxplot_importes_medios_pago.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"   ✅ Boxplot guardado: {filename.name}")
        plt.close()
    
    def generar_recomendaciones(self):
        """
        Generar recomendaciones basadas en los análisis realizados.
        Con explicaciones claras para personas sin conocimiento técnico.
        """
        print("\n" + "=" * 80)
        print("💡 RECOMENDACIONES BASADAS EN EL ANÁLISIS")
        print("=" * 80)
        
        print("\n📋 RESUMEN DE HALLAZGOS:")
        print("-" * 80)
        
        # Recomendaciones sobre medios de pago
        if 'medios_pago' in self.resultados:
            medios_pago = self.resultados['medios_pago']
            distribucion = medios_pago['distribucion']
            metodo_mas_usado = max(distribucion.items(), key=lambda x: x[1])
            
            print(f"\n💳 SOBRE MEDIOS DE PAGO:")
            print(f"   • El método más usado es: {metodo_mas_usado[0].upper()}")
            print(f"     → Representa el {metodo_mas_usado[1]/sum(distribucion.values())*100:.1f}% de las ventas")
            print(f"     → Recomendación: Asegurar que este método funcione perfectamente")
            
            # Analizar diferencias en montos
            estadisticas = medios_pago['estadisticas_detalladas']
            if len(estadisticas) > 1:
                promedios = {k: v['mean'] for k, v in estadisticas.items()}
                metodo_mayor_promedio = max(promedios.items(), key=lambda x: x[1])
                metodo_menor_promedio = min(promedios.items(), key=lambda x: x[1])
                
                diferencia = metodo_mayor_promedio[1] - metodo_menor_promedio[1]
                if diferencia > metodo_menor_promedio[1] * 0.2:  # Más del 20% de diferencia
                    print(f"\n   • Diferencia en montos promedio:")
                    print(f"     → {metodo_mayor_promedio[0].upper()} tiene promedio de ${metodo_mayor_promedio[1]:.2f}")
                    print(f"     → {metodo_menor_promedio[0].upper()} tiene promedio de ${metodo_menor_promedio[1]:.2f}")
                    print(f"     → Diferencia: ${diferencia:.2f} ({diferencia/metodo_menor_promedio[1]*100:.1f}% más)")
                    print(f"     → Recomendación: Investigar por qué hay esta diferencia")
                    print(f"       - ¿Los clientes que usan {metodo_mayor_promedio[0]} compran productos más caros?")
                    print(f"       - ¿Hay oportunidades de promoción para {metodo_menor_promedio[0]}?")
        
        # Recomendaciones sobre outliers
        if 'variables_comunes' in self.resultados:
            print(f"\n🔍 SOBRE VALORES ATÍPICOS (OUTLIERS):")
            total_outliers = 0
            variables_con_outliers = []
            
            for var_name, var_data in self.resultados['variables_comunes'].items():
                if 'outliers' in var_data:
                    outliers_iqr = var_data['outliers'].get('metodo_iqr', {})
                    if outliers_iqr.get('count', 0) > 0:
                        total_outliers += outliers_iqr['count']
                        variables_con_outliers.append((var_name, outliers_iqr['count']))
            
            if variables_con_outliers:
                print(f"   • Se encontraron valores atípicos en {len(variables_con_outliers)} variables")
                print(f"   • Variables con más outliers:")
                for var_name, count in sorted(variables_con_outliers, key=lambda x: x[1], reverse=True)[:3]:
                    print(f"     → {var_name}: {count} valores atípicos")
                print(f"   • Recomendación: Revisar estos valores para entender si son:")
                print(f"     - Errores de datos (corregir)")
                print(f"     - Oportunidades de negocio (clientes VIP, productos estrella)")
                print(f"     - Casos especiales que requieren atención particular")
            else:
                print(f"   • ✓ No se encontraron valores atípicos significativos")
                print(f"   • Los datos están dentro de rangos normales")
        
        print("\n" + "-" * 80)
        print("🎯 RECOMENDACIONES GENERALES:")
        print("-" * 80)
        print("""
1. MONITOREO CONTINUO:
   → Establecer un sistema de monitoreo de las métricas clave identificadas
   → Revisar periódicamente los valores atípicos para detectar tendencias

2. SEGMENTACIÓN DE CLIENTES:
   → Usar los análisis de medios de pago para segmentar clientes
   → Crear estrategias de marketing dirigidas a cada segmento

3. OPTIMIZACIÓN DE MÉTODOS DE PAGO:
   → Priorizar los métodos de pago más usados
   → Investigar oportunidades para promover métodos menos usados pero con mayor ticket promedio

4. ANÁLISIS DE OUTLIERS:
   → Revisar regularmente los valores atípicos
   → Identificar si representan oportunidades o problemas

5. CONTINUIDAD DEL ANÁLISIS:
   → Realizar este análisis periódicamente para detectar cambios
   → Comparar resultados entre períodos para identificar tendencias
        """)
        
        input("\n⏸️  Presiona Enter para finalizar...")
    
    def ejecutar_analisis_completo(self):
        """Ejecutar el análisis estadístico completo."""
        print("\n" + "=" * 80)
        print("🚀 INICIANDO ANÁLISIS ESTADÍSTICO COMPLETO Y PROFESIONAL")
        print("=" * 80)
        print("\nEste análisis incluye:")
        print("  ✓ Presentación del problema e hipótesis")
        print("  ✓ Análisis de variables comunes con histogramas y boxplots")
        print("  ✓ Análisis detallado de outliers")
        print("  ✓ Análisis estadístico completo de medios de pago")
        print("  ✓ Relación entre medios de pago, clientes y ventas")
        print("  ✓ Recomendaciones basadas en datos")
        print("  ✓ Explicaciones claras para todos los niveles")
        
        # Cargar datos
        if not self.cargar_datos():
            return
        
        # Presentar problema e hipótesis
        self.presentar_problema_e_hipotesis()
        
        # Análisis de variables comunes
        self.analisis_variables_comunes()
        
        # Análisis de medios de pago
        self.analisis_medios_pago_completo()
        
        # Generar recomendaciones
        self.generar_recomendaciones()
        
        print("\n" + "=" * 80)
        print("✅ ANÁLISIS ESTADÍSTICO COMPLETO FINALIZADO")
        print("=" * 80)
        print(f"\n📁 Todos los gráficos se guardaron en: {self.resultados_dir}")
        print("\n💡 RECUERDA:")
        print("   • Revisa los gráficos generados para visualizar los resultados")
        print("   • Las recomendaciones están basadas en los datos analizados")
        print("   • Usa estos insights para tomar decisiones informadas")

if __name__ == "__main__":
    analizador = AnalisisCompletoEstadistico()
    analizador.ejecutar_analisis_completo()

