# Estadística Aplicada - Análisis Completo y Profesional

## 📋 Descripción

Este módulo contiene análisis estadísticos completos y profesionales diseñados para ser entendidos por personas sin conocimiento previo de estadística. Incluye explicaciones claras, visualizaciones detalladas y recomendaciones basadas en datos.

## 🎯 Objetivos

- Aplicar estadística descriptiva básica y avanzada
- Analizar distribuciones de datos con explicaciones claras
- Calcular y visualizar correlaciones entre variables
- Generar histogramas y boxplots para todas las variables importantes
- Analizar valores atípicos (outliers) de forma detallada
- Realizar análisis estadístico completo de medios de pago
- Analizar la relación entre medios de pago, clientes y ventas
- Generar recomendaciones basadas en datos
- Presentar problema, hipótesis y conclusiones de forma clara

## 📁 Archivos de trabajo

### **1. `estadistica_descriptiva.py`**
**¿Qué hace?** Análisis estadístico descriptivo básico con histogramas y boxplots.

**Incluye:**
- Medidas de tendencia central (media, mediana, moda) con explicaciones
- Medidas de dispersión (desviación estándar, varianza, rango, CV, MAD, SIQR)
- Análisis de forma de distribución (skewness, kurtosis)
- Detección básica de outliers
- Generación automática de histogramas y boxplots

**Cuándo usarlo:** Para análisis estadísticos básicos de variables individuales.

### **2. `correlaciones.py`**
**¿Qué hace?** Análisis de relaciones entre variables.

**Incluye:**
- Correlación de Pearson (relaciones lineales)
- Correlación de Spearman (relaciones monótonas)
- Matrices de correlación
- Identificación de correlaciones fuertes
- Interpretación de resultados

**Cuándo usarlo:** Para entender cómo se relacionan las diferentes variables del negocio.

### **3. `analisis_completo_estadistico.py` ⭐ RECOMENDADO**
**¿Qué hace?** Análisis estadístico completo y profesional con todas las funcionalidades.

**Incluye:**
- ✅ **Presentación del problema e hipótesis** con explicaciones claras
- ✅ **Análisis de variables comunes** con histogramas y boxplots
- ✅ **Análisis detallado de outliers** con múltiples métodos
- ✅ **Análisis estadístico completo de medios de pago**:
  - Distribución de ventas por método de pago
  - Análisis de montos por método de pago
  - Relación entre métodos de pago y clientes
  - Relación entre métodos de pago y ventas
  - Pruebas estadísticas para detectar diferencias significativas
- ✅ **Recomendaciones basadas en datos** con explicaciones claras
- ✅ **Explicaciones para todos los niveles** (sin conocimiento técnico requerido)

**Cuándo usarlo:** Para un análisis completo y profesional del negocio. **Este es el archivo más completo y recomendado.**

## 📊 Carpeta de histogramas

- `histogramas/` - Carpeta donde se guardan todos los gráficos generados:
  - **Histogramas**: Distribuciones de variables numéricas
  - **Boxplots**: Visualización de distribución y outliers
  - **Gráficos de medios de pago**: Distribución y comparaciones
  - **Matrices de correlación**: Relaciones entre variables

## 📚 Conceptos Explicados de Forma Simple

### **Medidas de Tendencia Central**
- **Media (Promedio)**: Suma todos los valores y divide entre la cantidad
  - Ejemplo: Si vendemos $100, $200, $300 → Media = $200
- **Mediana**: El valor que está en el medio cuando ordenas los datos
  - Ejemplo: En $100, $200, $300 → Mediana = $200
- **Moda**: El valor que aparece más veces
  - Ejemplo: Si $100 aparece 5 veces, $100 es la moda

### **Medidas de Dispersión**
- **Desviación Estándar**: Mide qué tan dispersos están los datos
  - Si es baja: Los datos son similares entre sí
  - Si es alta: Los datos son muy diferentes entre sí
- **Rango**: La diferencia entre el valor máximo y mínimo
- **Coeficiente de Variación (CV)**: Desviación estándar como porcentaje del promedio
  - Útil para comparar variabilidad entre diferentes variables

### **Distribuciones**
- **Distribución Normal**: Los datos están balanceados (como una campana)
- **Distribución Sesgada**: Los datos están concentrados en un lado
  - Sesgada a la derecha: Más valores pequeños, pocos muy grandes
  - Sesgada a la izquierda: Más valores grandes, pocos muy pequeños

### **Outliers (Valores Atípicos)**
- **¿Qué son?** Valores que están muy lejos del resto de los datos
- **Ejemplo**: Si la mayoría de ventas son de $100, pero hay una de $10,000
- **¿Por qué importan?** Pueden ser errores, oportunidades o casos especiales
- **Métodos de detección**:
  - **IQR**: Identifica valores fuera del rango normal (Q1 - 1.5*IQR a Q3 + 1.5*IQR)
  - **Z-Score**: Identifica valores que están a más de 3 desviaciones estándar del promedio

### **Correlaciones**
- **¿Qué es?** Mide si dos variables están relacionadas
- **Ejemplo**: ¿Cuando aumentan las ventas, también aumentan los clientes?
- **Tipos**:
  - **Pearson**: Mide relaciones lineales (si una aumenta, la otra aumenta proporcionalmente)
  - **Spearman**: Mide relaciones monótonas (si una aumenta, la otra también aumenta, pero no necesariamente de forma proporcional)

### **Boxplots**
- **¿Qué es?** Un gráfico que muestra la distribución de los datos
- **Partes del boxplot**:
  - **Caja**: Muestra el 50% central de los datos (entre Q1 y Q3)
  - **Línea en el medio**: La mediana (valor del medio)
  - **Bigotes**: Muestran el rango normal de los datos
  - **Puntos rojos**: Valores atípicos (outliers) que están fuera del rango normal

## 🚀 Cómo Usar

### **Opción 1: Análisis Completo (RECOMENDADO)**
```bash
cd "Sprint_2/Ximena Vargas - Proyecto Aurelion/2_Estadistica_Aplicada"
python analisis_completo_estadistico.py
```

Este script ejecuta un análisis completo que incluye:
- Presentación del problema e hipótesis
- Análisis de todas las variables comunes
- Histogramas y boxplots para todas las variables
- Análisis detallado de outliers
- Análisis completo de medios de pago
- Recomendaciones basadas en datos

### **Opción 2: Análisis Básico**
```bash
python estadistica_descriptiva.py
```

### **Opción 3: Análisis de Correlaciones**
```bash
python correlaciones.py
```

### **Opción 4: Desde el Menú Interactivo**
```bash
cd "Sprint_2"
python menu_interactivo.py
# Seleccionar opción 2 (Estadística Aplicada)
# Luego seleccionar el análisis que desees
```

## 💡 Interpretación de Resultados

### **Histogramas**
- **Barras a la izquierda**: Más valores pequeños
- **Barras a la derecha**: Más valores grandes
- **Barras balanceadas**: Valores distribuidos uniformemente
- **Línea roja**: Promedio
- **Línea verde**: Mediana

### **Boxplots**
- **Caja grande**: Mucha variabilidad en los datos
- **Caja pequeña**: Datos concentrados
- **Muchos puntos rojos**: Hay muchos valores atípicos que necesitan atención
- **Sin puntos rojos**: Los datos están dentro de rangos normales

### **Análisis de Medios de Pago**
- **Método más usado**: El que tiene más ventas
- **Método con mayor promedio**: Los clientes que lo usan gastan más
- **Diferencias significativas**: Los métodos realmente se comportan diferente (no es casualidad)

## 📈 Resultados Esperados

Después de ejecutar el análisis completo, obtendrás:

1. **Gráficos guardados** en la carpeta `histogramas/`:
   - Histogramas de todas las variables numéricas
   - Boxplots de todas las variables numéricas
   - Gráficos de distribución de medios de pago
   - Boxplots comparativos de importes por método de pago

2. **Análisis en consola** con:
   - Estadísticas descriptivas detalladas
   - Análisis de outliers
   - Análisis de medios de pago
   - Pruebas estadísticas
   - Recomendaciones

3. **Explicaciones claras** para cada resultado, sin necesidad de conocimiento técnico previo.

## 🎓 Aprendizajes

Al completar estos análisis, habrás aprendido:

- ✅ Cómo interpretar estadísticas descriptivas
- ✅ Cómo identificar y analizar valores atípicos
- ✅ Cómo visualizar distribuciones de datos
- ✅ Cómo analizar relaciones entre variables
- ✅ Cómo hacer análisis de negocio basado en datos
- ✅ Cómo generar recomendaciones accionables

---

*Todos los análisis incluyen explicaciones claras para que cualquier persona pueda entenderlos, sin necesidad de conocimiento previo de estadística.*
