#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ejercicio 1: Estadística Descriptiva Básica
Proyecto Aurelion - Sistema de Gestión de Ventas
Autor: Ximena Vargas
Camada: 25
Grupo: 10

Objetivo: Calcular e interpretar medidas de tendencia central y dispersión
Este ejercicio enseña:
- Medidas de tendencia central (media, mediana, moda)
- Medidas de dispersión (desviación estándar, varianza, rango)
- Análisis de cuartiles y percentiles
- Comparación de distribuciones
"""

# Importar librerías necesarias para el análisis estadístico
import pandas as pd  # type: ignore
import numpy as np  # type: ignore
import os
from pathlib import Path

# Importar librerías para visualización (parte del análisis estadístico)
try:
    import matplotlib.pyplot as plt  # type: ignore
    import seaborn as sns  # type: ignore
    VISUALIZACION_DISPONIBLE = True
except ImportError:
    VISUALIZACION_DISPONIBLE = False
    plt = None
    sns = None

def cargar_datos():
    """
    Cargar datos para análisis estadístico
    """
    ruta_datos = "../../../BASE_DE_DATOS/"
    
    try:
        ventas = pd.read_excel(os.path.join(ruta_datos, "Ventas.xlsx"))
        detalle_ventas = pd.read_excel(os.path.join(ruta_datos, "Detalle_ventas.xlsx"))
        productos = pd.read_excel(os.path.join(ruta_datos, "Productos.xlsx"))
        
        print("✅ Datos cargados para análisis estadístico")
        return ventas, detalle_ventas, productos
        
    except Exception as e:
        print(f"❌ Error al cargar datos: {e}")
        return None, None, None

def medidas_tendencia_central(df, columna):
    """
    Calcular medidas de tendencia central
    """
    print(f"\n📊 MEDIDAS DE TENDENCIA CENTRAL - {columna}")
    print("="*50)
    
    if columna not in df.columns:
        print(f"❌ La columna '{columna}' no existe")
        return
    
    # Verificar que la columna sea numérica
    if not pd.api.types.is_numeric_dtype(df[columna]):
        print(f"❌ La columna '{columna}' no es numérica")
        return
    
    # Calcular medidas
    media = df[columna].mean()
    mediana = df[columna].median()
    moda = df[columna].mode()
    
    print(f"📈 Media: {media:.2f}")
    print(f"📊 Mediana: {mediana:.2f}")
    print(f"🏆 Moda: {moda.iloc[0] if len(moda) > 0 else 'No hay moda única'}")
    
    return media, mediana, moda

def medidas_dispersion(df, columna):
    """
    Calcular medidas de dispersión (básicas y avanzadas)
    """
    print(f"\n📏 MEDIDAS DE DISPERSIÓN - {columna}")
    print("="*50)
    
    if columna not in df.columns:
        print(f"❌ La columna '{columna}' no existe")
        return
    
    if not pd.api.types.is_numeric_dtype(df[columna]):
        print(f"❌ La columna '{columna}' no es numérica")
        return
    
    data = df[columna].dropna()
    
    # Calcular medidas básicas
    desviacion_std = data.std()
    varianza = data.var()
    rango = data.max() - data.min()
    rango_intercuartil = data.quantile(0.75) - data.quantile(0.25)
    
    # Calcular medidas avanzadas
    media = data.mean()
    mediana = data.median()
    coeficiente_variacion = (desviacion_std / media * 100) if media != 0 else 0
    desviacion_media_absoluta = (data - mediana).abs().mean()  # MAD
    rango_semi_intercuartil = rango_intercuartil / 2  # SIQR
    
    print(f"📐 Desviación estándar (σ): {desviacion_std:.4f}")
    print(f"📊 Varianza (σ²): {varianza:.4f}")
    print(f"📏 Rango: {rango:.4f}")
    print(f"📋 Rango intercuartil (IQR): {rango_intercuartil:.4f}")
    print(f"📊 Rango semi-intercuartil (SIQR): {rango_semi_intercuartil:.4f}")
    print(f"📈 Coeficiente de variación (CV): {coeficiente_variacion:.2f}%")
    print(f"📉 Desviación media absoluta (MAD): {desviacion_media_absoluta:.4f}")
    
    # Interpretación del CV
    if coeficiente_variacion < 15:
        print(f"   → Baja variabilidad (datos homogéneos)")
    elif coeficiente_variacion < 35:
        print(f"   → Variabilidad moderada")
    else:
        print(f"   → Alta variabilidad (datos heterogéneos)")
    
    return {
        'std': desviacion_std,
        'var': varianza,
        'range': rango,
        'iqr': rango_intercuartil,
        'siqr': rango_semi_intercuartil,
        'cv': coeficiente_variacion,
        'mad': desviacion_media_absoluta
    }

def crear_histograma_estadistico(data, columna, nombre_dataset, histogram_dir=None, guardar=True):
    """
    Crear histograma como parte del análisis estadístico descriptivo
    con interpretación detallada del sesgo y análisis del negocio
    
    Args:
        data: Serie de pandas con los datos
        columna: Nombre de la columna
        nombre_dataset: Nombre del dataset
        histogram_dir: Directorio donde guardar (si None, no se guarda)
        guardar: Si True, guarda el histograma en archivo
    
    Returns:
        dict: Diccionario con estadísticas del histograma
    """
    if not VISUALIZACION_DISPONIBLE or len(data) == 0:
        return None
    
    # Crear figura más grande para mejor legibilidad
    fig, ax = plt.subplots(figsize=(14, 8))
    
    # Calcular número óptimo de bins basado en el análisis estadístico
    n_bins = int(np.ceil(np.log2(len(data)) + 1)) if len(data) > 1 else 20
    n_bins = min(max(n_bins, 10), 50)
    
    # Crear histograma
    n, bins, patches = ax.hist(data, bins=n_bins, alpha=0.7, color='steelblue', 
                               edgecolor='black', linewidth=1.2)
    
    # Agregar línea de densidad (KDE) si scipy está disponible
    try:
        from scipy import stats  # type: ignore
        density = stats.gaussian_kde(data)
        xs = np.linspace(data.min(), data.max(), 200)
        ax.plot(xs, density(xs) * len(data) * (bins[1] - bins[0]), 'r-', 
               linewidth=2, label='Curva de Densidad (KDE)', alpha=0.8)
    except:
        pass
    
    # Calcular estadísticas
    mean_val = data.mean()
    median_val = data.median()
    q1 = data.quantile(0.25)
    q3 = data.quantile(0.75)
    skewness = data.skew()
    
    # Agregar líneas verticales para media y mediana (medidas estadísticas)
    ax.axvline(mean_val, color='red', linestyle='--', linewidth=2.5, 
               label=f'Promedio (Media): {mean_val:.2f}', zorder=3)
    ax.axvline(median_val, color='green', linestyle='--', linewidth=2.5, 
               label=f'Mediana: {median_val:.2f}', zorder=3)
    
    # Agregar líneas para Q1 y Q3 (cuartiles del análisis estadístico)
    ax.axvline(q1, color='orange', linestyle=':', linewidth=2, alpha=0.8, 
               label=f'Q1 (25%): {q1:.2f}', zorder=2)
    ax.axvline(q3, color='orange', linestyle=':', linewidth=2, alpha=0.8, 
               label=f'Q3 (75%): {q3:.2f}', zorder=2)
    
    # Análisis de sesgo
    if abs(skewness) < 0.5:
        tipo_sesgo = "DISTRIBUCIÓN SIMÉTRICA"
        descripcion_sesgo = "Los datos están balanceados, con valores distribuidos de forma equilibrada alrededor del centro."
        interpretacion_negocio = _interpretar_distribucion_simetrica(columna, nombre_dataset, mean_val, median_val)
    elif skewness > 0.5:
        tipo_sesgo = "SESGADA A LA DERECHA (Positiva)"
        descripcion_sesgo = "La mayoría de los valores son pequeños, pero hay algunos valores muy grandes que 'arrastran' el promedio hacia la derecha."
        interpretacion_negocio = _interpretar_distribucion_derecha(columna, nombre_dataset, mean_val, median_val)
    else:
        tipo_sesgo = "SESGADA A LA IZQUIERDA (Negativa)"
        descripcion_sesgo = "La mayoría de los valores son grandes, pero hay algunos valores muy pequeños que 'arrastran' el promedio hacia la izquierda."
        interpretacion_negocio = _interpretar_distribucion_izquierda(columna, nombre_dataset, mean_val, median_val)
    
    # Configurar título con información del sesgo
    ax.set_title(f'Distribución de {columna} - {nombre_dataset}\n'
                f'Tipo: {tipo_sesgo} | Sesgo: {skewness:.3f}', 
                fontsize=14, fontweight='bold', pad=20)
    ax.set_xlabel(columna, fontsize=12, fontweight='bold')
    ax.set_ylabel('Frecuencia (Cantidad de veces que aparece)', fontsize=12, fontweight='bold')
    ax.grid(True, alpha=0.3, linestyle='--', axis='y')
    ax.legend(fontsize=9, loc='upper right', framealpha=0.9)
    
    # Agregar texto explicativo detallado
    texto_explicacion = f"""
📊 ANÁLISIS DE LA DISTRIBUCIÓN:
• Tipo de distribución: {tipo_sesgo}
• Medida de sesgo (Skewness): {skewness:.3f} {'(Simétrica)' if abs(skewness) < 0.5 else '(Sesgada a la derecha)' if skewness > 0.5 else '(Sesgada a la izquierda)'}
• {descripcion_sesgo}

💼 INTERPRETACIÓN PARA EL NEGOCIO:
{interpretacion_negocio}

📈 LECTURA DEL GRÁFICO:
• Las barras azules muestran cuántas veces aparece cada rango de valores
• La línea roja (promedio) está en {mean_val:.2f} - es el valor promedio de todos los datos
• La línea verde (mediana) está en {median_val:.2f} - es el valor del medio (50% arriba, 50% abajo)
• Las líneas naranjas muestran Q1 ({q1:.2f}) y Q3 ({q3:.2f}) - el 50% central de los datos
• {'La mediana está a la IZQUIERDA del promedio → Más valores pequeños' if median_val < mean_val else 'La mediana está a la DERECHA del promedio → Más valores grandes' if median_val > mean_val else 'La mediana y el promedio están cerca → Distribución balanceada'}
    """
    
    # Agregar texto en la parte inferior
    fig.text(0.5, -0.25, texto_explicacion, ha='center', fontsize=9, 
            style='normal', wrap=True, bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))
    
    # Guardar si se especifica
    filename = None
    if guardar and histogram_dir is not None:
        histogram_dir = Path(histogram_dir)
        histogram_dir.mkdir(exist_ok=True)
        filename = histogram_dir / f'histograma_{nombre_dataset}_{columna.replace(" ", "_").replace("/", "_")}.png'
        plt.tight_layout()
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"   📊 Histograma guardado: {filename}")
        print(f"   📈 Tipo de distribución: {tipo_sesgo} (Sesgo: {skewness:.3f})")
    
    plt.close()
    
    # Retornar estadísticas del análisis
    return {
        'mean': mean_val,
        'median': median_val,
        'q1': q1,
        'q3': q3,
        'std': data.std(),
        'skewness': skewness,
        'kurtosis': data.kurtosis(),
        'tipo_sesgo': tipo_sesgo,
        'filename': str(filename) if filename else None
    }

def _interpretar_distribucion_simetrica(columna, nombre_dataset, media, mediana):
    """Interpretar distribución simétrica para el negocio."""
    interpretaciones = {
        'importe': f"Los importes de venta están distribuidos de forma equilibrada. Esto significa que hay una mezcla balanceada de ventas pequeñas, medianas y grandes. El promedio de ${media:.2f} es representativo de las ventas típicas.",
        'cantidad': f"Las cantidades vendidas están distribuidas de forma equilibrada. Hay una mezcla balanceada de pedidos pequeños y grandes. El promedio de {media:.2f} unidades representa bien las ventas típicas.",
        'precio_unitario': f"Los precios unitarios están distribuidos de forma equilibrada. Hay una mezcla balanceada de productos económicos y costosos. El precio promedio de ${media:.2f} es representativo del catálogo.",
        'id_venta': "Las ventas están distribuidas de forma equilibrada en el tiempo. No hay concentración excesiva en períodos específicos.",
        'id_cliente': "Los clientes están distribuidos de forma equilibrada. No hay concentración excesiva de ventas en pocos clientes.",
        'id_producto': "Los productos están distribuidos de forma equilibrada. No hay concentración excesiva de ventas en pocos productos."
    }
    
    # Buscar coincidencias parciales
    for key, value in interpretaciones.items():
        if key.lower() in columna.lower():
            return value
    
    return f"Los valores de {columna} están distribuidos de forma equilibrada. El promedio de {media:.2f} es representativo de los valores típicos en {nombre_dataset}."

def _interpretar_distribucion_derecha(columna, nombre_dataset, media, mediana):
    """Interpretar distribución sesgada a la derecha para el negocio."""
    interpretaciones = {
        'importe': f"La mayoría de las ventas son de montos pequeños (mediana: ${mediana:.2f}), pero hay algunas ventas muy grandes que elevan el promedio a ${media:.2f}. Esto es TÍPICO en retail: muchas compras pequeñas y pocas compras grandes. Los clientes VIP o compras corporativas pueden estar causando este patrón.",
        'cantidad': f"La mayoría de los pedidos son de pocas unidades (mediana: {mediana:.2f}), pero hay algunos pedidos muy grandes que elevan el promedio a {media:.2f}. Esto sugiere que la mayoría de clientes compra poco, pero algunos hacen pedidos grandes (posiblemente mayoristas o compras corporativas).",
        'precio_unitario': f"La mayoría de los productos tienen precios bajos (mediana: ${mediana:.2f}), pero hay algunos productos muy costosos que elevan el promedio a ${media:.2f}. Esto es normal: muchos productos económicos y pocos productos premium o de lujo.",
        'id_venta': "La mayoría de las ventas ocurren en períodos normales, pero hay algunos períodos con muchas ventas (posiblemente temporadas altas, promociones o eventos especiales).",
        'id_cliente': "La mayoría de los clientes hacen pocas compras, pero hay algunos clientes muy activos (clientes VIP o frecuentes) que generan muchas ventas.",
        'id_producto': "La mayoría de los productos se venden poco, pero hay algunos productos estrella (best sellers) que se venden mucho más que el resto."
    }
    
    for key, value in interpretaciones.items():
        if key.lower() in columna.lower():
            return value
    
    return f"La mayoría de los valores de {columna} son pequeños (mediana: {mediana:.2f}), pero hay algunos valores muy grandes que elevan el promedio a {media:.2f}. Esto es común en datos de negocio: muchos casos normales y pocos casos excepcionales."

def _interpretar_distribucion_izquierda(columna, nombre_dataset, media, mediana):
    """Interpretar distribución sesgada a la izquierda para el negocio."""
    interpretaciones = {
        'importe': f"La mayoría de las ventas son de montos grandes (mediana: ${mediana:.2f}), pero hay algunas ventas muy pequeñas que reducen el promedio a ${media:.2f}. Esto puede indicar que el negocio se enfoca en ventas de mayor valor, con pocas ventas pequeñas (posiblemente promociones o productos de entrada).",
        'cantidad': f"La mayoría de los pedidos son de muchas unidades (mediana: {mediana:.2f}), pero hay algunos pedidos muy pequeños que reducen el promedio a {media:.2f}. Esto sugiere que el negocio se enfoca en pedidos grandes, posiblemente mayoristas o B2B.",
        'precio_unitario': f"La mayoría de los productos tienen precios altos (mediana: ${mediana:.2f}), pero hay algunos productos muy económicos que reducen el promedio a ${media:.2f}. Esto indica un catálogo premium con algunos productos de entrada.",
        'id_venta': "La mayoría de las ventas ocurren en períodos de alta actividad, con pocos períodos de baja actividad.",
        'id_cliente': "La mayoría de los clientes hacen muchas compras, con pocos clientes ocasionales.",
        'id_producto': "La mayoría de los productos se venden bien, con pocos productos de bajo movimiento."
    }
    
    for key, value in interpretaciones.items():
        if key.lower() in columna.lower():
            return value
    
    return f"La mayoría de los valores de {columna} son grandes (mediana: {mediana:.2f}), pero hay algunos valores muy pequeños que reducen el promedio a {media:.2f}. Esto puede indicar un enfoque en valores altos con pocos casos de bajo valor."

def analisis_completo_columna(df, columna, generar_histograma=False, histogram_dir=None, nombre_dataset='dataset'):
    """
    Análisis estadístico completo de una columna
    Incluye generación de histograma como parte del análisis estadístico
    
    Args:
        df: DataFrame
        columna: Nombre de la columna
        generar_histograma: Si True, genera histograma como parte del análisis
        histogram_dir: Directorio donde guardar histogramas
        nombre_dataset: Nombre del dataset para identificar el histograma
    """
    print(f"\n🔍 ANÁLISIS COMPLETO - {columna}")
    print("="*60)
    
    if columna not in df.columns:
        print(f"❌ La columna '{columna}' no existe")
        return None
    
    if not pd.api.types.is_numeric_dtype(df[columna]):
        print(f"❌ La columna '{columna}' no es numérica")
        return None
    
    # Información básica
    print(f"📊 Total de valores: {len(df[columna])}")
    print(f"❓ Valores nulos: {df[columna].isnull().sum()}")
    print(f"🔄 Valores únicos: {df[columna].nunique()}")
    
    # Medidas de tendencia central
    medidas_tendencia_central(df, columna)
    
    # Medidas de dispersión
    medidas_dispersion(df, columna)
    
    # Cuartiles y percentiles
    print(f"\n📋 CUARTILES Y PERCENTILES - {columna}")
    print("="*40)
    data = df[columna].dropna()
    cuartiles = data.quantile([0.25, 0.5, 0.75])
    percentiles = data.quantile([0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99])
    
    print(f"Q1 (P25): {cuartiles[0.25]:.4f}")
    print(f"Q2 (P50 - Mediana): {cuartiles[0.5]:.4f}")
    print(f"Q3 (P75): {cuartiles[0.75]:.4f}")
    print(f"\nPercentiles adicionales:")
    print(f"P10: {percentiles[0.10]:.4f}")
    print(f"P90: {percentiles[0.90]:.4f}")
    print(f"P95: {percentiles[0.95]:.4f}")
    print(f"P99: {percentiles[0.99]:.4f}")
    
    # Análisis de forma de la distribución
    print(f"\n📐 ANÁLISIS DE FORMA - {columna}")
    print("="*35)
    skewness = data.skew()
    kurtosis = data.kurtosis()
    
    print(f"Asimetría (Skewness): {skewness:.4f}")
    if abs(skewness) < 0.5:
        print(f"   → Distribución aproximadamente simétrica")
    elif skewness > 0.5:
        print(f"   → Asimetría positiva (cola hacia la derecha, sesgo derecho)")
    else:
        print(f"   → Asimetría negativa (cola hacia la izquierda, sesgo izquierdo)")
    
    print(f"Curtosis (Kurtosis): {kurtosis:.4f}")
    if abs(kurtosis) < 0.5:
        print(f"   → Curtosis normal (mesocúrtica, similar a distribución normal)")
    elif kurtosis > 0.5:
        print(f"   → Leptocúrtica (picos más altos, colas más pesadas que la normal)")
    else:
        print(f"   → Platicúrtica (picos más bajos, colas más ligeras que la normal)")
    
    # Análisis de outliers
    print(f"\n🔍 ANÁLISIS DE OUTLIERS - {columna}")
    print("="*40)
    q1 = cuartiles[0.25]
    q3 = cuartiles[0.75]
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    outliers = data[(data < lower_bound) | (data > upper_bound)]
    outliers_count = len(outliers)
    outliers_pct = (outliers_count / len(data)) * 100 if len(data) > 0 else 0
    
    print(f"Límite inferior (Q1 - 1.5*IQR): {lower_bound:.4f}")
    print(f"Límite superior (Q3 + 1.5*IQR): {upper_bound:.4f}")
    print(f"Outliers detectados: {outliers_count} ({outliers_pct:.2f}% del total)")
    if outliers_count > 0:
        print(f"Rango de outliers: [{outliers.min():.4f}, {outliers.max():.4f}]")
    
    # Valores extremos
    print(f"\n🎯 VALORES EXTREMOS - {columna}")
    print("="*35)
    print(f"Mínimo: {data.min():.4f}")
    print(f"Máximo: {data.max():.4f}")
    print(f"Rango: {data.max() - data.min():.4f}")
    
    # Generar histograma como parte del análisis estadístico
    hist_stats = None
    if generar_histograma and VISUALIZACION_DISPONIBLE:
        print(f"\n📊 GENERANDO HISTOGRAMA (Análisis Estadístico)")
        print("="*40)
        hist_stats = crear_histograma_estadistico(data, columna, nombre_dataset, histogram_dir, guardar=True)
        
        # También generar boxplot
        print(f"📦 GENERANDO BOXPLOT (Análisis de Outliers)")
        print("="*40)
        boxplot_stats = crear_boxplot_estadistico(data, columna, nombre_dataset, histogram_dir, guardar=True)
        if boxplot_stats:
            print(f"   • Outliers detectados en boxplot: {boxplot_stats.get('outliers_count', 0)}")
    
    # Retornar estadísticas completas
    return {
        'columna': columna,
        'media': data.mean(),
        'mediana': data.median(),
        'std': data.std(),
        'skewness': skewness,
        'kurtosis': kurtosis,
        'outliers_count': outliers_count,
        'histograma': hist_stats
    }

def crear_boxplot_estadistico(data, columna, nombre_dataset, histogram_dir=None, guardar=True):
    """
    Crear boxplot como parte del análisis estadístico descriptivo
    
    Args:
        data: Serie de pandas con los datos
        columna: Nombre de la columna
        nombre_dataset: Nombre del dataset
        histogram_dir: Directorio donde guardar (si None, no se guarda)
        guardar: Si True, guarda el boxplot en archivo
    
    Returns:
        dict: Diccionario con estadísticas del boxplot
    """
    if not VISUALIZACION_DISPONIBLE or len(data) == 0:
        return None
    
    # Crear figura
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # Crear boxplot
    bp = ax.boxplot([data], vert=True, patch_artist=True,
                   boxprops=dict(facecolor='lightblue', alpha=0.7),
                   medianprops=dict(color='red', linewidth=2),
                   whiskerprops=dict(color='black', linewidth=1.5),
                   capprops=dict(color='black', linewidth=1.5))
    
    # Calcular outliers
    q1 = data.quantile(0.25)
    q3 = data.quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    outliers = data[(data < lower_bound) | (data > upper_bound)]
    
    # Agregar puntos de outliers si existen
    if len(outliers) > 0:
        ax.scatter([1] * len(outliers), outliers, color='red', 
                  alpha=0.6, s=50, zorder=3, label=f'Outliers ({len(outliers)})')
    
    # Configurar gráfico
    ax.set_title(f'Boxplot de {columna} - {nombre_dataset}\n'
                f'(Visualización de distribución y valores atípicos)', 
                fontsize=14, fontweight='bold')
    ax.set_ylabel(columna, fontsize=12)
    ax.set_xticklabels([columna])
    ax.grid(True, alpha=0.3, axis='y')
    if len(outliers) > 0:
        ax.legend()
    
    # Agregar anotaciones
    ax.text(1.15, q1, f'Q1: {q1:.2f}', fontsize=9, verticalalignment='center')
    ax.text(1.15, data.median(), f'Mediana: {data.median():.2f}', 
           fontsize=9, verticalalignment='center')
    ax.text(1.15, q3, f'Q3: {q3:.2f}', fontsize=9, verticalalignment='center')
    
    # Guardar si se especifica
    filename = None
    if guardar and histogram_dir is not None:
        histogram_dir = Path(histogram_dir)
        histogram_dir.mkdir(exist_ok=True)
        filename = histogram_dir / f'boxplot_{nombre_dataset}_{columna.replace(" ", "_").replace("/", "_")}.png'
        plt.tight_layout()
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"   📦 Boxplot guardado: {filename}")
    
    plt.close()
    
    # Retornar estadísticas
    return {
        'q1': q1,
        'q3': q3,
        'median': data.median(),
        'outliers_count': len(outliers),
        'filename': str(filename) if filename else None
    }

def comparar_distribuciones(df, columnas):
    """
    Comparar distribuciones de múltiples columnas
    """
    print(f"\n⚖️  COMPARACIÓN DE DISTRIBUCIONES")
    print("="*50)
    
    # Crear DataFrame con estadísticas comparativas
    stats_comparison = pd.DataFrame()
    
    for col in columnas:
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            stats_comparison[col] = {
                'Media': df[col].mean(),
                'Mediana': df[col].median(),
                'Desv. Std': df[col].std(),
                'Mínimo': df[col].min(),
                'Máximo': df[col].max(),
                'Rango': df[col].max() - df[col].min()
            }
    
    if not stats_comparison.empty:
        print(stats_comparison.round(2))
    else:
        print("❌ No hay columnas numéricas válidas para comparar")

if __name__ == "__main__":
    print("🚀 Iniciando análisis de estadística descriptiva...")
    
    # Cargar datos
    ventas, detalle_ventas, productos = cargar_datos()
    
    if ventas is not None and detalle_ventas is not None:
        print("\n" + "="*60)
        print("ANÁLISIS DE VENTAS")
        print("="*60)
        
        # Analizar columnas numéricas de ventas
        columnas_numericas_ventas = ventas.select_dtypes(include=[np.number]).columns
        print(f"Columnas numéricas en Ventas: {list(columnas_numericas_ventas)}")
        
        # Crear directorio para histogramas si se van a generar
        histogram_dir = Path(__file__).parent / "histogramas"
        histogram_dir.mkdir(exist_ok=True)
        
        for col in columnas_numericas_ventas:
            analisis_completo_columna(ventas, col, generar_histograma=True, 
                                     histogram_dir=histogram_dir, nombre_dataset='ventas')
        
        print("\n" + "="*60)
        print("ANÁLISIS DE DETALLE VENTAS")
        print("="*60)
        
        # Analizar columnas numéricas de detalle ventas
        columnas_numericas_detalle = detalle_ventas.select_dtypes(include=[np.number]).columns
        print(f"Columnas numéricas en Detalle Ventas: {list(columnas_numericas_detalle)}")
        
        for col in columnas_numericas_detalle:
            analisis_completo_columna(detalle_ventas, col, generar_histograma=True, 
                                     histogram_dir=histogram_dir, nombre_dataset='detalle_ventas')
        
        # Comparar distribuciones si hay múltiples columnas numéricas
        if len(columnas_numericas_detalle) > 1:
            comparar_distribuciones(detalle_ventas, columnas_numericas_detalle)
