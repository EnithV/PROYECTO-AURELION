#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ejercicio 1: Fundamentos de Matplotlib
Proyecto Aurelion - Sistema de Gestión de Ventas
Autor: Ximena Vargas
Camada: 25
Grupo: 10

Objetivo: Aprender a crear visualizaciones básicas con Matplotlib
Este ejercicio enseña:
- Gráficos de barras y columnas
- Histogramas y distribuciones
- Gráficos de dispersión
- Gráficos de líneas
- Personalización de gráficos
- Subplots múltiples
"""

# Importar librerías necesarias para visualización
import matplotlib.pyplot as plt  # type: ignore
import pandas as pd  # type: ignore
import numpy as np  # type: ignore
import os

# Configurar estilo de matplotlib
plt.style.use('default')
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['font.size'] = 10

def cargar_datos():
    """
    Cargar datos para visualización
    """
    ruta_datos = "../../../BASE_DE_DATOS/"
    
    try:
        ventas = pd.read_excel(os.path.join(ruta_datos, "Ventas.xlsx"))
        detalle_ventas = pd.read_excel(os.path.join(ruta_datos, "Detalle_ventas.xlsx"))
        productos = pd.read_excel(os.path.join(ruta_datos, "Productos.xlsx"))
        
        print("✅ Datos cargados para visualización")
        return ventas, detalle_ventas, productos
        
    except Exception as e:
        print(f"❌ Error al cargar datos: {e}")
        return None, None, None

def grafico_barras_basico(df, columna_x, columna_y, titulo="Gráfico de Barras"):
    """
    Crear gráfico de barras básico
    """
    plt.figure(figsize=(10, 6))
    
    # Verificar que las columnas existen
    if columna_x not in df.columns or columna_y not in df.columns:
        print(f"❌ Columnas no encontradas: {columna_x}, {columna_y}")
        return
    
    # Crear gráfico de barras
    plt.bar(df[columna_x], df[columna_y], color='skyblue', edgecolor='navy', alpha=0.7)
    
    # Personalizar gráfico
    plt.title(titulo, fontsize=14, fontweight='bold')
    plt.xlabel(columna_x, fontsize=12)
    plt.ylabel(columna_y, fontsize=12)
    plt.xticks(rotation=45)
    plt.grid(axis='y', alpha=0.3)
    
    # Ajustar layout
    plt.tight_layout()
    plt.show()

def histograma_basico(df, columna, titulo="Histograma"):
    """
    Crear histograma básico
    """
    plt.figure(figsize=(10, 6))
    
    if columna not in df.columns:
        print(f"❌ Columna no encontrada: {columna}")
        return
    
    if not pd.api.types.is_numeric_dtype(df[columna]):
        print(f"❌ La columna '{columna}' no es numérica")
        return
    
    # Crear histograma
    plt.hist(df[columna].dropna(), bins=20, color='lightgreen', edgecolor='black', alpha=0.7)
    
    # Personalizar gráfico
    plt.title(titulo, fontsize=14, fontweight='bold')
    plt.xlabel(columna, fontsize=12)
    plt.ylabel('Frecuencia', fontsize=12)
    plt.grid(axis='y', alpha=0.3)
    
    # Añadir estadísticas
    media = df[columna].mean()
    mediana = df[columna].median()
    plt.axvline(media, color='red', linestyle='--', label=f'Media: {media:.2f}')
    plt.axvline(mediana, color='orange', linestyle='--', label=f'Mediana: {mediana:.2f}')
    plt.legend()
    
    plt.tight_layout()
    plt.show()

def grafico_dispersion(df, columna_x, columna_y, titulo="Gráfico de Dispersión"):
    """
    Crear gráfico de dispersión
    """
    plt.figure(figsize=(10, 6))
    
    if columna_x not in df.columns or columna_y not in df.columns:
        print(f"❌ Columnas no encontradas: {columna_x}, {columna_y}")
        return
    
    if not (pd.api.types.is_numeric_dtype(df[columna_x]) and pd.api.types.is_numeric_dtype(df[columna_y])):
        print(f"❌ Una o ambas columnas no son numéricas")
        return
    
    # Crear gráfico de dispersión
    plt.scatter(df[columna_x], df[columna_y], alpha=0.6, color='purple', s=50)
    
    # Personalizar gráfico
    plt.title(titulo, fontsize=14, fontweight='bold')
    plt.xlabel(columna_x, fontsize=12)
    plt.ylabel(columna_y, fontsize=12)
    plt.grid(True, alpha=0.3)
    
    # Añadir línea de tendencia
    z = np.polyfit(df[columna_x].dropna(), df[columna_y].dropna(), 1)
    p = np.poly1d(z)
    plt.plot(df[columna_x], p(df[columna_x]), "r--", alpha=0.8, label='Línea de tendencia')
    plt.legend()
    
    plt.tight_layout()
    plt.show()

def grafico_lineas(df, columna_x, columna_y, titulo="Gráfico de Líneas"):
    """
    Crear gráfico de líneas
    """
    plt.figure(figsize=(12, 6))
    
    if columna_x not in df.columns or columna_y not in df.columns:
        print(f"❌ Columnas no encontradas: {columna_x}, {columna_y}")
        return
    
    # Crear gráfico de líneas
    plt.plot(df[columna_x], df[columna_y], marker='o', linewidth=2, markersize=6, color='darkblue')
    
    # Personalizar gráfico
    plt.title(titulo, fontsize=14, fontweight='bold')
    plt.xlabel(columna_x, fontsize=12)
    plt.ylabel(columna_y, fontsize=12)
    plt.grid(True, alpha=0.3)
    
    # Rotar etiquetas del eje x si es necesario
    if len(df[columna_x].astype(str).iloc[0]) > 10:
        plt.xticks(rotation=45)
    
    plt.tight_layout()
    plt.show()

def subplots_multiples(df, columnas_numericas):
    """
    Crear múltiples subplots
    """
    n_cols = len(columnas_numericas)
    if n_cols == 0:
        print("❌ No hay columnas numéricas para graficar")
        return
    
    # Configurar subplots
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    fig.suptitle('Análisis Visual de Variables Numéricas', fontsize=16, fontweight='bold')
    
    # Aplanar axes para facilitar el acceso
    axes = axes.flatten()
    
    for i, col in enumerate(columnas_numericas[:4]):  # Máximo 4 gráficos
        if i < len(axes):
            # Histograma
            axes[i].hist(df[col].dropna(), bins=15, alpha=0.7, color=plt.cm.Set3(i))
            axes[i].set_title(f'Distribución de {col}', fontweight='bold')
            axes[i].set_xlabel(col)
            axes[i].set_ylabel('Frecuencia')
            axes[i].grid(True, alpha=0.3)
    
    # Ocultar subplots vacíos
    for i in range(len(columnas_numericas), len(axes)):
        axes[i].set_visible(False)
    
    plt.tight_layout()
    plt.show()

def personalizar_grafico():
    """
    Ejemplo de personalización avanzada de gráficos
    """
    # Crear datos de ejemplo
    x = np.linspace(0, 10, 100)
    y1 = np.sin(x)
    y2 = np.cos(x)
    
    plt.figure(figsize=(12, 8))
    
    # Crear gráfico con múltiples líneas
    plt.plot(x, y1, label='sin(x)', linewidth=2, color='blue', linestyle='-')
    plt.plot(x, y2, label='cos(x)', linewidth=2, color='red', linestyle='--')
    
    # Personalización avanzada
    plt.title('Funciones Trigonométricas', fontsize=16, fontweight='bold', pad=20)
    plt.xlabel('X', fontsize=14)
    plt.ylabel('Y', fontsize=14)
    
    # Personalizar ejes
    plt.xlim(0, 10)
    plt.ylim(-1.5, 1.5)
    
    # Personalizar grid
    plt.grid(True, alpha=0.3, linestyle=':', color='gray')
    
    # Personalizar leyenda
    plt.legend(loc='upper right', frameon=True, shadow=True, fancybox=True)
    
    # Añadir anotaciones
    plt.annotate('Máximo de sin(x)', xy=(np.pi/2, 1), xytext=(np.pi/2 + 1, 1.2),
                arrowprops=dict(arrowstyle='->', color='blue', lw=2),
                fontsize=12, color='blue')
    
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    print("🚀 Iniciando ejercicios de Matplotlib...")
    
    # Cargar datos
    ventas, detalle_ventas, productos = cargar_datos()
    
    if detalle_ventas is not None:
        print("\n" + "="*60)
        print("EJERCICIOS DE MATPLOTLIB")
        print("="*60)
        
        # Obtener columnas numéricas
        columnas_numericas = detalle_ventas.select_dtypes(include=[np.number]).columns
        print(f"Columnas numéricas disponibles: {list(columnas_numericas)}")
        
        # Ejercicio 1: Histograma
        if len(columnas_numericas) > 0:
            print(f"\n📊 Creando histograma para: {columnas_numericas[0]}")
            histograma_basico(detalle_ventas, columnas_numericas[0], 
                            f"Distribución de {columnas_numericas[0]}")
        
        # Ejercicio 2: Gráfico de dispersión
        if len(columnas_numericas) >= 2:
            print(f"\n📈 Creando gráfico de dispersión: {columnas_numericas[0]} vs {columnas_numericas[1]}")
            grafico_dispersion(detalle_ventas, columnas_numericas[0], columnas_numericas[1],
                             f"{columnas_numericas[0]} vs {columnas_numericas[1]}")
        
        # Ejercicio 3: Múltiples subplots
        print(f"\n📋 Creando múltiples subplots...")
        subplots_multiples(detalle_ventas, columnas_numericas)
        
        # Ejercicio 4: Personalización avanzada
        print(f"\n🎨 Ejemplo de personalización avanzada...")
        personalizar_grafico()
        
        print("\n✅ Ejercicios de Matplotlib completados!")
