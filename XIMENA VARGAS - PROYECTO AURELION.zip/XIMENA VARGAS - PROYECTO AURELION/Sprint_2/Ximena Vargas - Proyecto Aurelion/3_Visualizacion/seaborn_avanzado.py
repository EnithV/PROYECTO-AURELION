#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ejercicio 2: Visualizaciones Avanzadas con Seaborn
Proyecto Aurelion - Sistema de Gestión de Ventas
Autor: Ximena Vargas
Camada: 25
Grupo: 10

Objetivo: Dominar las capacidades de Seaborn para análisis estadístico
Este ejercicio enseña:
- Boxplots y violin plots
- Heatmaps de correlaciones
- Pairplots y análisis multivariado
- Scatterplots avanzados
- Barplots agrupados
- Distribuciones combinadas
"""

# Importar librerías necesarias para visualización avanzada
import seaborn as sns  # type: ignore
import matplotlib.pyplot as plt  # type: ignore
import pandas as pd  # type: ignore
import numpy as np  # type: ignore
import os

# Configurar estilo de Seaborn
sns.set_style("whitegrid")
sns.set_palette("husl")
plt.rcParams['figure.figsize'] = (12, 8)

def cargar_datos():
    """
    Cargar datos para visualización con Seaborn
    """
    ruta_datos = "../../../BASE_DE_DATOS/"
    
    try:
        ventas = pd.read_excel(os.path.join(ruta_datos, "Ventas.xlsx"))
        detalle_ventas = pd.read_excel(os.path.join(ruta_datos, "Detalle_ventas.xlsx"))
        productos = pd.read_excel(os.path.join(ruta_datos, "Productos.xlsx"))
        clientes = pd.read_excel(os.path.join(ruta_datos, "Clientes.xlsx"))
        
        print("✅ Datos cargados para visualización con Seaborn")
        return ventas, detalle_ventas, productos, clientes
        
    except Exception as e:
        print(f"❌ Error al cargar datos: {e}")
        return None, None, None, None

def boxplot_avanzado(df, columna_y, columna_x=None, titulo="Boxplot"):
    """
    Crear boxplot avanzado con Seaborn
    """
    plt.figure(figsize=(12, 6))
    
    if columna_y not in df.columns:
        print(f"❌ Columna no encontrada: {columna_y}")
        return
    
    if not pd.api.types.is_numeric_dtype(df[columna_y]):
        print(f"❌ La columna '{columna_y}' no es numérica")
        return
    
    if columna_x and columna_x in df.columns:
        # Boxplot por categorías
        sns.boxplot(data=df, x=columna_x, y=columna_y, palette="Set2")
        plt.title(f"{titulo} - {columna_y} por {columna_x}", fontsize=14, fontweight='bold')
    else:
        # Boxplot simple
        sns.boxplot(data=df, y=columna_y, palette="Set2")
        plt.title(f"{titulo} - {columna_y}", fontsize=14, fontweight='bold')
    
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def violin_plot(df, columna_y, columna_x=None, titulo="Violin Plot"):
    """
    Crear violin plot con Seaborn
    """
    plt.figure(figsize=(12, 6))
    
    if columna_y not in df.columns:
        print(f"❌ Columna no encontrada: {columna_y}")
        return
    
    if not pd.api.types.is_numeric_dtype(df[columna_y]):
        print(f"❌ La columna '{columna_y}' no es numérica")
        return
    
    if columna_x and columna_x in df.columns:
        sns.violinplot(data=df, x=columna_x, y=columna_y, palette="viridis")
        plt.title(f"{titulo} - {columna_y} por {columna_x}", fontsize=14, fontweight='bold')
    else:
        sns.violinplot(data=df, y=columna_y, palette="viridis")
        plt.title(f"{titulo} - {columna_y}", fontsize=14, fontweight='bold')
    
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def heatmap_correlaciones(df, titulo="Matriz de Correlaciones"):
    """
    Crear heatmap de correlaciones
    """
    plt.figure(figsize=(10, 8))
    
    # Seleccionar solo columnas numéricas
    df_numeric = df.select_dtypes(include=[np.number])
    
    if df_numeric.empty:
        print("❌ No hay columnas numéricas para crear heatmap")
        return
    
    # Calcular matriz de correlaciones
    corr_matrix = df_numeric.corr()
    
    # Crear heatmap
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))  # Máscara para triángulo superior
    sns.heatmap(corr_matrix, 
                mask=mask,
                annot=True, 
                cmap='coolwarm', 
                center=0,
                square=True,
                fmt='.2f',
                cbar_kws={"shrink": .8})
    
    plt.title(titulo, fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.show()

def pairplot_avanzado(df, columnas=None, hue=None):
    """
    Crear pairplot avanzado
    """
    if columnas is None:
        columnas = df.select_dtypes(include=[np.number]).columns.tolist()
    
    # Verificar que las columnas existen
    columnas_validas = [col for col in columnas if col in df.columns and pd.api.types.is_numeric_dtype(df[col])]
    
    if len(columnas_validas) < 2:
        print("❌ Se necesitan al menos 2 columnas numéricas para pairplot")
        return
    
    # Limitar a máximo 4 columnas para mejor visualización
    if len(columnas_validas) > 4:
        columnas_validas = columnas_validas[:4]
        print(f"⚠️  Limitando a las primeras 4 columnas: {columnas_validas}")
    
    # Crear pairplot
    g = sns.pairplot(df[columnas_validas + ([hue] if hue and hue in df.columns else [])], 
                     hue=hue if hue and hue in df.columns else None,
                     diag_kind='hist',
                     plot_kws={'alpha': 0.6})
    
    g.fig.suptitle('Análisis de Relaciones entre Variables', y=1.02, fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.show()

def distplot_combinado(df, columnas_numericas):
    """
    Crear distribución combinada de múltiples variables
    """
    plt.figure(figsize=(12, 8))
    
    for i, col in enumerate(columnas_numericas[:4]):  # Máximo 4 variables
        plt.subplot(2, 2, i+1)
        sns.histplot(data=df, x=col, kde=True, alpha=0.7, color=plt.cm.Set1(i))
        plt.title(f'Distribución de {col}', fontweight='bold')
        plt.xlabel(col)
        plt.ylabel('Densidad')
    
    plt.suptitle('Distribuciones de Variables Numéricas', fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.show()

def scatterplot_avanzado(df, columna_x, columna_y, hue=None, size=None):
    """
    Crear scatterplot avanzado con múltiples dimensiones
    """
    plt.figure(figsize=(12, 8))
    
    if columna_x not in df.columns or columna_y not in df.columns:
        print(f"❌ Columnas no encontradas: {columna_x}, {columna_y}")
        return
    
    if not (pd.api.types.is_numeric_dtype(df[columna_x]) and pd.api.types.is_numeric_dtype(df[columna_y])):
        print(f"❌ Una o ambas columnas no son numéricas")
        return
    
    # Crear scatterplot
    sns.scatterplot(data=df, 
                   x=columna_x, 
                   y=columna_y, 
                   hue=hue if hue and hue in df.columns else None,
                   size=size if size and size in df.columns else None,
                   alpha=0.7,
                   s=100)
    
    plt.title(f'Scatterplot: {columna_x} vs {columna_y}', fontsize=14, fontweight='bold')
    plt.xlabel(columna_x, fontsize=12)
    plt.ylabel(columna_y, fontsize=12)
    
    # Añadir línea de regresión
    sns.regplot(data=df, x=columna_x, y=columna_y, scatter=False, color='red', line_kws={'linestyle': '--'})
    
    plt.tight_layout()
    plt.show()

def barplot_agrupado(df, columna_x, columna_y, hue=None, titulo="Barplot Agrupado"):
    """
    Crear barplot agrupado
    """
    plt.figure(figsize=(12, 6))
    
    if columna_x not in df.columns or columna_y not in df.columns:
        print(f"❌ Columnas no encontradas: {columna_x}, {columna_y}")
        return
    
    if not pd.api.types.is_numeric_dtype(df[columna_y]):
        print(f"❌ La columna '{columna_y}' no es numérica")
        return
    
    # Crear barplot
    sns.barplot(data=df, 
               x=columna_x, 
               y=columna_y, 
               hue=hue if hue and hue in df.columns else None,
               palette="Set2",
               ci=95)  # Intervalo de confianza del 95%
    
    plt.title(titulo, fontsize=14, fontweight='bold')
    plt.xlabel(columna_x, fontsize=12)
    plt.ylabel(columna_y, fontsize=12)
    plt.xticks(rotation=45)
    
    if hue and hue in df.columns:
        plt.legend(title=hue, bbox_to_anchor=(1.05, 1), loc='upper left')
    
    plt.tight_layout()
    plt.show()

def analisis_completo_seaborn(df):
    """
    Realizar análisis visual completo con Seaborn
    """
    print("\n🔍 ANÁLISIS VISUAL COMPLETO CON SEABORN")
    print("="*50)
    
    columnas_numericas = df.select_dtypes(include=[np.number]).columns.tolist()
    columnas_categoricas = df.select_dtypes(include=['object', 'category']).columns.tolist()
    
    print(f"Columnas numéricas: {columnas_numericas}")
    print(f"Columnas categóricas: {columnas_categoricas}")
    
    if len(columnas_numericas) >= 2:
        # Heatmap de correlaciones
        print("\n📊 Creando heatmap de correlaciones...")
        heatmap_correlaciones(df, "Matriz de Correlaciones")
        
        # Pairplot
        print("\n🔗 Creando pairplot...")
        pairplot_avanzado(df, columnas_numericas[:4])
        
        # Scatterplot avanzado
        print(f"\n📈 Creando scatterplot: {columnas_numericas[0]} vs {columnas_numericas[1]}")
        hue_col = columnas_categoricas[0] if columnas_categoricas else None
        scatterplot_avanzado(df, columnas_numericas[0], columnas_numericas[1], hue=hue_col)
    
    if columnas_numericas:
        # Distribuciones
        print(f"\n📊 Creando distribuciones...")
        distplot_combinado(df, columnas_numericas)
        
        # Boxplot
        print(f"\n📦 Creando boxplot para: {columnas_numericas[0]}")
        boxplot_avanzado(df, columnas_numericas[0], 
                        columna_x=columnas_categoricas[0] if columnas_categoricas else None)

if __name__ == "__main__":
    print("🚀 Iniciando ejercicios de Seaborn...")
    
    # Cargar datos
    ventas, detalle_ventas, productos, clientes = cargar_datos()
    
    if detalle_ventas is not None:
        print("\n" + "="*60)
        print("EJERCICIOS DE SEABORN")
        print("="*60)
        
        # Análisis completo con Seaborn
        analisis_completo_seaborn(detalle_ventas)
        
        # Ejercicios específicos
        columnas_numericas = detalle_ventas.select_dtypes(include=[np.number]).columns.tolist()
        columnas_categoricas = detalle_ventas.select_dtypes(include=['object', 'category']).columns.tolist()
        
        if len(columnas_numericas) >= 2:
            # Violin plot
            print(f"\n🎻 Creando violin plot...")
            violin_plot(detalle_ventas, columnas_numericas[0], 
                       columna_x=columnas_categoricas[0] if columnas_categoricas else None)
        
        if columnas_categoricas and columnas_numericas:
            # Barplot agrupado
            print(f"\n📊 Creando barplot agrupado...")
            barplot_agrupado(detalle_ventas, columnas_categoricas[0], columnas_numericas[0],
                           titulo=f"{columnas_numericas[0]} por {columnas_categoricas[0]}")
        
        print("\n✅ Ejercicios de Seaborn completados!")
