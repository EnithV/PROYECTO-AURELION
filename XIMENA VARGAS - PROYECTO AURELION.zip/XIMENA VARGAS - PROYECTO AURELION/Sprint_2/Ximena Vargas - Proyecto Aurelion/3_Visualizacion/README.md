# Visualización de Datos

## Objetivos
- Aprender a crear visualizaciones efectivas con Matplotlib
- Dominar las capacidades de Seaborn para análisis estadístico
- Crear gráficos informativos y atractivos
- Interpretar visualizaciones de datos

## Archivos de trabajo
- `matplotlib_basico.py` - Fundamentos de Matplotlib
- `seaborn_avanzado.py` - Visualizaciones con Seaborn
- `graficos_estadisticos.py` - Gráficos para análisis estadístico
- `dashboard_visualizacion.py` - Dashboard completo

## Tipos de gráficos
- Gráficos de barras y columnas
- Histogramas y distribuciones
- Gráficos de dispersión
- Boxplots y violin plots
- Heatmaps y matrices de correlación
- Gráficos de líneas y tendencias
- Gráficos de área y pie charts
