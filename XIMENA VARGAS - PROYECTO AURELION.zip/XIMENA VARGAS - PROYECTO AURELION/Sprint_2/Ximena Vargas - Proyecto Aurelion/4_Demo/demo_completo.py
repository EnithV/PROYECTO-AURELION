#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Demo Completo: Análisis Integral de Datos
Proyecto Aurelion - Sistema de Gestión de Ventas
Autor: Ximena Vargas
Camada: 25
Grupo: 10

Objetivo: Integrar todos los conceptos aprendidos en un análisis completo
Este demo integra:
- Carga y limpieza de datos con pandas
- Análisis estadístico descriptivo
- Análisis de correlaciones
- Visualizaciones con matplotlib y seaborn
- Generación automática de reportes
- Clase AnalizadorDatos para encapsular funcionalidades
"""

# Importar librerías necesarias para el análisis integral
import pandas as pd  # type: ignore
import numpy as np  # type: ignore
import matplotlib.pyplot as plt  # type: ignore
import seaborn as sns  # type: ignore
import os
import sys
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')  # Suprimir advertencias para output más limpio

# Importar funciones de estadística descriptiva (incluye generación de histogramas)
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '2_Estadistica_Aplicada'))
from estadistica_descriptiva import analisis_completo_columna, crear_histograma_estadistico
from pathlib import Path

# Configuración de visualización
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")
plt.rcParams['figure.figsize'] = (12, 8)

class AnalizadorDatos:
    """
    Clase para realizar análisis completo de datos
    """
    
    def __init__(self, ruta_datos="../../../BASE_DE_DATOS/"):
        self.ruta_datos = ruta_datos
        self.datos = {}
        self.resultados = {}
        
    def cargar_datos(self):
        """
        Cargar todos los archivos de datos
        """
        print("🔄 Cargando datos...")
        
        archivos = {
            'clientes': 'Clientes.xlsx',
            'productos': 'Productos.xlsx',
            'ventas': 'Ventas.xlsx',
            'detalle_ventas': 'Detalle_ventas.xlsx'
        }
        
        for nombre, archivo in archivos.items():
            try:
                ruta_completa = os.path.join(self.ruta_datos, archivo)
                self.datos[nombre] = pd.read_excel(ruta_completa)
                print(f"✅ {nombre.capitalize()}: {self.datos[nombre].shape}")
            except Exception as e:
                print(f"❌ Error cargando {nombre}: {e}")
        
        print(f"📊 Total de datasets cargados: {len(self.datos)}")
        return len(self.datos) > 0
    
    def inspeccionar_datos(self):
        """
        Inspección completa de los datos
        """
        print("\n🔍 INSPECCIÓN DE DATOS")
        print("="*50)
        
        for nombre, df in self.datos.items():
            print(f"\n📋 {nombre.upper()}:")
            print(f"   - Forma: {df.shape}")
            print(f"   - Columnas: {list(df.columns)}")
            print(f"   - Valores nulos: {df.isnull().sum().sum()}")
            print(f"   - Tipos de datos:")
            for col, dtype in df.dtypes.items():
                print(f"     * {col}: {dtype}")
    
    def limpiar_datos(self):
        """
        Limpieza básica de datos
        """
        print("\n🧹 LIMPIEZA DE DATOS")
        print("="*50)
        
        for nombre, df in self.datos.items():
            print(f"\n🔧 Limpiando {nombre}...")
            
            # Eliminar filas completamente vacías
            filas_antes = len(df)
            df_limpio = df.dropna(how='all')
            filas_despues = len(df_limpio)
            
            if filas_antes != filas_despues:
                print(f"   - Eliminadas {filas_antes - filas_despues} filas vacías")
            
            # Limpiar espacios en columnas de texto
            for col in df_limpio.select_dtypes(include=['object']).columns:
                df_limpio[col] = df_limpio[col].astype(str).str.strip()
            
            # Actualizar datos
            self.datos[nombre] = df_limpio
            print(f"   ✅ {nombre} limpio: {df_limpio.shape}")
    
    def analisis_estadistico(self):
        """
        Análisis estadístico completo y avanzado
        """
        print("\n📊 ANÁLISIS ESTADÍSTICO AVANZADO")
        print("="*50)
        
        self.resultados['estadisticas'] = {}
        self.resultados['estadisticas_avanzadas'] = {}
        
        for nombre, df in self.datos.items():
            print(f"\n📈 Estadísticas de {nombre}:")
            
            # Seleccionar columnas numéricas
            columnas_numericas = df.select_dtypes(include=[np.number]).columns
            
            if len(columnas_numericas) > 0:
                # Estadísticas básicas
                stats = df[columnas_numericas].describe()
                self.resultados['estadisticas'][nombre] = stats
                print(stats.round(2))
                
                # Estadísticas avanzadas por columna
                self.resultados['estadisticas_avanzadas'][nombre] = {}
                for col in columnas_numericas:
                    data = df[col].dropna()
                    if len(data) > 0:
                        self.resultados['estadisticas_avanzadas'][nombre][col] = {
                            'mean': data.mean(),
                            'median': data.median(),
                            'mode': data.mode().iloc[0] if len(data.mode()) > 0 else None,
                            'std': data.std(),
                            'var': data.var(),
                            'cv': (data.std() / data.mean() * 100) if data.mean() != 0 else 0,
                            'mad': (data - data.median()).abs().mean(),
                            'q1': data.quantile(0.25),
                            'q3': data.quantile(0.75),
                            'iqr': data.quantile(0.75) - data.quantile(0.25),
                            'siqr': (data.quantile(0.75) - data.quantile(0.25)) / 2,
                            'min': data.min(),
                            'max': data.max(),
                            'range': data.max() - data.min(),
                            'skewness': data.skew(),
                            'kurtosis': data.kurtosis(),
                            'percentiles': {p: data.quantile(p/100) for p in [10, 25, 50, 75, 90, 95, 99]},
                            'outliers': len(data[(data < (data.quantile(0.25) - 1.5 * (data.quantile(0.75) - data.quantile(0.25)))) | 
                                                (data > (data.quantile(0.75) + 1.5 * (data.quantile(0.75) - data.quantile(0.25))))])
                        }
            else:
                print("   - No hay columnas numéricas")
    
    def analisis_correlaciones(self):
        """
        Análisis de correlaciones
        """
        print("\n🔗 ANÁLISIS DE CORRELACIONES")
        print("="*50)
        
        self.resultados['correlaciones'] = {}
        
        for nombre, df in self.datos.items():
            columnas_numericas = df.select_dtypes(include=[np.number]).columns
            
            if len(columnas_numericas) >= 2:
                print(f"\n📊 Correlaciones en {nombre}:")
                corr_matrix = df[columnas_numericas].corr()
                self.resultados['correlaciones'][nombre] = corr_matrix
                
                # Mostrar correlaciones más fuertes
                corr_pairs = []
                for i in range(len(corr_matrix.columns)):
                    for j in range(i+1, len(corr_matrix.columns)):
                        corr_val = corr_matrix.iloc[i, j]
                        if abs(corr_val) > 0.5:  # Correlaciones moderadas o fuertes
                            corr_pairs.append({
                                'Variables': f"{corr_matrix.columns[i]} - {corr_matrix.columns[j]}",
                                'Correlación': corr_val
                            })
                
                if corr_pairs:
                    corr_df = pd.DataFrame(corr_pairs)
                    print(corr_df.to_string(index=False))
                else:
                    print("   - No hay correlaciones fuertes (|r| > 0.5)")
    
    def crear_visualizaciones(self):
        """
        Crear visualizaciones como parte del análisis estadístico
        Los histogramas se generan basados en el análisis estadístico descriptivo
        Todas las visualizaciones se guardan en 2_Estadistica_Aplicada/histogramas/
        """
        print("\n📊 CREANDO VISUALIZACIONES (Basadas en Análisis Estadístico)")
        print("="*50)
        
        # Crear directorio para histogramas dentro de 2_Estadistica_Aplicada
        histogram_dir = Path(__file__).parent.parent / "2_Estadistica_Aplicada" / "histogramas"
        histogram_dir.mkdir(exist_ok=True)
        print(f"📁 Carpeta 'histogramas' ubicada en: {histogram_dir}")
        self.histogram_dir = str(histogram_dir)
        
        self.resultados['histogramas'] = {}
        self.resultados['metodos_pago'] = {}
        
        # Generar histogramas para cada variable numérica como parte del análisis estadístico
        for nombre, df in self.datos.items():
            print(f"\n📈 Generando visualizaciones estadísticas para {nombre}...")
            columnas_numericas = df.select_dtypes(include=[np.number]).columns
            
            for col in columnas_numericas:
                data = df[col].dropna()
                if len(data) > 0:
                    # Generar histograma basado en el análisis estadístico
                    hist_stats = crear_histograma_estadistico(
                        data, col, nombre, histogram_dir, guardar=True
                    )
                    if hist_stats:
                        self.resultados['histogramas'][f'{nombre}_{col}'] = hist_stats
            
            # Generar boxplots para detección de outliers (parte del análisis estadístico)
            if len(columnas_numericas) > 0:
                self._crear_boxplots_estadisticos(df, nombre, columnas_numericas, histogram_dir)
            
            # Generar matriz de correlaciones
            if len(columnas_numericas) >= 2:
                self._crear_matriz_correlaciones(df, nombre, columnas_numericas, histogram_dir)
            
            # Análisis de métodos de pago
            payment_cols = [col for col in df.columns if 'pago' in col.lower() or 'metodo' in col.lower() or 'payment' in col.lower()]
            for col in payment_cols:
                if df[col].dtype == 'object' or df[col].dtype.name == 'category':
                    self._crear_grafico_metodos_pago(df, col, nombre, histogram_dir)
    
    def _crear_boxplots_estadisticos(self, df, nombre_dataset, columnas_numericas, histogram_dir):
        """Crear boxplots como parte del análisis estadístico de outliers"""
        n_cols = min(len(columnas_numericas), 4)
        fig, axes = plt.subplots(1, n_cols, figsize=(5*n_cols, 6))
        if n_cols == 1:
            axes = [axes]
        
        fig.suptitle(f'Boxplots para Detección de Outliers - {nombre_dataset}', fontsize=16, fontweight='bold')
        
        for i, col in enumerate(columnas_numericas[:n_cols]):
            data = df[col].dropna()
            bp = axes[i].boxplot(data, patch_artist=True, showmeans=True, meanline=True)
            
            for patch in bp['boxes']:
                patch.set_facecolor('lightblue')
                patch.set_alpha(0.7)
            
            q1 = data.quantile(0.25)
            q3 = data.quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            outliers_count = len(data[(data < lower_bound) | (data > upper_bound)])
            
            axes[i].set_title(f'{col}\nOutliers: {outliers_count}', fontsize=11, fontweight='bold')
            axes[i].set_ylabel('Valor', fontsize=10)
            axes[i].grid(True, alpha=0.3, axis='y')
            
            stats_text = f'Q1: {q1:.2f}\nMediana: {data.median():.2f}\nQ3: {q3:.2f}'
            axes[i].text(0.02, 0.98, stats_text, transform=axes[i].transAxes, 
                        fontsize=8, verticalalignment='top', 
                        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        plt.tight_layout()
        filename = histogram_dir / f'boxplots_outliers_{nombre_dataset}.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"✅ Boxplots guardados: {filename}")
    
    def _crear_matriz_correlaciones(self, df, nombre_dataset, columnas_numericas, histogram_dir):
        """Crear matriz de correlaciones"""
        plt.figure(figsize=(10, 8))
        corr_matrix = df[columnas_numericas].corr()
        sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0,
                   square=True, linewidths=0.5, fmt='.2f')
        plt.title(f'Matriz de Correlaciones - {nombre_dataset}', fontsize=14, fontweight='bold')
        plt.tight_layout()
        filename = histogram_dir / f'matriz_correlaciones_{nombre_dataset}.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"✅ Matriz de correlaciones guardada: {filename}")
        
        if 'correlaciones' not in self.resultados:
            self.resultados['correlaciones'] = {}
        self.resultados['correlaciones'][nombre_dataset] = corr_matrix
    
    def _crear_grafico_metodos_pago(self, df, columna, nombre_dataset, histogram_dir):
        """Crear gráfico de métodos de pago"""
        payment_counts = df[columna].value_counts()
        payment_percentages = df[columna].value_counts(normalize=True) * 100
        
        fig, ax = plt.subplots(figsize=(10, 6))
        payment_counts.plot(kind='bar', ax=ax, color='steelblue', edgecolor='black')
        ax.set_title(f'Distribución de Métodos de Pago - {columna} ({nombre_dataset})', fontsize=14, fontweight='bold')
        ax.set_xlabel('Método de Pago', fontsize=12)
        ax.set_ylabel('Frecuencia', fontsize=12)
        ax.grid(True, alpha=0.3, axis='y')
        plt.xticks(rotation=45, ha='right')
        
        for i, v in enumerate(payment_counts.values):
            ax.text(i, v, f'{v}\n({payment_percentages.iloc[i]:.1f}%)', 
                   ha='center', va='bottom', fontsize=9)
        
        plt.tight_layout()
        filename = histogram_dir / f'metodos_pago_{nombre_dataset}_{columna.replace(" ", "_").replace("/", "_")}.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"   ✅ Gráfico de métodos de pago guardado: {filename}")
        
        self.resultados['metodos_pago'][f'{nombre_dataset}_{columna}'] = {
            'counts': payment_counts.to_dict(),
            'percentages': payment_percentages.to_dict(),
            'total': len(df[columna].dropna())
        }
    
    def generar_reporte(self):
        """
        Generar reporte de análisis completo en formato Markdown
        """
        print("\n📝 GENERANDO REPORTE")
        print("="*50)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        nombre_reporte = f"reporte_analisis_{timestamp}.md"
        
        report = []
        report.append("# REPORTE DE ANÁLISIS DE DATOS - SPRINT 2")
        report.append("=" * 50)
        report.append(f"**Autor:** Ximena Vargas")
        report.append(f"**Camada:** 25")
        report.append(f"**Grupo:** 10")
        report.append(f"**Fecha de análisis:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("")
        
        # Resumen de datos
        report.append("## RESUMEN DE DATOS")
        for nombre, df in self.datos.items():
            report.append(f"### {nombre.capitalize()}")
            report.append(f"- Registros: {df.shape[0]}")
            report.append(f"- Columnas: {df.shape[1]}")
            report.append(f"- Valores nulos: {df.isnull().sum().sum()}")
            report.append("")
        
        # Estadísticas Descriptivas Avanzadas
        if 'estadisticas_avanzadas' in self.resultados:
            report.append("## ESTADÍSTICAS DESCRIPTIVAS AVANZADAS")
            report.append("")
            report.append("Esta sección presenta un análisis estadístico completo y detallado de todas las variables numéricas del dataset.")
            report.append("")
            
            for nombre, columnas_stats in self.resultados['estadisticas_avanzadas'].items():
                for col, stats in columnas_stats.items():
                    report.append(f"### Variable: {col} ({nombre})")
                    report.append("")
                    
                    # Medidas de Tendencia Central
                    report.append("#### Medidas de Tendencia Central")
                    report.append(f"- **Media (μ):** {stats['mean']:.4f}")
                    report.append(f"- **Mediana (Q2):** {stats['median']:.4f}")
                    if stats['mode'] is not None:
                        report.append(f"- **Moda:** {stats['mode']:.4f}")
                    else:
                        report.append(f"- **Moda:** No hay moda única")
                    report.append("")
                    
                    # Medidas de Dispersión
                    report.append("#### Medidas de Dispersión")
                    report.append(f"- **Desviación Estándar (σ):** {stats['std']:.4f}")
                    report.append(f"- **Varianza (σ²):** {stats['var']:.4f}")
                    report.append(f"- **Coeficiente de Variación (CV):** {stats['cv']:.2f}%")
                    report.append(f"- **Rango:** {stats['range']:.4f}")
                    report.append(f"- **Desviación Media Absoluta (MAD):** {stats['mad']:.4f}")
                    report.append("")
                    
                    # Interpretación del CV
                    if stats['cv'] < 15:
                        cv_interp = "Baja variabilidad (datos homogéneos)"
                    elif stats['cv'] < 35:
                        cv_interp = "Variabilidad moderada"
                    else:
                        cv_interp = "Alta variabilidad (datos heterogéneos)"
                    report.append(f"  *Interpretación del CV: {cv_interp}*")
                    report.append("")
                    
                    # Percentiles
                    report.append("#### Percentiles")
                    for p in [10, 25, 50, 75, 90, 95, 99]:
                        if p in stats['percentiles']:
                            report.append(f"- **P{p}:** {stats['percentiles'][p]:.4f}")
                    report.append("")
                    
                    # Cuartiles
                    report.append("#### Cuartiles y Rango Intercuartílico (IQR)")
                    report.append(f"- **Q1 (Percentil 25):** {stats['q1']:.4f}")
                    report.append(f"- **Q2 (Mediana, Percentil 50):** {stats['median']:.4f}")
                    report.append(f"- **Q3 (Percentil 75):** {stats['q3']:.4f}")
                    report.append(f"- **IQR (Q3 - Q1):** {stats['iqr']:.4f}")
                    report.append(f"- **Rango Semi-Intercuartílico (SIQR):** {stats['siqr']:.4f}")
                    report.append("")
                    
                    # Análisis de Forma
                    report.append("#### Análisis de Forma de la Distribución")
                    report.append(f"- **Asimetría (Skewness):** {stats['skewness']:.4f}")
                    if abs(stats['skewness']) < 0.5:
                        skew_interp = "Distribución aproximadamente simétrica"
                    elif stats['skewness'] > 0.5:
                        skew_interp = "Asimetría positiva (cola hacia la derecha, sesgo derecho)"
                    else:
                        skew_interp = "Asimetría negativa (cola hacia la izquierda, sesgo izquierdo)"
                    report.append(f"  *{skew_interp}*")
                    report.append("")
                    
                    report.append(f"- **Curtosis (Kurtosis):** {stats['kurtosis']:.4f}")
                    if abs(stats['kurtosis']) < 0.5:
                        kurt_interp = "Curtosis normal (mesocúrtica, similar a distribución normal)"
                    elif stats['kurtosis'] > 0.5:
                        kurt_interp = "Leptocúrtica (picos más altos, colas más pesadas que la normal)"
                    else:
                        kurt_interp = "Platicúrtica (picos más bajos, colas más ligeras que la normal)"
                    report.append(f"  *{kurt_interp}*")
                    report.append("")
                    
                    # Outliers
                    report.append("#### Análisis de Outliers (Valores Atípicos)")
                    report.append(f"- **Outliers detectados:** {stats['outliers']}")
                    report.append("")
                    report.append("---")
                    report.append("")
        
        # Análisis Detallado de Histogramas
        if 'histogramas' in self.resultados:
            report.append("## ANÁLISIS DETALLADO DE HISTOGRAMAS")
            report.append("")
            report.append("Los histogramas proporcionan una representación visual de la distribución de frecuencias de las variables numéricas. Este análisis detallado incluye interpretación estadística completa de cada histograma generado.")
            report.append("")
            
            for key, hist_stats in self.resultados['histogramas'].items():
                # Obtener datos para análisis adicional
                nombre_dataset, col = key.split('_', 1) if '_' in key else (key, key)
                if nombre_dataset in self.datos and col in self.datos[nombre_dataset].columns:
                    data = self.datos[nombre_dataset][col].dropna()
                    
                    report.append(f"### Variable: {key}")
                    report.append("")
                    report.append(f"**Ubicación del histograma:** `{hist_stats['filename']}`")
                    report.append("")
                    
                    # Análisis visual del histograma
                    report.append("#### Análisis Visual del Histograma")
                    mode_result = data.mode()
                    if len(mode_result) == 1:
                        report.append(f"- **Tipo de distribución:** Unimodal (una moda en {mode_result.iloc[0]:.4f})")
                    elif len(mode_result) == 2:
                        report.append(f"- **Tipo de distribución:** Bimodal (dos modas: {mode_result.iloc[0]:.4f} y {mode_result.iloc[1]:.4f})")
                    elif len(mode_result) > 2:
                        report.append(f"- **Tipo de distribución:** Multimodal ({len(mode_result)} modas detectadas)")
                    else:
                        report.append(f"- **Tipo de distribución:** Sin moda clara (distribución uniforme o muy dispersa)")
                    
                    # Comparación media-mediana
                    mean_median_diff = abs(hist_stats['mean'] - hist_stats['median'])
                    if mean_median_diff < hist_stats['std'] * 0.1:
                        report.append(f"- **Relación Media-Mediana:** Media ({hist_stats['mean']:.4f}) y mediana ({hist_stats['median']:.4f}) son muy similares, sugiriendo simetría.")
                    elif hist_stats['mean'] > hist_stats['median']:
                        report.append(f"- **Relación Media-Mediana:** Media ({hist_stats['mean']:.4f}) > Mediana ({hist_stats['median']:.4f}), indicando asimetría positiva (cola derecha).")
                    else:
                        report.append(f"- **Relación Media-Mediana:** Mediana ({hist_stats['median']:.4f}) > Media ({hist_stats['mean']:.4f}), indicando asimetría negativa (cola izquierda).")
                    report.append("")
                    
                    # Estadísticas descriptivas
                    report.append("#### Estadísticas Descriptivas del Histograma")
                    report.append(f"- **Media (μ):** {hist_stats['mean']:.4f}")
                    report.append(f"- **Mediana (Q2):** {hist_stats['median']:.4f}")
                    report.append(f"- **Desviación Estándar (σ):** {hist_stats['std']:.4f}")
                    report.append(f"- **Varianza (σ²):** {hist_stats['std']**2:.4f}")
                    report.append(f"- **Mínimo:** {data.min():.4f}")
                    report.append(f"- **Máximo:** {data.max():.4f}")
                    report.append(f"- **Rango:** {data.max() - data.min():.4f}")
                    report.append("")
                    
                    # Análisis de forma detallado
                    report.append("#### Análisis de Forma de la Distribución")
                    report.append(f"- **Asimetría (Skewness):** {hist_stats['skewness']:.4f}")
                    if abs(hist_stats['skewness']) < 0.5:
                        skew_interp = "Distribución aproximadamente simétrica. La media y mediana son similares, y los datos se distribuyen de manera equilibrada alrededor del centro."
                    elif hist_stats['skewness'] > 0.5:
                        skew_interp = f"Distribución con asimetría positiva (sesgo derecho). La cola se extiende hacia valores mayores. Esto indica que hay más valores por debajo de la media que por encima. El valor de asimetría ({hist_stats['skewness']:.4f}) sugiere una asimetría moderada a fuerte."
                    else:
                        skew_interp = f"Distribución con asimetría negativa (sesgo izquierdo). La cola se extiende hacia valores menores. Esto indica que hay más valores por encima de la media que por debajo. El valor de asimetría ({hist_stats['skewness']:.4f}) sugiere una asimetría moderada a fuerte."
                    report.append(f"  *{skew_interp}*")
                    report.append("")
                    
                    report.append(f"- **Curtosis (Kurtosis):** {hist_stats['kurtosis']:.4f}")
                    if abs(hist_stats['kurtosis']) < 0.5:
                        kurt_interp = "Curtosis normal (mesocúrtica). La distribución tiene un pico similar a una distribución normal estándar, con colas de grosor normal."
                    elif hist_stats['kurtosis'] > 0.5:
                        kurt_interp = f"Distribución leptocúrtica. La distribución tiene un pico más alto y colas más pesadas que una distribución normal. El valor de curtosis ({hist_stats['kurtosis']:.4f}) indica que hay más valores concentrados cerca de la media y más valores extremos (outliers potenciales) que en una distribución normal."
                    else:
                        kurt_interp = f"Distribución platicúrtica. La distribución tiene un pico más bajo y colas más ligeras que una distribución normal. El valor de curtosis ({hist_stats['kurtosis']:.4f}) indica que los datos están más dispersos y hay menos valores extremos que en una distribución normal."
                    report.append(f"  *{kurt_interp}*")
                    report.append("")
                    
                    # Análisis de outliers
                    q1 = data.quantile(0.25)
                    q3 = data.quantile(0.75)
                    iqr = q3 - q1
                    lower_bound = q1 - 1.5 * iqr
                    upper_bound = q3 + 1.5 * iqr
                    outliers = data[(data < lower_bound) | (data > upper_bound)]
                    outliers_count = len(outliers)
                    outliers_pct = (outliers_count / len(data)) * 100 if len(data) > 0 else 0
                    
                    report.append("#### Análisis de Outliers (Valores Atípicos)")
                    report.append(f"- **Número de outliers detectados:** {outliers_count} ({outliers_pct:.2f}% del total)")
                    if outliers_count > 0:
                        report.append(f"- **Límite inferior para outliers:** {lower_bound:.4f}")
                        report.append(f"- **Límite superior para outliers:** {upper_bound:.4f}")
                        report.append(f"- **Rango de valores outliers:** [{outliers.min():.4f}, {outliers.max():.4f}]")
                        report.append(f"- **Interpretación:** Se detectaron {outliers_count} valores atípicos ({outliers_pct:.2f}% del total). Estos valores pueden ser errores de medición, valores legítimos pero extremos, o requerir investigación adicional.")
                    else:
                        report.append(f"- **Interpretación:** No se detectaron valores atípicos significativos en esta variable. Los datos están dentro de los límites esperados según el método IQR.")
                    report.append("")
                    
                    # Interpretación general
                    report.append("#### Interpretación General del Histograma")
                    report.append(f"El histograma de la variable **{key}** muestra una distribución con características específicas que reflejan el comportamiento de los datos. La mayoría de los valores se concentran alrededor de {hist_stats['median']:.4f} (mediana), con una dispersión medida por una desviación estándar de {hist_stats['std']:.4f}.")
                    report.append("")
                    report.append("---")
                    report.append("")
        
        # Análisis de Métodos de Pago
        if 'metodos_pago' in self.resultados and len(self.resultados['metodos_pago']) > 0:
            report.append("## ANÁLISIS DE MÉTODOS DE PAGO")
            report.append("")
            
            for key, payment_data in self.resultados['metodos_pago'].items():
                report.append(f"### {key}")
                report.append(f"**Total de transacciones analizadas:** {payment_data['total']}")
                report.append("")
                report.append("**Distribución de métodos de pago:**")
                report.append("")
                report.append("| Método de Pago | Cantidad | Porcentaje |")
                report.append("|----------------|----------|------------|")
                
                sorted_payments = sorted(payment_data['counts'].items(), key=lambda x: x[1], reverse=True)
                for method, count in sorted_payments:
                    percentage = payment_data['percentages'].get(method, 0)
                    report.append(f"| {method} | {count} | {percentage:.2f}% |")
                
                report.append("")
                most_common = max(payment_data['counts'].items(), key=lambda x: x[1])
                report.append(f"**Interpretación:** El método de pago más utilizado es **{most_common[0]}** con {most_common[1]} transacciones ({payment_data['percentages'][most_common[0]]:.2f}% del total).")
                report.append("")
                report.append("---")
                report.append("")
        
        # Análisis de Boxplots y Variables Continuas
        if 'estadisticas_avanzadas' in self.resultados:
            report.append("## ANÁLISIS DE BOXPLOTS Y VARIABLES CONTINUAS")
            report.append("")
            report.append("Los boxplots son herramientas visuales esenciales para analizar variables continuas. Permiten identificar:")
            report.append("- Mediana y cuartiles")
            report.append("- Rango intercuartílico (IQR)")
            report.append("- Valores atípicos (outliers)")
            report.append("- Asimetría de la distribución")
            report.append("")
            report.append("**Ubicación del gráfico:** `2_Estadistica_Aplicada/histogramas/boxplots_outliers_*.png`")
            report.append("")
            
            for nombre, columnas_stats in self.resultados['estadisticas_avanzadas'].items():
                for col, stats in columnas_stats.items():
                    if nombre in self.datos and col in self.datos[nombre].columns:
                        data = self.datos[nombre][col].dropna()
                        report.append(f"### Variable: {col} ({nombre})")
                        report.append(f"- **Mediana:** {stats['median']:.4f}")
                        report.append(f"- **Q1:** {stats['q1']:.4f}")
                        report.append(f"- **Q3:** {stats['q3']:.4f}")
                        report.append(f"- **IQR:** {stats['iqr']:.4f}")
                        report.append(f"- **Outliers detectados:** {stats['outliers']} ({stats['outliers']/len(data)*100:.2f}% del total)" if len(data) > 0 else "- **Outliers detectados:** 0")
                        report.append("")
        
        # Correlaciones
        if 'correlaciones' in self.resultados:
            report.append("## ANÁLISIS DE CORRELACIONES")
            report.append("")
            report.append("**Ubicación del gráfico:** `2_Estadistica_Aplicada/histogramas/matriz_correlaciones_*.png`")
            report.append("")
            for nombre, corr in self.resultados['correlaciones'].items():
                report.append(f"### {nombre.capitalize()}")
                report.append("")
                report.append("| Variable 1 | Variable 2 | Correlación |")
                report.append("|------------|------------|-------------|")
                
                for i in range(len(corr.columns)):
                    for j in range(i+1, len(corr.columns)):
                        corr_val = corr.iloc[i, j]
                        if abs(corr_val) > 0.5:
                            strength = "Fuerte" if abs(corr_val) > 0.7 else "Moderada"
                            report.append(f"| {corr.columns[i]} | {corr.columns[j]} | {corr_val:.4f} ({strength}) |")
                report.append("")
        
        # Guardar reporte
        with open(nombre_reporte, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report))
        
        print(f"✅ Reporte generado: {nombre_reporte}")
        return nombre_reporte
    
    def ejecutar_analisis_completo(self):
        """
        Ejecutar análisis completo
        """
        print("🚀 INICIANDO ANÁLISIS COMPLETO")
        print("="*60)
        
        # Paso 1: Cargar datos
        if not self.cargar_datos():
            print("❌ No se pudieron cargar los datos")
            return False
        
        # Paso 2: Inspeccionar datos
        self.inspeccionar_datos()
        
        # Paso 3: Limpiar datos
        self.limpiar_datos()
        
        # Paso 4: Análisis estadístico (incluye generación de histogramas)
        self.analisis_estadistico()
        
        # Paso 5: Análisis de correlaciones
        self.analisis_correlaciones()
        
        # Paso 6: Visualizaciones basadas en análisis estadístico
        self.crear_visualizaciones()
        
        # Paso 7: Generar reporte
        reporte = self.generar_reporte()
        
        print("\n✅ ANÁLISIS COMPLETO FINALIZADO")
        print("="*60)
        print(f"📊 Datasets analizados: {len(self.datos)}")
        print(f"📈 Análisis estadísticos: {len(self.resultados.get('estadisticas', {}))}")
        print(f"📊 Estadísticas avanzadas: {len(self.resultados.get('estadisticas_avanzadas', {}))}")
        print(f"📊 Histogramas creados: {len(self.resultados.get('histogramas', {}))}")
        print(f"💳 Análisis de métodos de pago: {len(self.resultados.get('metodos_pago', {}))}")
        print(f"🔗 Matrices de correlación: {len(self.resultados.get('correlaciones', {}))}")
        print(f"📝 Reporte generado: {reporte}")
        print(f"📁 Gráficos guardados en: 2_Estadistica_Aplicada/histogramas/")
        
        return True

def main():
    """
    Función principal para ejecutar el demo
    """
    print("🎯 DEMO COMPLETO - ANÁLISIS INTEGRAL DE DATOS")
    print("="*60)
    
    # Crear analizador
    analizador = AnalizadorDatos()
    
    # Ejecutar análisis completo
    exito = analizador.ejecutar_analisis_completo()
    
    if exito:
        print("\n🎉 ¡Demo completado exitosamente!")
        print("\n📚 Conceptos aplicados:")
        print("   ✅ Carga y lectura de datos")
        print("   ✅ Inspección y limpieza")
        print("   ✅ Análisis estadístico")
        print("   ✅ Análisis de correlaciones")
        print("   ✅ Visualizaciones")
        print("   ✅ Generación de reportes")
    else:
        print("\n❌ El demo no pudo completarse")

if __name__ == "__main__":
    main()
