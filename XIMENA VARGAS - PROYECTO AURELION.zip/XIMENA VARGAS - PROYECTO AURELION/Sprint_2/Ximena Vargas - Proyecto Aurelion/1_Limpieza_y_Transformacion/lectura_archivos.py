#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ejercicio 1: Lectura de archivos Excel con pandas
Proyecto Aurelion - Sistema de Gestión de Ventas
Autor: Ximena Vargas
Camada: 25
Grupo: 10

Objetivo: Aprender a cargar y leer archivos Excel usando pandas
Este ejercicio enseña:
- Carga de archivos Excel con pandas
- Manejo de errores en la carga de datos
- Inspección básica de DataFrames
- Visualización de primeras filas de datos
"""

# Importar librerías necesarias para el análisis
import pandas as pd  # type: ignore
import os
from pathlib import Path

def obtener_ruta_base_datos():
    """
    Obtener la ruta correcta a BASE_DE_DATOS independientemente de desde dónde se ejecute el script.
    
    Returns:
        str: Ruta absoluta a BASE_DE_DATOS
    """
    # Obtener la ruta del archivo actual
    archivo_actual = Path(__file__).resolve()
    
    # Navegar desde el archivo actual hasta BASE_DE_DATOS
    # El archivo está en: Sprint_2/Ximena Vargas - Proyecto Aurelion/1_Limpieza_y_Transformacion/lectura_archivos.py
    # BASE_DE_DATOS está en: BASE_DE_DATOS/
    # Necesitamos subir 3 niveles: 1_Limpieza_y_Transformacion -> Ximena Vargas - Proyecto Aurelion -> Sprint_2 -> raíz -> BASE_DE_DATOS
    
    # Intentar diferentes rutas relativas
    rutas_posibles = [
        archivo_actual.parent.parent.parent.parent / "BASE_DE_DATOS",  # Desde Sprint_2/Ximena Vargas - Proyecto Aurelion/1_Limpieza...
        archivo_actual.parent.parent.parent / "BASE_DE_DATOS",  # Si está en otro lugar
        Path.cwd().parent.parent.parent / "BASE_DE_DATOS",  # Desde directorio actual
    ]
    
    for ruta in rutas_posibles:
        if ruta.exists() and ruta.is_dir():
            return str(ruta)
    
    # Si no se encuentra, retornar ruta relativa como fallback
    return "../../../BASE_DE_DATOS"

def cargar_datos():
    """
    Función para cargar todos los archivos Excel de la base de datos
    
    Returns:
        tuple: Tupla con 4 DataFrames (clientes, productos, ventas, detalle_ventas)
               Si hay error, retorna (None, None, None, None)
    """
    # Obtener la ruta base donde se encuentran los archivos de datos
    ruta_datos = obtener_ruta_base_datos()
    
    try:
        # Cargar cada archivo Excel usando pandas.read_excel()
        # os.path.join() construye la ruta completa de forma segura
        clientes = pd.read_excel(os.path.join(ruta_datos, "Clientes.xlsx"))
        productos = pd.read_excel(os.path.join(ruta_datos, "Productos.xlsx"))
        ventas = pd.read_excel(os.path.join(ruta_datos, "Ventas.xlsx"))
        detalle_ventas = pd.read_excel(os.path.join(ruta_datos, "Detalle_ventas.xlsx"))
        
        # Mensaje de confirmación si la carga fue exitosa
        print("✅ Archivos cargados exitosamente")
        return clientes, productos, ventas, detalle_ventas
        
    except Exception as e:
        # Manejo de errores: si falla la carga, mostrar el error y retornar None
        print(f"❌ Error al cargar archivos: {e}")
        print(f"   Ruta intentada: {ruta_datos}")
        return None, None, None, None

def mostrar_info_basica(clientes, productos, ventas, detalle_ventas):
    """
    Mostrar información básica de cada DataFrame
    
    Args:
        clientes (DataFrame): DataFrame con datos de clientes
        productos (DataFrame): DataFrame con datos de productos
        ventas (DataFrame): DataFrame con datos de ventas
        detalle_ventas (DataFrame): DataFrame con detalles de ventas
    """
    # Crear diccionario para iterar sobre todos los datasets
    datasets = {
        "Clientes": clientes,
        "Productos": productos,
        "Ventas": ventas,
        "Detalle Ventas": detalle_ventas
    }
    
    # Iterar sobre cada dataset y mostrar información básica
    for nombre, df in datasets.items():
        if df is not None:  # Verificar que el DataFrame no sea None
            print(f"\n📊 {nombre}:")
            # Mostrar la forma del DataFrame (filas, columnas)
            print(f"   - Forma: {df.shape}")
            # Mostrar las columnas disponibles
            print(f"   - Columnas: {list(df.columns)}")
            print(f"   - Tipos de datos:")
            # Iterar sobre cada columna y mostrar su tipo de dato
            for col, dtype in df.dtypes.items():
                print(f"     * {col}: {dtype}")

if __name__ == "__main__":
    """
    Función principal que se ejecuta cuando el script se ejecuta directamente
    """
    print("🚀 Iniciando ejercicio de lectura de archivos...")
    
    # Cargar datos usando la función cargar_datos()
    clientes, productos, ventas, detalle_ventas = cargar_datos()
    
    # Verificar que la carga fue exitosa (clientes no es None)
    if clientes is not None:
        # Mostrar información básica de todos los datasets
        mostrar_info_basica(clientes, productos, ventas, detalle_ventas)
        
        # Mostrar las primeras 5 filas de cada dataset para inspección visual
        print("\n" + "="*50)
        print("PRIMERAS FILAS DE CADA DATASET")
        print("="*50)
        
        print("\n👥 CLIENTES:")
        print(clientes.head())  # head() muestra las primeras 5 filas por defecto
        
        print("\n📦 PRODUCTOS:")
        print(productos.head())
        
        print("\n💰 VENTAS:")
        print(ventas.head())
        
        print("\n📋 DETALLE VENTAS:")
        print(detalle_ventas.head())
