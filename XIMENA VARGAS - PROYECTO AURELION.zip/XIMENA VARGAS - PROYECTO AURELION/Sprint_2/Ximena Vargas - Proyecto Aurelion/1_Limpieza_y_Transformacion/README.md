# Limpieza y Transformación de Datos

## Objetivos
- Aprender a leer archivos Excel con pandas
- Entender las estructuras principales de pandas (DataFrame, Series)
- Realizar inspección básica de datos
- Aplicar técnicas de limpieza de datos

## Archivos de trabajo
- `lectura_archivos.py` - Lectura de archivos Excel
- `estructuras_pandas.py` - Estructuras principales de pandas
- `inspeccion_datos.py` - Inspección y análisis básico
- `limpieza_datos.py` - Técnicas de limpieza

## Datos disponibles
- `../../../BASE_DE_DATOS/Clientes.xlsx`
- `../../../BASE_DE_DATOS/Productos.xlsx`
- `../../../BASE_DE_DATOS/Ventas.xlsx`
- `../../../BASE_DE_DATOS/Detalle_ventas.xlsx`
