#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ejercicio 2: Estructuras principales de pandas
Proyecto Aurelion - Sistema de Gestión de Ventas
Autor: Ximena Vargas
Camada: 25
Grupo: 10

Objetivo: Entender DataFrame y Series, sus propiedades y métodos básicos
Este ejercicio enseña:
- Creación de Series y DataFrames
- Propiedades y métodos básicos
- Operaciones de selección y filtrado
- Estadísticas descriptivas básicas
"""

# Importar librerías necesarias para el análisis
import pandas as pd  # type: ignore
import numpy as np  # type: ignore

def crear_ejemplos_basicos():
    """
    Crear ejemplos básicos de Series y DataFrame
    """
    print("🔧 CREANDO EJEMPLOS BÁSICOS")
    print("="*40)
    
    # Crear una Series
    print("\n📈 SERIES:")
    ventas_mensuales = pd.Series([1000, 1200, 800, 1500, 2000], 
                                index=['Ene', 'Feb', 'Mar', 'Abr', 'May'],
                                name='Ventas')
    print(ventas_mensuales)
    print(f"Tipo: {type(ventas_mensuales)}")
    print(f"Valores: {ventas_mensuales.values}")
    print(f"Índices: {ventas_mensuales.index}")
    
    # Crear un DataFrame
    print("\n📊 DATAFRAME:")
    datos_ventas = {
        'Mes': ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo'],
        'Ventas': [1000, 1200, 800, 1500, 2000],
        'Clientes': [50, 60, 40, 75, 100],
        'Productos': [25, 30, 20, 35, 45]
    }
    
    df_ventas = pd.DataFrame(datos_ventas)
    print(df_ventas)
    print(f"Tipo: {type(df_ventas)}")
    print(f"Forma: {df_ventas.shape}")
    print(f"Columnas: {df_ventas.columns.tolist()}")
    print(f"Índices: {df_ventas.index.tolist()}")

def explorar_propiedades_dataframe(df):
    """
    Explorar las propiedades principales de un DataFrame
    """
    print(f"\n🔍 PROPIEDADES DEL DATAFRAME")
    print("="*40)
    
    print(f"📏 Forma (shape): {df.shape}")
    print(f"📋 Columnas: {list(df.columns)}")
    print(f"🔢 Índices: {list(df.index)}")
    print(f"📊 Tipos de datos:")
    print(df.dtypes)
    print(f"💾 Memoria utilizada: {df.memory_usage(deep=True).sum()} bytes")
    print(f"🏷️  Información general:")
    print(df.info())

def operaciones_basicas(df):
    """
    Realizar operaciones básicas con DataFrames
    """
    print(f"\n⚙️  OPERACIONES BÁSICAS")
    print("="*40)
    
    # Selección de columnas
    print("\n🎯 Selección de columnas:")
    if 'Ventas' in df.columns:
        print("Columna 'Ventas':")
        print(df['Ventas'])
    
    # Selección de filas
    print("\n📝 Selección de filas:")
    print("Primeras 3 filas:")
    print(df.head(3))
    print("Últimas 2 filas:")
    print(df.tail(2))
    
    # Filtrado
    print("\n🔍 Filtrado de datos:")
    if 'Ventas' in df.columns:
        ventas_altas = df[df['Ventas'] > 1000]
        print("Ventas mayores a 1000:")
        print(ventas_altas)
    
    # Estadísticas básicas
    print("\n📈 Estadísticas básicas:")
    print(df.describe())

if __name__ == "__main__":
    print("🚀 Iniciando ejercicio de estructuras pandas...")
    
    # Crear ejemplos básicos
    crear_ejemplos_basicos()
    
    # Crear DataFrame de ejemplo para explorar
    datos_ejemplo = {
        'Producto': ['A', 'B', 'C', 'D', 'E'],
        'Precio': [10.5, 25.0, 15.75, 8.0, 30.0],
        'Cantidad': [100, 50, 75, 200, 25],
        'Categoria': ['Electrónicos', 'Ropa', 'Hogar', 'Deportes', 'Libros']
    }
    
    df_ejemplo = pd.DataFrame(datos_ejemplo)
    
    # Explorar propiedades
    explorar_propiedades_dataframe(df_ejemplo)
    
    # Operaciones básicas
    operaciones_basicas(df_ejemplo)
