#!/bin/bash
# Script para instalar dependencias del proyecto
# Proyecto Aurelion - Ximena Vargas

echo "=========================================="
echo "INSTALACIÓN DE DEPENDENCIAS - PROYECTO AURELION"
echo "=========================================="
echo ""

# Verificar que estamos en el directorio correcto
if [ ! -f "requirements.txt" ]; then
    echo "❌ Error: No se encontró requirements.txt"
    echo "   Asegúrate de estar en el directorio raíz del proyecto"
    exit 1
fi

# Verificar que el venv existe
if [ ! -d "venv" ]; then
    echo "⚠️  El ambiente virtual no existe. Creándolo..."
    python -m venv venv
    if [ $? -ne 0 ]; then
        echo "❌ Error al crear el ambiente virtual"
        exit 1
    fi
    echo "✅ Ambiente virtual creado"
fi

# Activar el ambiente virtual
echo "🔄 Activando ambiente virtual..."
source venv/Scripts/activate

if [ $? -ne 0 ]; then
    echo "❌ Error al activar el ambiente virtual"
    exit 1
fi

echo "✅ Ambiente virtual activado"
echo ""

# Actualizar pip
echo "🔄 Actualizando pip..."
pip install --upgrade pip --quiet

# Instalar dependencias
echo "📦 Instalando dependencias desde requirements.txt..."
pip install -r requirements.txt

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Dependencias instaladas correctamente"
    echo ""
    echo "📋 Paquetes instalados:"
    pip list | grep -E "pandas|numpy|matplotlib|seaborn|scipy|openpyxl"
    echo ""
    echo "🎉 ¡Instalación completada!"
    echo ""
    echo "Para usar el proyecto:"
    echo "  1. Activa el venv: source venv/Scripts/activate"
    echo "  2. Navega a Sprint_2: cd Sprint_2"
    echo "  3. Ejecuta el menú: python menu_interactivo.py"
else
    echo ""
    echo "❌ Error al instalar dependencias"
    exit 1
fi

